'use client'

import { useEffect, useState } from 'react'
import { useApp } from '@/lib/store'
import { api, ApiError } from '@/lib/api-client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Sparkles, Brain, Globe, ShieldCheck, Loader2, MailCheck, ArrowLeft } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import type { User } from '@/types'

export function AuthScreen() {
  const { authView, setAuthView, setUser, init } = useApp()
  const [verifyToken] = useState<string | null>(() =>
    typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('verify') : null,
  )
  const [resetToken] = useState<string | null>(() =>
    typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('reset') : null,
  )

  return (
    <div className="flex min-h-[100dvh] w-full">
      {/* Brand panel — desktop only */}
      <div className="relative hidden w-1/2 flex-col justify-between overflow-hidden bg-gradient-to-br from-emerald-950 via-background to-background p-8 xl:flex xl:p-12">
        <div className="pointer-events-none absolute -right-32 top-1/4 h-96 w-96 rounded-full bg-brand/20 blur-3xl" />
        <div className="pointer-events-none absolute -left-20 bottom-10 h-72 w-72 rounded-full bg-brand/10 blur-3xl" />
        <div className="relative flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand text-brand-foreground">
            <Sparkles className="h-5 w-5" />
          </div>
          <span className="text-xl font-semibold tracking-tight">Nexus AI</span>
        </div>
        <div className="relative space-y-6">
          <h1 className="text-fluid-xl font-bold leading-tight tracking-tight">
            Your intelligent assistant with{' '}
            <span className="text-brand">real memory</span> and{' '}
            <span className="text-brand">live web research</span>.
          </h1>
          <p className="text-fluid-md text-muted-foreground">
            Ask complex questions. Nexus searches the web when it matters, cites its sources, and
            remembers what's useful across every conversation.
          </p>
          <div className="grid grid-cols-1 gap-3 pt-4">
            {[
              { icon: Brain, title: 'Persistent memory', desc: 'Remembers your context, preferences and projects.' },
              { icon: Globe, title: 'Live web research', desc: 'Searches authoritative sources, ranks and cites them.' },
              { icon: ShieldCheck, title: 'Private & secure', desc: 'Hashed passwords, secure sessions, strict isolation.' },
            ].map((f) => (
              <div key={f.title} className="flex items-start gap-3 rounded-xl border border-border/60 bg-card/40 p-3 backdrop-blur">
                <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand/15 text-brand">
                  <f.icon className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <div className="font-medium">{f.title}</div>
                  <div className="text-sm text-muted-foreground">{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="relative text-xs text-muted-foreground">
          © {new Date().getFullYear()} Nexus AI · Neon PostgreSQL · Built with Next.js
        </div>
      </div>

      {/* Form panel */}
      <div className="flex w-full flex-col items-center justify-center px-4 py-8 sm:px-6 sm:py-12 lg:w-1/2">
        <div className="w-full max-w-sm">
          {authView === 'login' && <LoginForm onSuccess={(u) => { setUser(u); init() }} />}
          {authView === 'register' && <RegisterForm onSuccess={(u) => { setUser(u); init() }} />}
          {authView === 'forgot' && <ForgotForm />}
          {authView === 'reset' && <ResetForm token={resetToken} />}
          {authView === 'verify' && <VerifyForm token={verifyToken} onSuccess={(u) => { setUser(u); init() }} />}
        </div>
      </div>
    </div>
  )
}

function FormShell({ title, subtitle, children, footer }: { title: string; subtitle?: string; children: React.ReactNode; footer?: React.ReactNode }) {
  return (
    <div className="space-y-5 sm:space-y-6">
      <div className="lg:hidden">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-brand-foreground">
            <Sparkles className="h-4 w-4" />
          </div>
          <span className="text-lg font-semibold">Nexus AI</span>
        </div>
      </div>
      <div className="space-y-1.5">
        <h2 className="text-fluid-lg font-bold tracking-tight">{title}</h2>
        {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {children}
      {footer && <div className="text-sm text-muted-foreground">{footer}</div>}
    </div>
  )
}

function FieldError({ msg }: { msg?: string }) {
  if (!msg) return null
  return <p className="text-xs text-destructive">{msg}</p>
}

function LoginForm({ onSuccess }: { onSuccess: (u: User) => void }) {
  const { setAuthView } = useApp()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const { user } = await api<{ user: User }>('/api/auth/login', { method: 'POST', body: { email, password, remember: true } })
      toast({ title: 'Welcome back!' })
      onSuccess(user)
    } catch (e) {
      toast({ title: 'Sign in failed', description: e instanceof ApiError ? e.message : 'Something went wrong', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <FormShell
      title="Welcome back"
      subtitle="Sign in to continue your conversations."
      footer={<>Don&apos;t have an account? <button onClick={() => setAuthView('register')} className="font-medium text-brand hover:underline">Sign up</button></>}
    >
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">Password</Label>
            <button type="button" onClick={() => setAuthView('forgot')} className="text-xs text-muted-foreground hover:text-brand">Forgot?</button>
          </div>
          <Input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </div>
        <Button type="submit" className="w-full bg-brand text-brand-foreground hover:bg-brand/90" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Sign in
        </Button>
      </form>
    </FormShell>
  )
}

function RegisterForm({ onSuccess }: { onSuccess: (u: User) => void }) {
  const { setAuthView } = useApp()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' })
  const [err, setErr] = useState<Record<string, string>>({})

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErr({})
    setLoading(true)
    try {
      const { user } = await api<{ user: User }>('/api/auth/register', {
        method: 'POST',
        body: form,
      })
      toast({ title: 'Account created', description: 'A verification link has been sent to your email.' })
      onSuccess(user)
    } catch (e) {
      toast({ title: 'Registration failed', description: e instanceof ApiError ? e.message : 'Something went wrong', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }))

  return (
    <FormShell
      title="Create your account"
      subtitle="Start chatting with an AI that remembers and researches."
      footer={<>Already have an account? <button onClick={() => setAuthView('login')} className="font-medium text-brand hover:underline">Sign in</button></>}
    >
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="name">Full name</Label>
          <Input id="name" required value={form.name} onChange={set('name')} placeholder="Jane Doe" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="remail">Email</Label>
          <Input id="remail" type="email" autoComplete="email" required value={form.email} onChange={set('email')} placeholder="you@example.com" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="rpass">Password</Label>
          <Input id="rpass" type="password" autoComplete="new-password" required value={form.password} onChange={set('password')} placeholder="Min 8 chars, letters + numbers" />
          <p className="text-xs text-muted-foreground">Use at least 8 characters with a letter and a number.</p>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="rcpass">Confirm password</Label>
          <Input id="rcpass" type="password" autoComplete="new-password" required value={form.confirmPassword} onChange={set('confirmPassword')} placeholder="••••••••" />
          <FieldError msg={err.confirmPassword} />
        </div>
        <Button type="submit" className="w-full bg-brand text-brand-foreground hover:bg-brand/90" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Create account
        </Button>
      </form>
    </FormShell>
  )
}

function ForgotForm() {
  const { setAuthView } = useApp()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [resetLink, setResetLink] = useState<string | null>(null)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await api<{ ok: boolean; resetLink?: string }>('/api/auth/forgot-password', { method: 'POST', body: { email } })
      setSent(true)
      setResetLink(res.resetLink ?? null)
    } catch (e) {
      toast({ title: 'Request failed', description: e instanceof ApiError ? e.message : 'Try again', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  if (sent) {
    return (
      <FormShell title="Check your email" subtitle="If an account exists for that address, a reset link is on its way.">
        <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/40 p-4">
          <MailCheck className="h-5 w-5 text-brand" />
          <p className="text-sm text-muted-foreground">The link expires in 1 hour.</p>
        </div>
        {resetLink && (
          <div className="rounded-lg border border-dashed border-border p-3 text-xs">
            <p className="mb-2 font-medium text-muted-foreground">Dev mode — no email provider configured. Use this link:</p>
            <a href={resetLink} className="break-all text-brand underline">{resetLink}</a>
          </div>
        )}
        <button onClick={() => setAuthView('login')} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-brand">
          <ArrowLeft className="h-4 w-4" /> Back to sign in
        </button>
      </FormShell>
    )
  }

  return (
    <FormShell title="Reset your password" subtitle="Enter your email and we'll send you a reset link.">
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="femail">Email</Label>
          <Input id="femail" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        </div>
        <Button type="submit" className="w-full bg-brand text-brand-foreground hover:bg-brand/90" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Send reset link
        </Button>
      </form>
      <button onClick={() => setAuthView('login')} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-brand">
        <ArrowLeft className="h-4 w-4" /> Back to sign in
      </button>
    </FormShell>
  )
}

function ResetForm({ token }: { token: string | null }) {
  const { setAuthView } = useApp()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [password, setPassword] = useState('')
  const [done, setDone] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!token) return
    setLoading(true)
    try {
      await api('/api/auth/reset-password', { method: 'POST', body: { token, password } })
      setDone(true)
      toast({ title: 'Password reset', description: 'You can now sign in with your new password.' })
    } catch (e) {
      toast({ title: 'Reset failed', description: e instanceof ApiError ? e.message : 'Invalid or expired link', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  if (!token) {
    return (
      <FormShell title="Invalid link" subtitle="This reset link is missing or malformed.">
        <button onClick={() => setAuthView('forgot')} className="text-sm text-brand hover:underline">Request a new reset link</button>
      </FormShell>
    )
  }
  if (done) {
    return (
      <FormShell title="Password updated" subtitle="Your password has been reset successfully.">
        <Button onClick={() => setAuthView('login')} className="w-full bg-brand text-brand-foreground hover:bg-brand/90">Continue to sign in</Button>
      </FormShell>
    )
  }
  return (
    <FormShell title="Set a new password" subtitle="Choose a strong password for your account.">
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="npass">New password</Label>
          <Input id="npass" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min 8 chars, letters + numbers" />
        </div>
        <Button type="submit" className="w-full bg-brand text-brand-foreground hover:bg-brand/90" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Reset password
        </Button>
      </form>
    </FormShell>
  )
}

function VerifyForm({ token, onSuccess }: { token: string | null; onSuccess: (u: User) => void }) {
  const { toast } = useToast()
  const [state, setState] = useState<'loading' | 'success' | 'error'>(() => (token ? 'loading' : 'error'))

  useEffect(() => {
    if (!token) return
    let active = true
    api<{ ok: boolean }>('/api/auth/verify-email', { method: 'POST', body: { token } })
      .then(() => {
        if (!active) return
        setState('success')
        toast({ title: 'Email verified!' })
        api<{ user: User | null }>('/api/auth/me').then(({ user }) => { if (user) onSuccess(user) })
      })
      .catch(() => { if (active) setState('error') })
    return () => { active = false }
  }, [token, toast, onSuccess])

  return (
    <FormShell title="Verifying your email" subtitle="Hang tight while we confirm your address.">
      {state === 'loading' && <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Verifying…</div>}
      {state === 'success' && <div className="flex items-center gap-3 rounded-lg border border-brand/30 bg-brand/10 p-4"><MailCheck className="h-5 w-5 text-brand" /><p className="text-sm">Your email is verified. Redirecting…</p></div>}
      {state === 'error' && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive">This verification link is invalid or expired.</div>}
    </FormShell>
  )
}
