import { ReactNode } from 'react'
import { MarketingHeader, MarketingFooter } from './layout'

export function MarketingPage({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-[100dvh] flex-col">
      <MarketingHeader />
      <main className="flex-1">{children}</main>
      <MarketingFooter />
    </div>
  )
}
