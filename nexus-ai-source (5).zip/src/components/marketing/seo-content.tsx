import Link from 'next/link'
import { Sparkles, Brain, Globe, ShieldCheck, Zap, Search, Languages, MessageSquare } from 'lucide-react'
import { PRODUCT, FEATURES, FAQS } from '@/lib/seo/product-info'

export function SeoContent() {
  return (
    <div className="seo-content min-h-[100dvh] bg-background">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="pointer-events-none absolute -right-32 top-1/4 h-96 w-96 rounded-full bg-brand/10 blur-3xl" />
        <div className="pointer-events-none absolute -left-20 bottom-10 h-72 w-72 rounded-full bg-brand/5 blur-3xl" />
        <div className="relative mx-auto flex max-w-4xl flex-col items-center px-4 py-20 text-center sm:py-28">
          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand text-brand-foreground shadow-lg shadow-brand/20">
            <Sparkles className="h-8 w-8" />
          </div>
          <h1 className="text-fluid-xl font-bold tracking-tight">
            {PRODUCT.name} — {PRODUCT.tagline}
          </h1>
          <p className="mt-4 max-w-2xl text-fluid-md text-muted-foreground">
            {PRODUCT.description}
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/"
              className="rounded-xl bg-brand px-6 py-2.5 text-sm font-medium text-brand-foreground transition-colors hover:bg-brand/90"
            >
              Start Chatting
            </Link>
            <Link
              href="/about"
              className="rounded-xl border border-border px-6 py-2.5 text-sm font-medium transition-colors hover:bg-muted"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* What is Nexus AI — direct factual answer for AI search */}
      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6">
        <h2 className="text-fluid-lg font-bold tracking-tight">What is {PRODUCT.name}?</h2>
        <p className="mt-4 text-base leading-relaxed text-muted-foreground">
          {PRODUCT.name} is an independent AI conversational platform that combines streaming AI chat,
          live web research with source citations, and persistent long-term memory. It is built on Neon
          PostgreSQL and uses a provider-agnostic architecture, meaning the underlying AI model (OpenAI,
          Anthropic, Ollama, or any OpenAI-compatible endpoint) can be changed through configuration
          without modifying the application. {PRODUCT.name} searches the internet when fresh information
          is needed, remembers useful context across conversations, and provides accurate, cited answers.
        </p>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6">
        <h2 className="text-fluid-lg font-bold tracking-tight">Key Features</h2>
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feature) => (
            <Link
              key={feature.slug}
              href={`/features/${feature.slug}`}
              className="group rounded-xl border border-border bg-card p-5 transition-colors hover:border-brand/40"
            >
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-brand/10 text-brand">
                <FeatureIcon slug={feature.slug} />
              </div>
              <h3 className="font-semibold">{feature.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{feature.description}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Use Cases */}
      <section className="border-y border-border bg-muted/20">
        <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6">
          <h2 className="text-fluid-lg font-bold tracking-tight">Who Uses {PRODUCT.name}?</h2>
          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { label: 'Students', desc: 'Research and study with cited sources' },
              { label: 'Developers', desc: 'Code assistance and technical research' },
              { label: 'Researchers', desc: 'Authority-ranked academic sources' },
              { label: 'Content Creators', desc: 'Brainstorm with persistent context' },
              { label: 'Business', desc: 'Secure, private AI with RBAC' },
            ].map((uc) => (
              <Link
                key={uc.label}
                href={`/use-cases/${uc.label.toLowerCase().replace(/\s+/g, '-')}`}
                className="rounded-xl border border-border bg-card p-4 transition-colors hover:border-brand/40"
              >
                <h3 className="font-medium">{uc.label}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{uc.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ — factual Q&A for AI search engines */}
      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h2 className="text-fluid-lg font-bold tracking-tight">Frequently Asked Questions</h2>
        <div className="mt-8 space-y-4">
          {FAQS.map((faq) => (
            <div key={faq.question} className="rounded-lg border border-border bg-card p-4">
              <h3 className="font-medium">{faq.question}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{faq.answer}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center">
          <Link href="/faq" className="text-sm font-medium text-brand hover:underline">
            View all FAQs →
          </Link>
        </div>
      </section>

      {/* Security & Privacy trust signals */}
      <section className="border-t border-border bg-muted/20">
        <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6">
          <h2 className="text-fluid-lg font-bold tracking-tight">Security & Privacy</h2>
          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
              <div>
                <h3 className="font-medium">Enterprise-Grade Security</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Bcrypt password hashing, HTTP-only sessions, CSRF protection, rate limiting, RBAC,
                  and hashed token storage.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
              <Brain className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
              <div>
                <h3 className="font-medium">Private Memory</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Memories are isolated per user. Sensitive data (passwords, keys, tokens) is never
                  stored. You control what is remembered.
                </p>
              </div>
            </div>
          </div>
          <div className="mt-6">
            <Link href="/docs/security" className="text-sm font-medium text-brand hover:underline">
              Read the security documentation →
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

function FeatureIcon({ slug }: { slug: string }) {
  switch (slug) {
    case 'ai-chat': return <MessageSquare className="h-5 w-5" />
    case 'web-research': return <Globe className="h-5 w-5" />
    case 'memory': return <Brain className="h-5 w-5" />
    case 'ai-search': return <Search className="h-5 w-5" />
    case 'multilingual': return <Languages className="h-5 w-5" />
    default: return <Zap className="h-5 w-5" />
  }
}
