'use client'

import { useEffect, useState, useCallback } from 'react'
import { useApp } from '@/lib/store'
import { api, ApiError } from '@/lib/api-client'
import type { UserSettings, Memory, User } from '@/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog'
import { ArrowLeft, Loader2, Trash2, Brain, User as UserIcon, Sliders, Palette, ShieldAlert, Mail } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { useTheme } from 'next-themes'
import { cn } from '@/lib/utils'

export function SettingsView() {
  const { setView } = useApp()
  return (
    <div className="flex h-full flex-col">
      <header className="flex h-14 items-center gap-2 border-b border-border px-4">
        <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => setView('chat')}><ArrowLeft className="h-4 w-4" /></Button>
        <h2 className="text-sm font-medium">Settings</h2>
      </header>
      <ScrollArea className="flex-1">
        <div className="mx-auto max-w-3xl px-4 py-6">
          <Tabs defaultValue="profile">
            <TabsList className="mb-6 flex w-full justify-start overflow-x-auto">
              <TabsTrigger value="profile" className="gap-1.5"><UserIcon className="h-4 w-4" /> Profile</TabsTrigger>
              <TabsTrigger value="ai" className="gap-1.5"><Sliders className="h-4 w-4" /> AI</TabsTrigger>
              <TabsTrigger value="memory" className="gap-1.5"><Brain className="h-4 w-4" /> Memory</TabsTrigger>
              <TabsTrigger value="appearance" className="gap-1.5"><Palette className="h-4 w-4" /> Appearance</TabsTrigger>
              <TabsTrigger value="privacy" className="gap-1.5"><ShieldAlert className="h-4 w-4" /> Privacy</TabsTrigger>
            </TabsList>
            <TabsContent value="profile"><ProfileTab /></TabsContent>
            <TabsContent value="ai"><AITab /></TabsContent>
            <TabsContent value="memory"><MemoryTab /></TabsContent>
            <TabsContent value="appearance"><AppearanceTab /></TabsContent>
            <TabsContent value="privacy"><PrivacyTab /></TabsContent>
          </Tabs>
        </div>
      </ScrollArea>
    </div>
  )
}

function ProfileTab() {
  const { user, setUser } = useApp()
  const { toast } = useToast()
  const [form, setForm] = useState({ name: user?.name ?? '', email: user?.email ?? '' })
  const [loading, setLoading] = useState(false)

  const save = async () => {
    setLoading(true)
    try {
      const { profile } = await api<{ profile: User }>('/api/profile', { method: 'PATCH', body: form })
      setUser({ ...profile, role: user!.role })
      toast({ title: 'Profile updated' })
    } catch (e) {
      toast({ title: 'Update failed', description: e instanceof ApiError ? e.message : undefined, variant: 'destructive' })
    } finally { setLoading(false) }
  }

  return (
    <Card>
      <CardHeader><CardTitle>Profile</CardTitle><CardDescription>Update your personal information.</CardDescription></CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="name">Full name</Label>
          <Input id="name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
          {user && !user.emailVerified && (
            <p className="flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-500">
              <Mail className="h-3.5 w-3.5" /> Your email is not verified yet.
            </p>
          )}
        </div>
        <Button onClick={save} disabled={loading} className="bg-brand text-brand-foreground hover:bg-brand/90">
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Save changes
        </Button>
      </CardContent>
    </Card>
  )
}

function AITab() {
  const { toast } = useToast()
  const [settings, setSettings] = useState<UserSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [tierLabel, setTierLabel] = useState<string>('Assistant')

  useEffect(() => {
    Promise.all([
      api<{ settings: UserSettings }>('/api/settings'),
      api<{ tierLabel: string | null }>('/api/ai/status'),
    ])
      .then(([{ settings }, { tierLabel }]) => {
        setSettings(settings)
        setTierLabel(tierLabel ?? 'Assistant')
      })
      .finally(() => setLoading(false))
  }, [])

  const update = async (patch: Partial<UserSettings>) => {
    setSaving(true)
    try {
      const { settings: updated } = await api<{ settings: UserSettings }>('/api/settings', { method: 'PATCH', body: patch })
      setSettings(updated)
    } catch (e) {
      toast({ title: 'Save failed', description: e instanceof ApiError ? e.message : undefined, variant: 'destructive' })
    } finally { setSaving(false) }
  }

  if (loading || !settings) return <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader><CardTitle>Model & behaviour</CardTitle><CardDescription>Control how Nexus AI responds.</CardDescription></CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-1.5">
            <Label>Active model</Label>
            <div className="flex flex-col gap-2 rounded-lg border border-border bg-muted/40 px-3 py-2.5 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <div className="text-sm font-medium">Nexus AI • {tierLabel}</div>
                <div className="truncate text-xs text-muted-foreground">
                  {settings.model
                    ? `Using your override: ${settings.model}`
                    : 'Using the server-configured model'}
                </div>
              </div>
              {settings.model && (
                <Button variant="outline" size="sm" className="shrink-0" onClick={() => update({ model: null })}>
                  Use server default
                </Button>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              The underlying AI model is configured by your administrator. You can override it below
              if you know the exact model id for the active provider.
            </p>
            <Input
              value={settings.model ?? ''}
              onChange={(e) => setSettings({ ...settings, model: e.target.value || null })}
              onBlur={(e) => {
                const v = e.target.value.trim() || null
                if (v !== settings.model) update({ model: v })
              }}
              placeholder="(server default)"
              className="mt-1"
            />
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between"><Label>Temperature</Label><span className="text-sm text-muted-foreground">{settings.temperature.toFixed(2)}</span></div>
            <Slider value={[settings.temperature]} min={0} max={2} step={0.05} onValueChange={([v]) => setSettings({ ...settings, temperature: v })} onValueCommit={([v]) => update({ temperature: v })} />
            <p className="text-xs text-muted-foreground">Lower = focused & deterministic. Higher = creative & varied.</p>
          </div>
          <div className="space-y-1.5">
            <Label>Response style</Label>
            <Select value={settings.responseStyle} onValueChange={(v: any) => update({ responseStyle: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="concise">Concise</SelectItem>
                <SelectItem value="balanced">Balanced</SelectItem>
                <SelectItem value="detailed">Detailed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Interface language</Label>
            <Select value={settings.language} onValueChange={(v: any) => update({ language: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
                <SelectItem value="ar">العربية</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Capabilities</CardTitle><CardDescription>Toggle intelligent features.</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          <ToggleRow title="Long-term memory" desc="Remember useful facts about you across conversations." checked={settings.memoryEnabled} onCheckedChange={(v) => update({ memoryEnabled: v })} />
          <ToggleRow title="Web research" desc="Let the AI search the internet when fresh information is needed." checked={settings.webSearchEnabled} onCheckedChange={(v) => update({ webSearchEnabled: v })} />
        </CardContent>
      </Card>
      {saving && <p className="text-xs text-muted-foreground">Saving…</p>}
    </div>
  )
}

function MemoryTab() {
  const { toast } = useToast()
  const [memories, setMemories] = useState<Memory[]>([])
  const [enabled, setEnabled] = useState(true)
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    api<{ memories: Memory[]; memoryEnabled: boolean }>('/api/memories')
      .then(({ memories, memoryEnabled }) => { setMemories(memories); setEnabled(memoryEnabled) })
      .finally(() => setLoading(false))
  }, [])
  useEffect(() => { load() }, [load])

  const del = async (id: string) => {
    await api(`/api/memories/${id}`, { method: 'DELETE' })
    setMemories((m) => m.filter((x) => x.id !== id))
  }
  const clearAll = async () => {
    await api('/api/memories?all=true', { method: 'DELETE' })
    setMemories([])
    toast({ title: 'All memories cleared' })
  }
  const toggle = async (v: boolean) => {
    setEnabled(v)
    await api('/api/settings', { method: 'PATCH', body: { memoryEnabled: v } })
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div><CardTitle>Long-term memory</CardTitle><CardDescription>{memories.length} memories stored</CardDescription></div>
          <Switch checked={enabled} onCheckedChange={toggle} />
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Nexus extracts durable facts (your name, projects, preferences) to improve future conversations.
            Sensitive data like passwords or API keys is never stored. You have full control below.
          </p>
          {memories.length > 0 && (
            <Button variant="outline" size="sm" className="mt-4 text-destructive" onClick={clearAll}>
              <Trash2 className="mr-2 h-4 w-4" /> Clear all memories
            </Button>
          )}
        </CardContent>
      </Card>

      {loading ? (
        <div className="flex justify-center py-6"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
      ) : (
        <div className="space-y-2">
          {memories.map((m) => (
            <Card key={m.id}>
              <CardContent className="flex items-start gap-3 py-3">
                <span className="mt-0.5 rounded bg-brand/15 px-1.5 py-0.5 text-[10px] uppercase text-brand">{m.memoryType}</span>
                <p className="flex-1 text-sm">{m.content}</p>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => del(m.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
              </CardContent>
            </Card>
          ))}
          {!loading && memories.length === 0 && (
            <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
              No memories yet. They appear as you chat and share useful context.
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function AppearanceTab() {
  const { theme, setTheme } = useTheme()

  const saveTheme = async (t: string) => {
    setTheme(t)
    try { await api('/api/settings', { method: 'PATCH', body: { theme: t as any } }) } catch {}
  }

  const themes = [
    { id: 'light', label: 'Light', desc: 'Bright & clean' },
    { id: 'dark', label: 'Dark', desc: 'Easy on the eyes' },
    { id: 'system', label: 'System', desc: 'Follow your device' },
  ]

  return (
    <Card>
      <CardHeader><CardTitle>Appearance</CardTitle><CardDescription>Choose how Nexus looks.</CardDescription></CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {themes.map((t) => (
            <button
              key={t.id}
              onClick={() => saveTheme(t.id)}
              className={cn(
                'flex items-center gap-3 rounded-xl border-2 p-3 text-left transition-colors sm:block',
                theme === t.id ? 'border-brand bg-brand/5' : 'border-border hover:border-border/80',
              )}
            >
              <div className={cn('mb-0 h-10 w-10 shrink-0 rounded-md sm:mb-2 sm:h-12 sm:w-full', t.id === 'light' ? 'bg-background border border-border' : t.id === 'dark' ? 'bg-zinc-900' : 'bg-gradient-to-br from-background to-zinc-900')} />
              <div className="min-w-0">
                <div className="text-sm font-medium">{t.label}</div>
                <div className="text-xs text-muted-foreground">{t.desc}</div>
              </div>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

function PrivacyTab() {
  const { logout } = useApp()
  const { toast } = useToast()
  const [confirmText, setConfirmText] = useState('')
  const [deleting, setDeleting] = useState(false)

  const del = async () => {
    setDeleting(true)
    try {
      await api('/api/account', { method: 'POST', body: { confirm: 'DELETE' } })
      toast({ title: 'Account deleted' })
      logout()
    } catch (e) {
      toast({ title: 'Deletion failed', description: e instanceof ApiError ? e.message : undefined, variant: 'destructive' })
    } finally { setDeleting(false) }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader><CardTitle>Data & privacy</CardTitle><CardDescription>Your data belongs to you.</CardDescription></CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• Your conversations, messages and memories are stored securely in Neon PostgreSQL and isolated to your account.</p>
          <p>• Passwords are hashed with bcrypt (12 rounds) — they are never stored in plain text.</p>
          <p>• Sessions use opaque tokens in HTTP-only cookies and expire automatically.</p>
          <p>• You can export or delete all your data at any time.</p>
        </CardContent>
      </Card>
      <Card className="border-destructive/40">
        <CardHeader><CardTitle className="text-destructive">Danger zone</CardTitle><CardDescription>Permanently delete your account and all associated data.</CardDescription></CardHeader>
        <CardContent>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive">Delete my account</Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete account permanently?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently remove your account, conversations, messages, memories, and settings.
                  This action cannot be undone. Type <strong>DELETE</strong> to confirm.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <Input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="DELETE" />
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setConfirmText('')}>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  disabled={confirmText !== 'DELETE' || deleting}
                  onClick={del}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  {deleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Delete forever
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  )
}

function ToggleRow({ title, desc, checked, onCheckedChange }: { title: string; desc: string; checked: boolean; onCheckedChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <div className="text-sm font-medium">{title}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  )
}
