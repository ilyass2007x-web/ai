'use client'

import { useState } from 'react'
import { useApp } from '@/lib/store'
import { api, ApiError } from '@/lib/api-client'
import type { Conversation } from '@/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose,
} from '@/components/ui/dialog'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Plus, Search, MessageSquare, Archive, Settings, LogOut, Trash2, Pencil,
  Pin, PinOff, ChevronDown, ChevronRight, PanelLeftClose, Sparkles, ShieldAlert, X,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'

export function Sidebar({ onClose }: { onClose?: () => void }) {
  const {
    conversations, currentConversationId, setCurrentConversation,
    upsertConversation, removeConversation, user, setView, logout,
    setSearchQuery,
  } = useApp()
  const { toast } = useToast()
  const [query, setQuery] = useState('')
  const [showArchived, setShowArchived] = useState(false)
  const [renaming, setRenaming] = useState<Conversation | null>(null)
  const [newTitle, setNewTitle] = useState('')

  const filtered = conversations.filter((c) =>
    c.title.toLowerCase().includes(query.toLowerCase()),
  )
  const pinned = filtered.filter((c) => c.pinned && !c.archived)
  const recent = filtered.filter((c) => !c.pinned && !c.archived)
  const archived = filtered.filter((c) => c.archived)

  const submitSearch = () => {
    if (!query.trim()) return
    setSearchQuery(query.trim())
    setView('search')
  }

  const newChat = async () => {
    setCurrentConversation(null)
    onClose?.()
  }

  const doRename = async () => {
    if (!renaming || !newTitle.trim()) return
    try {
      const { conversation } = await api<{ conversation: Conversation }>(
        `/api/conversations/${renaming.id}`,
        { method: 'PATCH', body: { title: newTitle.trim() } },
      )
      upsertConversation(conversation)
      setRenaming(null)
    } catch (e) {
      toast({ title: 'Rename failed', description: e instanceof ApiError ? e.message : undefined, variant: 'destructive' })
    }
  }

  const togglePin = async (c: Conversation) => {
    try {
      const { conversation } = await api<{ conversation: Conversation }>(`/api/conversations/${c.id}`, {
        method: 'PATCH', body: { pinned: !c.pinned },
      })
      upsertConversation(conversation)
    } catch {}
  }

  const archive = async (c: Conversation) => {
    try {
      const { conversation } = await api<{ conversation: Conversation }>(`/api/conversations/${c.id}`, {
        method: 'PATCH', body: { archived: !c.archived },
      })
      upsertConversation(conversation)
    } catch {}
  }

  const del = async (c: Conversation) => {
    if (!confirm('Delete this conversation permanently?')) return
    try {
      await api(`/api/conversations/${c.id}`, { method: 'DELETE' })
      removeConversation(c.id)
      if (currentConversationId === c.id) setCurrentConversation(null)
    } catch (e) {
      toast({ title: 'Delete failed', variant: 'destructive' })
    }
  }

  return (
    <div className="flex h-full w-full flex-col bg-sidebar text-sidebar-foreground">
      {/* Header */}
      <div className="flex items-center gap-2 p-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-brand-foreground">
          <Sparkles className="h-4 w-4" />
        </div>
        <span className="flex-1 text-lg font-semibold tracking-tight">Nexus AI</span>
        {onClose && (
          <Button variant="ghost" size="icon" className="h-8 w-8 lg:hidden" onClick={onClose} aria-label="Close sidebar">
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* New chat */}
      <div className="px-3 pb-2">
        <Button onClick={newChat} className="w-full justify-start gap-2 bg-brand text-brand-foreground hover:bg-brand/90">
          <Plus className="h-4 w-4" /> New chat
        </Button>
      </div>

      {/* Search */}
      <div className="px-3 pb-2">
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') submitSearch() }}
            placeholder="Search conversations (Enter for global search)"
            className="h-9 pl-9"
          />
        </div>
      </div>

      {/* Conversation list */}
      <ScrollArea className="flex-1 px-2">
        <div className="space-y-1 pb-4">
          {pinned.length > 0 && (
            <Section label="Pinned" icon={<Pin className="h-3 w-3" />}>
              {pinned.map((c) => (
                <ConvItem
                  key={c.id}
                  c={c}
                  active={c.id === currentConversationId}
                  onClick={() => { setCurrentConversation(c.id); onClose?.() }}
                  onRename={() => { setRenaming(c); setNewTitle(c.title) }}
                  onPin={() => togglePin(c)}
                  onArchive={() => archive(c)}
                  onDelete={() => del(c)}
                />
              ))}
            </Section>
          )}

          {recent.length > 0 && (
            <Section label="Recent">
              {recent.map((c) => (
                <ConvItem
                  key={c.id}
                  c={c}
                  active={c.id === currentConversationId}
                  onClick={() => { setCurrentConversation(c.id); onClose?.() }}
                  onRename={() => { setRenaming(c); setNewTitle(c.title) }}
                  onPin={() => togglePin(c)}
                  onArchive={() => archive(c)}
                  onDelete={() => del(c)}
                />
              ))}
            </Section>
          )}

          {archived.length > 0 && (
            <div>
              <button
                onClick={() => setShowArchived((s) => !s)}
                className="flex w-full items-center gap-1 px-2 py-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground hover:text-foreground"
              >
                {showArchived ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                Archived ({archived.length})
              </button>
              {showArchived && archived.map((c) => (
                <ConvItem
                  key={c.id}
                  c={c}
                  active={c.id === currentConversationId}
                  onClick={() => { setCurrentConversation(c.id); onClose?.() }}
                  onRename={() => { setRenaming(c); setNewTitle(c.title) }}
                  onPin={() => togglePin(c)}
                  onArchive={() => archive(c)}
                  onDelete={() => del(c)}
                />
              ))}
            </div>
          )}

          {conversations.length === 0 && (
            <div className="px-3 py-8 text-center text-sm text-muted-foreground">
              No conversations yet. Start a new chat!
            </div>
          )}
        </div>
      </ScrollArea>

      {/* User footer */}
      <div className="border-t border-sidebar-border p-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left hover:bg-sidebar-accent">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand/15 text-sm font-semibold text-brand">
                {(user?.name?.[0] ?? user?.email?.[0] ?? '?').toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{user?.name ?? 'User'}</div>
                <div className="truncate text-xs text-muted-foreground">{user?.email}</div>
              </div>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="truncate">{user?.email}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setView('settings')}>
              <Settings className="mr-2 h-4 w-4" /> Settings
            </DropdownMenuItem>
            {user?.role === 'admin' && (
              <DropdownMenuItem onClick={() => setView('admin')}>
                <ShieldAlert className="mr-2 h-4 w-4" /> Admin dashboard
              </DropdownMenuItem>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => logout()} className="text-destructive focus:text-destructive">
              <LogOut className="mr-2 h-4 w-4" /> Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Rename dialog */}
      <Dialog open={!!renaming} onOpenChange={(o) => !o && setRenaming(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rename conversation</DialogTitle>
          </DialogHeader>
          <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Conversation title" onKeyDown={(e) => e.key === 'Enter' && doRename()} />
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
            <Button onClick={doRename} className="bg-brand text-brand-foreground hover:bg-brand/90">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function Section({ label, icon, children }: { label: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="mb-1">
      <div className="flex items-center gap-1 px-2 py-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {icon}{label}
      </div>
      <div className="space-y-0.5">{children}</div>
    </div>
  )
}

function ConvItem({
  c, active, onClick, onRename, onPin, onArchive, onDelete,
}: {
  c: Conversation; active: boolean; onClick: () => void
  onRename: () => void; onPin: () => void; onArchive: () => void; onDelete: () => void
}) {
  return (
    <div className="group relative">
      <button
        onClick={onClick}
        className={cn(
          'flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left text-sm transition-colors',
          active ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'hover:bg-sidebar-accent/60',
        )}
      >
        {c.archived ? <Archive className="h-4 w-4 shrink-0 text-muted-foreground" /> : <MessageSquare className="h-4 w-4 shrink-0 text-muted-foreground" />}
        <span className="flex-1 truncate">{c.title}</span>
        {c.pinned && <Pin className="h-3 w-3 text-brand" />}
      </button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="absolute right-1 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground opacity-0 transition-opacity hover:bg-sidebar-accent group-hover:opacity-100 data-[state=open]:opacity-100" aria-label="Conversation options">
            <PanelLeftClose className="h-3.5 w-3.5 rotate-90" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-44">
          <DropdownMenuItem onClick={onRename}><Pencil className="mr-2 h-4 w-4" /> Rename</DropdownMenuItem>
          <DropdownMenuItem onClick={onPin}>{c.pinned ? <><PinOff className="mr-2 h-4 w-4" /> Unpin</> : <><Pin className="mr-2 h-4 w-4" /> Pin</>}</DropdownMenuItem>
          <DropdownMenuItem onClick={onArchive}><Archive className="mr-2 h-4 w-4" /> {c.archived ? 'Unarchive' : 'Archive'}</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive"><Trash2 className="mr-2 h-4 w-4" /> Delete</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
