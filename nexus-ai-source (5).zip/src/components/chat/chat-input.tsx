'use client'

import { useRef, useState, useEffect } from 'react'
import { ArrowUp, Square, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface Props {
  onSend: (content: string) => void
  onStop?: () => void
  isStreaming: boolean
  disabled?: boolean
  placeholder?: string
}

export function ChatInput({ onSend, onStop, isStreaming, disabled, placeholder }: Props) {
  const [value, setValue] = useState('')
  const ref = useRef<HTMLTextAreaElement>(null)

  // Auto-grow
  useEffect(() => {
    const el = ref.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = Math.min(el.scrollHeight, 220) + 'px'
  }, [value])

  const submit = () => {
    const v = value.trim()
    if (!v || disabled || isStreaming) return
    onSend(v)
    setValue('')
  }

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault()
      submit()
    }
  }

  return (
    <div className="border-t border-border bg-background/80 pb-safe backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto w-full max-w-3xl px-3 py-2.5 sm:px-6 sm:py-3">
        <div
          className={cn(
            'relative flex items-end gap-2 rounded-2xl border border-border bg-card px-2.5 py-2 shadow-sm transition-colors focus-within:border-brand/50 sm:px-3',
          )}
        >
          <textarea
            ref={ref}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={onKeyDown}
            rows={1}
            disabled={disabled}
            placeholder={placeholder ?? 'Message Nexus AI…'}
            className="max-h-[200px] flex-1 resize-none bg-transparent px-1 py-1.5 text-[15px] leading-relaxed outline-none placeholder:text-muted-foreground disabled:opacity-50"
          />
          <div className="flex items-center gap-1 pb-0.5">
            {isStreaming ? (
              <Button
                size="icon"
                onClick={onStop}
                className="h-10 w-10 rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90 sm:h-9 sm:w-9"
                aria-label="Stop generating"
              >
                <Square className="h-4 w-4 fill-current" />
              </Button>
            ) : (
              <Button
                size="icon"
                onClick={submit}
                disabled={!value.trim() || disabled}
                className="h-10 w-10 rounded-xl bg-brand text-brand-foreground hover:bg-brand/90 disabled:opacity-40 sm:h-9 sm:w-9"
                aria-label="Send message"
              >
                {disabled ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
              </Button>
            )}
          </div>
        </div>
        <p className="mt-1.5 hidden text-center text-[11px] text-muted-foreground sm:block">
          Press <kbd className="rounded bg-muted px-1 font-mono">Enter</kbd> to send,{' '}
          <kbd className="rounded bg-muted px-1 font-mono">Shift+Enter</kbd> for a new line. Nexus may
          search the web and can make mistakes — check important info.
        </p>
        <p className="mt-1 text-center text-[11px] text-muted-foreground sm:hidden">
          Enter to send · Shift+Enter for new line
        </p>
      </div>
    </div>
  )
}
