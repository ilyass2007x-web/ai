'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { useApp } from '@/lib/store'
import { api, streamChat, ApiError } from '@/lib/api-client'
import type { Message, Conversation, Source } from '@/types'
import { MessageItem } from './message-item'
import { ChatInput } from './chat-input'
import { Button } from '@/components/ui/button'
import {
  Menu, Sparkles, Search as SearchIcon, Brain, Globe, Zap, ArrowLeft,
  Download, Loader2,
} from 'lucide-react'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useToast } from '@/hooks/use-toast'

interface StreamingMsg extends Message {
  isStreaming?: boolean
}

const SUGGESTIONS = [
  { icon: Brain, title: 'Explain a concept', prompt: 'Explain how vector embeddings work, with a simple analogy.' },
  { icon: Zap, title: 'Write some code', prompt: 'Write a TypeScript function to debounce an async call with cancellation.' },
  { icon: Globe, title: 'Research the web', prompt: 'What are the latest developments in PostgreSQL for 2025?' },
  { icon: Sparkles, title: 'Brainstorm ideas', prompt: 'Give me 5 SaaS product ideas that use AI memory and web research.' },
]

export function ChatView() {
  const {
    currentConversationId, conversations, upsertConversation, setCurrentConversation,
    setSidebarOpen, view, setSearchQuery, setView,
  } = useApp()
  const { toast } = useToast()
  const [messages, setMessages] = useState<Message[]>([])
  const [loadingMsgs, setLoadingMsgs] = useState(true)
  const [isStreaming, setIsStreaming] = useState(false)
  const [convLoading, setConvLoading] = useState(false)
  const abortRef = useRef<AbortController | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  const currentConv = conversations.find((c) => c.id === currentConversationId)

  // Load messages when conversation changes. All setState happens inside an
  // async function (after a microtask) so the effect body has no synchronous
  // setState calls — and we do NOT remount the component (so an in-flight
  // send that creates a new conversation keeps its streaming state).
  useEffect(() => {
    let active = true
    void (async () => {
      await Promise.resolve()
      if (!active) return
      if (!currentConversationId) {
        setMessages([])
        setLoadingMsgs(false)
        return
      }
      setLoadingMsgs(true)
      try {
        const { conversation } = await api<{ conversation: { messages: Message[] } }>(
          `/api/conversations/${currentConversationId}`,
        )
        if (active) setMessages(conversation.messages)
      } catch {
        if (active) setMessages([])
      } finally {
        if (active) setLoadingMsgs(false)
      }
    })()
    return () => { active = false }
  }, [currentConversationId])

  // Auto-scroll to bottom on new content.
  useEffect(() => {
    const el = scrollRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [messages])

  const send = async (content: string) => {
    if (isStreaming) return
    setIsStreaming(true)
    setConvLoading(true)

    // Optimistic user message.
    const userMsg: Message = {
      id: 'temp-user-' + Date.now(),
      role: 'user',
      content,
      createdAt: new Date().toISOString(),
    }
    const assistantId = 'temp-assistant-' + Date.now()
    const assistantMsg: StreamingMsg = {
      id: assistantId,
      role: 'assistant',
      content: '',
      createdAt: new Date().toISOString(),
      isStreaming: true,
    }
    setMessages((m) => [...m, userMsg, assistantMsg])

    const controller = new AbortController()
    abortRef.current = controller

    let firstDelta = true
    await streamChat(
      '/api/chat',
      { conversationId: currentConversationId ?? undefined, content },
      {
        onMeta: (meta) => {
          setConvLoading(false)
          if (meta.conversationId && meta.conversationId !== currentConversationId) {
            // New conversation was created on the server.
            const newConv: Conversation = {
              id: meta.conversationId,
              title: content.slice(0, 60),
              archived: false,
              pinned: false,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            }
            upsertConversation(newConv)
            setCurrentConversation(meta.conversationId)
          } else if (currentConversationId) {
            // Bump updatedAt by re-fetching conversation meta later (non-critical).
          }
          const sources: Source[] = meta.sources ?? []
          setMessages((m) =>
            m.map((msg) =>
              msg.id === assistantId
                ? { ...msg, sources: sources.map((s) => ({ source: s })) }
                : msg,
            ),
          )
        },
        onDelta: (delta) => {
          if (firstDelta) { firstDelta = false; setConvLoading(false) }
          setMessages((m) =>
            m.map((msg) =>
              msg.id === assistantId
                ? { ...msg, content: msg.content + delta }
                : msg,
            ),
          )
        },
        onDone: () => {
          setMessages((m) =>
            m.map((msg) => (msg.id === assistantId ? { ...msg, isStreaming: false } : msg)),
          )
        },
        onError: (message) => {
          setConvLoading(false)
          setMessages((m) =>
            m.map((msg) =>
              msg.id === assistantId
                ? { ...msg, content: msg.content || `⚠️ ${message}`, isStreaming: false }
                : msg,
            ),
          )
          toast({ title: 'Generation error', description: message, variant: 'destructive' })
        },
      },
      controller.signal,
    ).finally(() => {
      setIsStreaming(false)
      setConvLoading(false)
      abortRef.current = null
      // Replace temp ids with real ones by reloading the conversation messages.
      if (currentConversationId || useApp.getState().currentConversationId) {
        const cid = useApp.getState().currentConversationId
        if (cid) {
          api<{ conversation: { messages: Message[] } }>(`/api/conversations/${cid}`)
            .then(({ conversation }) => setMessages(conversation.messages))
            .catch(() => {})
        }
      }
    })
  }

  const stop = () => {
    abortRef.current?.abort()
    abortRef.current = null
    setIsStreaming(false)
    setConvLoading(false)
    setMessages((m) => m.map((msg) =>
      (msg as StreamingMsg).isStreaming
        ? { ...msg, isStreaming: false, content: msg.content || '*(stopped)*' }
        : msg,
    ))
  }

  const regenerate = useCallback(async (assistantMessageId: string) => {
    if (isStreaming || !currentConversationId) return
    // Find the assistant message and everything after it; remove locally.
    const idx = messages.findIndex((m) => m.id === assistantMessageId)
    if (idx === -1) return
    const kept = messages.slice(0, idx)
    setMessages(kept)

    setIsStreaming(true)
    const newId = 'temp-assistant-' + Date.now()
    setMessages((m) => [...m, { id: newId, role: 'assistant', content: '', createdAt: new Date().toISOString(), isStreaming: true }])

    const controller = new AbortController()
    abortRef.current = controller
    let firstDelta = true
    await streamChat(
      '/api/chat/regenerate',
      { conversationId: currentConversationId, messageId: assistantMessageId },
      {
        onMeta: (meta) => {
          const sources: Source[] = meta.sources ?? []
          setMessages((m) => m.map((msg) => msg.id === newId ? { ...msg, sources: sources.map((s) => ({ source: s })) } : msg))
        },
        onDelta: (delta) => {
          if (firstDelta) firstDelta = false
          setMessages((m) => m.map((msg) => msg.id === newId ? { ...msg, content: msg.content + delta } : msg))
        },
        onDone: () => setMessages((m) => m.map((msg) => msg.id === newId ? { ...msg, isStreaming: false } : msg)),
        onError: (message) => {
          setMessages((m) => m.map((msg) => msg.id === newId ? { ...msg, content: msg.content || `⚠️ ${message}`, isStreaming: false } : msg))
          toast({ title: 'Regeneration error', description: message, variant: 'destructive' })
        },
      },
      controller.signal,
    ).finally(() => {
      setIsStreaming(false)
      abortRef.current = null
      const cid = useApp.getState().currentConversationId
      if (cid) {
        api<{ conversation: { messages: Message[] } }>(`/api/conversations/${cid}`)
          .then(({ conversation }) => setMessages(conversation.messages)).catch(() => {})
      }
    })
  }, [isStreaming, currentConversationId, messages, toast])

  const exportConv = (format: 'markdown' | 'txt' | 'json') => {
    if (!currentConversationId) return
    window.open(`/api/conversations/${currentConversationId}/export?format=${format}`, '_blank')
  }

  // ── Search results view ──────────────────────────────────────
  const searchQuery = useApp((s) => s.searchQuery)
  const [searchResults, setSearchResults] = useState<{ conversations: any[]; messages: any[]; memories: any[] } | null>(null)
  const [searching, setSearching] = useState(false)
  useEffect(() => {
    if (view !== 'search' || !searchQuery) {
      return
    }
    let active = true
    const t = setTimeout(() => {
      setSearching(true)
      api<{ conversations: any[]; messages: any[]; memories: any[] }>('/api/search', {
        method: 'POST', body: { q: searchQuery },
      })
        .then((r) => { if (active) setSearchResults(r) })
        .catch(() => { if (active) setSearchResults(null) })
        .finally(() => { if (active) setSearching(false) })
    }, 250)
    return () => { active = false; clearTimeout(t) }
  }, [view, searchQuery])

  if (view === 'search') {
    return <SearchView query={searchQuery} results={searchResults} searching={searching} onOpenConv={(id) => setCurrentConversation(id)} onBack={() => setView('chat')} />
  }

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <header className="flex h-14 items-center gap-2 border-b border-border bg-background/80 px-3 backdrop-blur">
        <Button variant="ghost" size="icon" className="h-9 w-9 lg:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open sidebar">
          <Menu className="h-5 w-5" />
        </Button>
        <div className="min-w-0 flex-1">
          <h2 className="truncate text-sm font-medium">{currentConv?.title ?? 'New chat'}</h2>
        </div>
        {currentConversationId && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9" aria-label="Export"><Download className="h-4 w-4" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => exportConv('markdown')}>Export as Markdown</DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportConv('txt')}>Export as Text</DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportConv('json')}>Export as JSON</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </header>

      {/* Messages */}
      <div ref={scrollRef} className="scrollbar-thin flex-1 overflow-y-auto">
        {!currentConversationId && messages.length === 0 ? (
          <EmptyState onPick={send} />
        ) : loadingMsgs ? (
          <div className="flex h-full items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
        ) : (
          <div className="mx-auto w-full max-w-3xl divide-y divide-border/50">
            {messages.map((m) => (
              <MessageItem
                key={m.id}
                message={m}
                isStreaming={(m as StreamingMsg).isStreaming}
                onRegenerate={m.role === 'assistant' ? () => regenerate(m.id) : undefined}
              />
            ))}
          </div>
        )}
      </div>

      {/* Input */}
      <ChatInput onSend={send} onStop={stop} isStreaming={isStreaming || convLoading} disabled={false} />
    </div>
  )
}

function EmptyState({ onPick }: { onPick: (prompt: string) => void }) {
  return (
    <div className="mx-auto flex min-h-full max-w-2xl flex-col items-center justify-center px-4 py-8 text-center sm:py-10">
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-brand text-brand-foreground shadow-lg shadow-brand/20 sm:mb-5 sm:h-14 sm:w-14">
        <Sparkles className="h-6 w-6 sm:h-7 sm:w-7" />
      </div>
      <h1 className="text-fluid-xl font-bold tracking-tight">How can I help you today?</h1>
      <p className="mt-2 max-w-md text-sm text-muted-foreground sm:text-base">
        Ask anything. I&apos;ll search the web when fresh information is needed, cite my sources, and
        remember what matters across conversations.
      </p>
      <div className="mt-6 grid w-full grid-cols-1 gap-2 sm:mt-8 sm:grid-cols-2">
        {SUGGESTIONS.map((s) => (
          <button
            key={s.title}
            onClick={() => onPick(s.prompt)}
            className="group flex items-start gap-2.5 rounded-xl border border-border bg-card p-2.5 text-left transition-colors hover:border-brand/40 hover:bg-muted/40 sm:gap-3 sm:p-3"
          >
            <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-brand/10 text-brand">
              <s.icon className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-medium">{s.title}</div>
              <div className="text-xs text-muted-foreground line-clamp-2">{s.prompt}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

function SearchView({ query, results, searching, onOpenConv, onBack }: {
  query: string; results: { conversations: any[]; messages: any[]; memories: any[] } | null
  searching: boolean; onOpenConv: (id: string) => void; onBack: () => void
}) {
  return (
    <div className="flex h-full flex-col">
      <header className="flex h-14 items-center gap-2 border-b border-border px-3 sm:px-4">
        <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={onBack}><ArrowLeft className="h-4 w-4" /></Button>
        <SearchIcon className="h-4 w-4 shrink-0 text-muted-foreground" />
        <span className="min-w-0 truncate text-sm">Results for <span className="font-medium">&ldquo;{query}&rdquo;</span></span>
      </header>
      <div className="scrollbar-thin flex-1 overflow-y-auto p-3 sm:p-4">
        <div className="mx-auto max-w-2xl space-y-6">
          {searching && <div className="flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>}
          {!searching && results && (
            <>
              <SearchSection title="Conversations" count={results.conversations.length}>
                {results.conversations.map((c) => (
                  <button key={c.id} onClick={() => onOpenConv(c.id)} className="block w-full rounded-lg border border-border bg-card p-3 text-left hover:bg-muted/40">
                    <div className="truncate font-medium">{c.title}</div>
                  </button>
                ))}
              </SearchSection>
              <SearchSection title="Messages" count={results.messages.length}>
                {results.messages.map((m: any) => (
                  <button key={m.id} onClick={() => onOpenConv(m.conversation.id)} className="block w-full rounded-lg border border-border bg-card p-3 text-left hover:bg-muted/40">
                    <div className="truncate text-xs text-muted-foreground">{m.conversation.title} · {m.role}</div>
                    <div className="line-clamp-3 text-sm">{m.content}</div>
                  </button>
                ))}
              </SearchSection>
              <SearchSection title="Memories" count={results.memories.length}>
                {results.memories.map((m: any) => (
                  <div key={m.id} className="rounded-lg border border-border bg-card p-3">
                    <span className="mr-2 rounded bg-brand/15 px-1.5 py-0.5 text-[10px] text-brand">{m.memoryType}</span>
                    <span className="text-sm">{m.content}</span>
                  </div>
                ))}
              </SearchSection>
              {results.conversations.length + results.messages.length + results.memories.length === 0 && (
                <div className="py-10 text-center text-muted-foreground">No results found.</div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

function SearchSection({ title, count, children }: { title: string; count: number; children: React.ReactNode }) {
  if (count === 0) return null
  return (
    <div>
      <h3 className="mb-2 text-sm font-semibold">{title} <span className="text-muted-foreground">({count})</span></h3>
      <div className="space-y-2">{children}</div>
    </div>
  )
}
