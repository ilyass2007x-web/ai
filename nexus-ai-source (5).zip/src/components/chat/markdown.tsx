'use client'

import { memo, useState } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { PrismAsyncLight as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism'
import {
  jsx, typescript, javascript, bash, python, json, css, markup, sql, go, rust, java, yaml, markdown as md,
} from 'react-syntax-highlighter/dist/esm/languages/prism'
import { useTheme } from 'next-themes'
import { Check, Copy } from 'lucide-react'

// Register only the languages we actually need (keeps the bundle small).
const LANGS: Record<string, any> = {
  jsx, tsx: typescript, ts: typescript, typescript,
  javascript, js: javascript,
  bash, sh: bash, shell: bash,
  python, py: python,
  json, css, html: markup, xml: markup, markup,
  sql, go, rust, rs: rust, java, yaml, yml: yaml,
  markdown: md, md,
}
for (const [name, mod] of Object.entries(LANGS)) {
  if (mod) SyntaxHighlighter.registerLanguage(name, mod)
}

interface Props {
  content: string
  className?: string
}

function CodeBlock({ language, code }: { language: string; code: string }) {
  const { resolvedTheme } = useTheme()
  const [copied, setCopied] = useState(false)
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {}
  }
  return (
    <div className="group relative my-3 overflow-hidden rounded-lg border border-border bg-muted/40">
      <div className="flex items-center justify-between border-b border-border bg-muted/60 px-2.5 py-1.5 text-xs sm:px-3">
        <span className="truncate font-mono text-muted-foreground">{language || 'code'}</span>
        <button
          onClick={copy}
          className="flex shrink-0 items-center gap-1 text-muted-foreground transition-colors hover:text-foreground"
          aria-label="Copy code"
        >
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <div className="table-wrap">
        <SyntaxHighlighter
          language={LANGS[language] ? language : 'markup'}
          style={resolvedTheme === 'dark' ? oneDark : oneLight}
          customStyle={{
            margin: 0,
            background: 'transparent',
            padding: '0.75rem 0.875rem',
            fontSize: '0.8125rem',
            lineHeight: 1.55,
          }}
          codeTagProps={{ style: { fontFamily: 'var(--font-geist-mono), monospace' } }}
        >
          {code}
        </SyntaxHighlighter>
      </div>
    </div>
  )
}

export const Markdown = memo(function Markdown({ content }: Props) {
  return (
    <div className="prose prose-sm dark:prose-invert max-w-none prose-pre:m-0 prose-pre:bg-transparent prose-pre:p-0 prose-code:before:content-none prose-code:after:content-none">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          code({ className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || '')
            const text = String(children ?? '')
            const isBlock = text.includes('\n') || !!match
            if (isBlock) {
              return <CodeBlock language={match?.[1] ?? ''} code={text.replace(/\n$/, '')} />
            }
            return (
              <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-[0.85em]" {...props}>
                {children}
              </code>
            )
          },
          a({ href, children, ...props }) {
            return (
              <a href={href} target="_blank" rel="noopener noreferrer" className="text-brand underline underline-offset-2 hover:opacity-80" {...props}>
                {children}
              </a>
            )
          },
          ul({ children }) {
            return <ul className="my-2 list-disc space-y-1 pl-5">{children}</ul>
          },
          ol({ children }) {
            return <ol className="my-2 list-decimal space-y-1 pl-5">{children}</ol>
          },
          blockquote({ children }) {
            return <blockquote className="my-3 border-l-2 border-border pl-3 italic text-muted-foreground">{children}</blockquote>
          },
          table({ children }) {
            return (
              <div className="my-3 overflow-x-auto">
                <table className="w-full border-collapse text-sm">{children}</table>
              </div>
            )
          },
          th({ children }) {
            return <th className="border border-border bg-muted/60 px-3 py-1.5 text-left font-semibold">{children}</th>
          },
          td({ children }) {
            return <td className="border border-border px-3 py-1.5">{children}</td>
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  )
})
