'use client'

import { useState } from 'react'
import { Markdown } from './markdown'
import type { Message, Source } from '@/types'
import { User as UserIcon, Sparkles, Copy, Check, RefreshCw, ThumbsUp, ThumbsDown, ExternalLink, Globe } from 'lucide-react'
import { cn } from '@/lib/utils'
import { api, ApiError } from '@/lib/api-client'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'

interface Props {
  message: Message
  isStreaming?: boolean
  onRegenerate?: () => void
}

export function MessageItem({ message, isStreaming, onRegenerate }: Props) {
  const isUser = message.role === 'user'
  const [copied, setCopied] = useState(false)
  const [feedback, setFeedback] = useState<'positive' | 'negative' | null>(null)
  const { toast } = useToast()

  const sources: Source[] = (message.sources ?? []).map((s) => s.source)

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(message.content)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {}
  }

  const sendFeedback = async (rating: 'positive' | 'negative') => {
    setFeedback((f) => (f === rating ? null : rating))
    try {
      await api(`/api/messages/${message.id}/feedback`, { method: 'POST', body: { rating } })
    } catch (e) {
      toast({ title: 'Could not save feedback', description: e instanceof ApiError ? e.message : undefined, variant: 'destructive' })
    }
  }

  return (
    <div className={cn('group flex gap-2.5 px-3 py-4 sm:gap-3 sm:px-6 sm:py-5', isUser ? 'bg-transparent' : 'bg-muted/30')}>
      <div className="flex-shrink-0">
        {isUser ? (
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
            <UserIcon className="h-4 w-4" />
          </div>
        ) : (
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-brand-foreground">
            <Sparkles className="h-4 w-4" />
          </div>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="mb-1 flex items-center gap-2">
          <span className="text-sm font-semibold">{isUser ? 'You' : 'Nexus AI'}</span>
        </div>
        <div className={cn('text-[15px] leading-relaxed', isStreaming && 'streaming-caret')}>
          {message.content ? <Markdown content={message.content} /> : isStreaming ? (
            <div className="flex items-center gap-1 py-1">
              <span className="typing-dot h-2 w-2 rounded-full bg-brand" />
              <span className="typing-dot h-2 w-2 rounded-full bg-brand" />
              <span className="typing-dot h-2 w-2 rounded-full bg-brand" />
            </div>
          ) : null}
        </div>

        {sources.length > 0 && <Sources sources={sources} />}

        {!isUser && !isStreaming && message.content && (
          <div className="mt-2 flex items-center gap-0.5 opacity-100 transition-opacity sm:gap-1 sm:opacity-0 sm:group-hover:opacity-100">
            <Button variant="ghost" size="icon" className="h-9 w-9 sm:h-8 sm:w-8" onClick={copy} aria-label="Copy">
              {copied ? <Check className="h-4 w-4 text-brand" /> : <Copy className="h-4 w-4" />}
            </Button>
            {onRegenerate && (
              <Button variant="ghost" size="icon" className="h-9 w-9 sm:h-8 sm:w-8" onClick={onRegenerate} aria-label="Regenerate">
                <RefreshCw className="h-4 w-4" />
              </Button>
            )}
            <Button variant="ghost" size="icon" className={cn('h-9 w-9 sm:h-8 sm:w-8', feedback === 'positive' && 'text-brand')} onClick={() => sendFeedback('positive')} aria-label="Good response">
              <ThumbsUp className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className={cn('h-9 w-9 sm:h-8 sm:w-8', feedback === 'negative' && 'text-destructive')} onClick={() => sendFeedback('negative')} aria-label="Bad response">
              <ThumbsDown className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

function Sources({ sources }: { sources: Source[] }) {
  const [open, setOpen] = useState(true)
  return (
    <div className="mt-3 rounded-lg border border-border bg-card/50">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-2 px-3 py-2 text-sm"
      >
        <Globe className="h-4 w-4 text-brand" />
        <span className="font-medium">Web sources</span>
        <span className="rounded-full bg-muted px-1.5 py-0.5 text-xs text-muted-foreground">{sources.length}</span>
      </button>
      {open && (
        <div className="space-y-1.5 border-t border-border p-2">
          {sources.map((s, i) => (
            <a
              key={s.url + i}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-start gap-2 rounded-md p-2 hover:bg-muted/60"
            >
              <span className="mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded bg-brand/15 text-xs font-medium text-brand">{i + 1}</span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1 truncate text-sm font-medium">
                  <span className="truncate">{s.title || s.domain}</span>
                  <ExternalLink className="h-3 w-3 flex-shrink-0 text-muted-foreground" />
                </div>
                <div className="truncate text-xs text-muted-foreground">{s.domain}</div>
                {s.snippet && <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{s.snippet}</p>}
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  )
}
