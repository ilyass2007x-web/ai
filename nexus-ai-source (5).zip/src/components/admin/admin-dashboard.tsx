'use client'

import { useEffect, useState } from 'react'
import { api } from '@/lib/api-client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Users, MessageSquare, Brain, Globe, Zap, Database, ShieldCheck, Loader2, Activity, Cpu } from 'lucide-react'
import { useApp } from '@/lib/store'
import { AdminAIConfig } from './admin-ai-config'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line,
} from 'recharts'

interface AdminData {
  totals: {
    users: number; activeUsers7d: number; conversations: number; messages: number
    aiRequests: number; totalTokens: number; webSearches: number; memories: number; feedback: number
  }
  usageByDay: { day: string; requests: number; tokens: number; searches: number }[]
  popularModels: { model: string; count: number }[]
  recentUsers: { id: string; email: string; name: string | null; role: string; emailVerified: string | null; createdAt: string }[]
  dbHealthy: boolean
}

export function AdminDashboard() {
  const { setView } = useApp()
  const [data, setData] = useState<AdminData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showAIConfig, setShowAIConfig] = useState(false)

  useEffect(() => {
    api<AdminData>('/api/admin').then(setData).catch((e) => setError(e?.message ?? 'Failed to load')).finally(() => setLoading(false))
  }, [])

  return (
    <div className="flex h-full flex-col">
      <header className="flex h-14 items-center gap-2 border-b border-border px-3 sm:px-4">
        <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={() => showAIConfig ? setShowAIConfig(false) : setView('chat')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h2 className="min-w-0 flex-1 truncate text-sm font-medium">{showAIConfig ? 'AI Architecture' : 'Admin Dashboard'}</h2>
        {!showAIConfig && (
          <Button variant="outline" size="sm" className="shrink-0 gap-1.5" onClick={() => setShowAIConfig(true)}>
            <Cpu className="h-4 w-4" /> <span className="hidden sm:inline">AI config</span><span className="sm:hidden">AI</span>
          </Button>
        )}
        {data && !showAIConfig && (
          <Badge variant={data.dbHealthy ? 'default' : 'destructive'} className="hidden shrink-0 gap-1 sm:flex">
            <Database className="h-3 w-3" /> {data.dbHealthy ? 'DB healthy' : 'DB error'}
          </Badge>
        )}
      </header>
      {showAIConfig && (
        <ScrollArea className="flex-1">
          <div className="mx-auto max-w-5xl px-4 py-6">
            <AdminAIConfig onBack={() => setShowAIConfig(false)} />
          </div>
        </ScrollArea>
      )}
      {!showAIConfig && (
        <ScrollArea className="flex-1">
          <div className="mx-auto max-w-6xl space-y-4 px-3 py-4 sm:space-y-6 sm:px-4 sm:py-6">
            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>
            ) : error ? (
              <Card><CardContent className="py-10 text-center text-destructive">{error}</CardContent></Card>
            ) : data ? (
              <>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-3 lg:grid-cols-4">
                <Stat icon={Users} label="Total users" value={data.totals.users} accent="text-emerald-500" />
                <Stat icon={Activity} label="Active (7d)" value={data.totals.activeUsers7d} accent="text-sky-500" />
                <Stat icon={MessageSquare} label="Convos" value={data.totals.conversations} accent="text-violet-500" />
                <Stat icon={MessageSquare} label="Messages" value={data.totals.messages} accent="text-orange-500" />
                <Stat icon={Zap} label="AI requests" value={data.totals.aiRequests} accent="text-amber-500" />
                <Stat icon={Brain} label="Tokens" value={fmt(data.totals.totalTokens)} accent="text-rose-500" />
                <Stat icon={Globe} label="Web searches" value={data.totals.webSearches} accent="text-teal-500" />
                <Stat icon={ShieldCheck} label="Memories" value={data.totals.memories} accent="text-fuchsia-500" />
              </div>

              <Card>
                <CardHeader><CardTitle>Usage over time</CardTitle><CardDescription>AI requests, tokens & web searches per day.</CardDescription></CardHeader>
                <CardContent>
                  <div className="h-48 w-full sm:h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={data.usageByDay}>
                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                        <XAxis dataKey="day" tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" interval="preserveStartEnd" />
                        <YAxis tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" width={32} />
                        <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
                        <Line type="monotone" dataKey="requests" stroke="#10b981" strokeWidth={2} dot={false} name="AI requests" />
                        <Line type="monotone" dataKey="searches" stroke="#14b8a6" strokeWidth={2} dot={false} name="Web searches" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-4 lg:grid-cols-2">
                <Card>
                  <CardHeader><CardTitle>Popular models</CardTitle><CardDescription>Most requested AI models.</CardDescription></CardHeader>
                  <CardContent>
                    {data.popularModels.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No usage yet.</p>
                    ) : (
                      <div className="h-48 w-full sm:h-56">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={data.popularModels} layout="vertical">
                            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                            <XAxis type="number" tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                            <YAxis type="category" dataKey="model" tick={{ fontSize: 11 }} stroke="var(--muted-foreground)" width={90} />
                            <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
                            <Bar dataKey="count" fill="#10b981" radius={[0, 4, 4, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader><CardTitle>Recent users</CardTitle><CardDescription>Newest sign-ups.</CardDescription></CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {data.recentUsers.map((u) => (
                        <div key={u.id} className="flex items-center gap-2.5 rounded-lg border border-border p-2 sm:gap-3">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand/15 text-sm font-semibold text-brand">
                            {(u.name?.[0] ?? u.email[0]).toUpperCase()}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-medium">{u.name ?? '—'}</div>
                            <div className="truncate text-xs text-muted-foreground">{u.email}</div>
                          </div>
                          {u.role === 'admin' && <Badge variant="secondary" className="shrink-0">admin</Badge>}
                          {u.emailVerified ? <Badge variant="outline" className="shrink-0 gap-1 text-emerald-600"><ShieldCheck className="h-3 w-3" /></Badge> : <Badge variant="outline" className="shrink-0 text-amber-600">unverified</Badge>}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          ) : null}
          </div>
        </ScrollArea>
      )}
    </div>
  )
}

function Stat({ icon: Icon, label, value, accent }: { icon: any; label: string; value: string | number; accent: string }) {
  return (
    <Card>
      <CardContent className="flex items-center gap-2.5 py-3 sm:gap-3 sm:py-4">
        <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted ${accent} sm:h-10 sm:w-10`}>
          <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-lg font-bold leading-tight sm:text-xl">{value}</div>
          <div className="truncate text-xs text-muted-foreground">{label}</div>
        </div>
      </CardContent>
    </Card>
  )
}

function fmt(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M'
  if (n >= 1_000) return (n / 1_000).toFixed(1) + 'K'
  return String(n)
}
