'use client'

import { useEffect, useState } from 'react'
import { api, ApiError } from '@/lib/api-client'
import type { AIStatus } from '@/types'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2, RefreshCw, ShieldCheck, Cpu, Globe, Brain, Zap } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface AIConfigResponse extends AIStatus {
  status: {
    primary: { id: string; label: string; model: string; healthy: boolean } | null
    fallback: { id: string; label: string; model: string; healthy: boolean } | null
    embedding: { id: string; label: string; model: string; healthy: boolean } | null
    tierLabel: string
  } | null
}

export function AdminAIConfig({ onBack }: { onBack: () => void }) {
  const [data, setData] = useState<AIConfigResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [reloading, setReloading] = useState(false)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    try {
      const d = await api<AIConfigResponse>('/api/admin/ai')
      setData(d)
    } catch (e) {
      toast({ title: 'Failed to load', description: e instanceof ApiError ? e.message : undefined, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const reload = async () => {
    setReloading(true)
    try {
      const res = await api<AIConfigResponse & { reloaded: boolean }>('/api/admin/ai', {
        method: 'POST', body: { action: 'reload' },
      })
      setData(res)
      toast({ title: 'AI configuration reloaded' })
    } catch (e) {
      toast({ title: 'Reload failed', description: e instanceof ApiError ? e.message : undefined, variant: 'destructive' })
    } finally {
      setReloading(false)
    }
  }

  if (loading || !data) {
    return <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>
  }

  const status = data.status
  const primary = status?.primary
  const fallback = status?.fallback
  const embedding = status?.embedding

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-semibold sm:text-xl">
            <Cpu className="h-5 w-5 shrink-0 text-brand" /> AI Architecture
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Configure Nexus AI&apos;s underlying model providers. Keys are stored in environment variables
            and never exposed in plaintext.
          </p>
        </div>
        <Button variant="outline" onClick={reload} disabled={reloading} className="shrink-0 self-start sm:self-auto">
          {reloading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
          Reload config
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-1 md:grid-cols-2">
        <ProviderCard
          icon={Zap}
          title="Primary provider"
          description="The main inference engine used for chat & reasoning."
          provider={data.primary}
          runtime={primary}
        />
        <ProviderCard
          icon={ShieldCheck}
          title="Fallback provider"
          description="Used automatically if the primary fails."
          provider={data.fallback}
          runtime={fallback}
          optional
        />
        <ProviderCard
          icon={Brain}
          title="Embedding provider"
          description="Generates vectors for semantic memory search (optional)."
          provider={data.embedding}
          runtime={embedding}
          optional
        />
        <ProviderCard
          icon={Globe}
          title="Web search provider"
          description="Independent internet research layer."
          provider={{
            provider: process.env.WEB_SEARCH_PROVIDER || 'zai',
            model: '—',
            baseUrl: null,
            apiKeyConfigured: Boolean(process.env.WEB_SEARCH_API_KEY) || !process.env.WEB_SEARCH_PROVIDER,
          }}
          runtime={null}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Available providers</CardTitle>
          <CardDescription>Registered provider factories you can switch to via environment variables.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {(data.availableProviders ?? []).map((p) => (
            <Badge key={p} variant="secondary" className="font-mono">{p}</Badge>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Configuration</CardTitle>
          <CardDescription>
            Providers are configured via environment variables. After updating <code className="rounded bg-muted px-1 font-mono text-xs">.env</code>,
            click &quot;Reload config&quot; (or restart the server).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <pre className="table-wrap rounded-lg border border-border bg-muted/40 p-2.5 text-[11px] leading-relaxed sm:p-3 sm:text-xs"><code>{`# Primary
AI_PROVIDER=openai           # openai | openai-compatible | openrouter | ollama | custom | zai | …
AI_MODEL=gpt-4o
AI_BASE_URL=https://api.openai.com/v1
AI_API_KEY=sk-...

# Fallback (optional)
AI_FALLBACK_PROVIDER=ollama
AI_FALLBACK_MODEL=llama3.1
AI_FALLBACK_BASE_URL=http://localhost:11434

# Web search (optional)
WEB_SEARCH_PROVIDER=zai

# Embeddings (optional)
EMBEDDING_PROVIDER=openai
EMBEDDING_MODEL=text-embedding-3-small`}</code></pre>
        </CardContent>
      </Card>

      <Button variant="ghost" onClick={onBack}>← Back to dashboard</Button>
    </div>
  )
}

function ProviderCard({
  icon: Icon, title, description, provider, runtime, optional,
}: {
  icon: any; title: string; description: string
  provider: { provider: string; model: string; baseUrl: string | null; apiKeyConfigured: boolean } | null
  runtime: { id: string; label: string; model: string; healthy: boolean } | null
  optional?: boolean
}) {
  const healthy = runtime?.healthy ?? false
  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0">
        <div className="flex min-w-0 items-center gap-2">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand/10 text-brand">
            <Icon className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <CardTitle className="text-base">{title}</CardTitle>
            <CardDescription className="truncate text-xs">{description}</CardDescription>
          </div>
        </div>
        <div className="shrink-0">
          {optional && !provider && <Badge variant="outline">not configured</Badge>}
          {provider && (
            <Badge variant={healthy ? 'default' : 'destructive'} className="gap-1">
              <span className={`h-1.5 w-1.5 rounded-full ${healthy ? 'bg-emerald-400' : 'bg-red-400'}`} />
              {healthy ? 'healthy' : 'unreachable'}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-2 text-sm">
        {provider ? (
          <>
            <Row label="Provider" value={provider.provider} />
            <Row label="Model" value={provider.model} />
            {provider.baseUrl && <Row label="Endpoint" value={provider.baseUrl} />}
            <Row label="API key" value={provider.apiKeyConfigured ? '✓ configured (hidden)' : '✗ not set'} />
          </>
        ) : (
          <p className="text-sm text-muted-foreground">
            {optional ? 'Optional — not configured. Nexus AI will skip this capability.' : 'Not configured.'}
          </p>
        )}
      </CardContent>
    </Card>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="shrink-0 text-xs text-muted-foreground">{label}</span>
      <span className="truncate text-right font-mono text-xs">{value}</span>
    </div>
  )
}
