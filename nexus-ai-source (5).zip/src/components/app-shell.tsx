'use client'

import { useEffect } from 'react'
import dynamic from 'next/dynamic'
import { useApp } from '@/lib/store'
import { Sidebar } from '@/components/chat/sidebar'
import { ChatView } from '@/components/chat/chat-view'
import { AuthScreen } from '@/components/auth/auth-screen'
import { Sparkles, Loader2 } from 'lucide-react'
import { Sheet, SheetContent } from '@/components/ui/sheet'

const SettingsView = dynamic(() => import('@/components/settings/settings-view').then((m) => m.SettingsView), { ssr: false })
const AdminDashboard = dynamic(() => import('@/components/admin/admin-dashboard').then((m) => m.AdminDashboard), { ssr: false })

/**
 * Client-side application shell. Overlays the server-rendered SEO content
 * with the interactive chat app for authenticated users. Crawlers (which
 * don't execute JS) see the SEO content beneath.
 */
export function AppShell() {
  const { user, loading, view, init, sidebarOpen, setSidebarOpen } = useApp()

  useEffect(() => {
    init()
  }, [init])

  // While loading, render nothing visible — the SEO content shows beneath.
  if (loading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand text-brand-foreground shadow-lg shadow-brand/20">
            <Sparkles className="h-6 w-6" />
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading Nexus AI…
          </div>
        </div>
      </div>
    )
  }

  // Unauthenticated users see the auth screen overlay.
  if (!user) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-background">
        <AuthScreen />
      </div>
    )
  }

  // Authenticated users see the full chat application overlay.
  return (
    <div className="fixed inset-0 z-50 flex w-full overflow-hidden bg-background">
      <aside className="hidden w-72 shrink-0 border-r border-sidebar-border lg:block">
        <Sidebar />
      </aside>

      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-[85vw] max-w-72 p-0">
          <Sidebar onClose={() => setSidebarOpen(false)} />
        </SheetContent>
      </Sheet>

      <main className="flex min-w-0 flex-1 flex-col">
        {view === 'chat' && <ChatView />}
        {view === 'settings' && <SettingsView />}
        {view === 'admin' && <AdminDashboard />}
      </main>
    </div>
  )
}
