import { NextRequest, NextResponse } from 'next/server'

// ────────────────────────────────────────────────────────────────────────────
// Security middleware: HTTP security headers + request body size limits.
//
// Applies to ALL routes. Runs before any route handler.
// ────────────────────────────────────────────────────────────────────────────

const MAX_BODY_SIZE = 2 * 1024 * 1024 // 2 MB default for JSON API requests

// Content-Security-Policy: restrict resource loading to same-origin + known safe sources.
// - No inline scripts except Next.js hot-reload in dev.
// - No inline styles except what Next.js injects.
// - Images: allow data: URIs (for avatars) + https.
// - Connect: same-origin only (API calls go through the gateway).
// - Fonts: same-origin + Google Fonts (used by Geist).
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval'", // Next.js requires inline+eval in dev/turbopack
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com data:",
  "img-src 'self' data: https: blob:",
  "connect-src 'self' https: wss:", // Allow WebSocket for HMR + HTTPS API calls
  "media-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'", // Clickjacking protection — no framing at all
  "upgrade-insecure-requests",
].join('; ')

const SECURITY_HEADERS: Record<string, string> = {
  'Content-Security-Policy': CSP,
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
  'X-DNS-Prefetch-Control': 'off',
  'X-Permitted-Cross-Domain-Policies': 'none',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
}

// HSTS only in production (behind HTTPS). In dev, the gateway uses HTTP.
const HSTS = process.env.NODE_ENV === 'production'
  ? 'max-age=63072000; includeSubDomains; preload'
  : ''

export function middleware(request: NextRequest) {
  // ── Request body size limit ──────────────────────────────────────────────
  // Reject oversized JSON payloads early (before they reach the handler).
  const contentLength = parseInt(request.headers.get('content-length') ?? '0', 10)
  if (contentLength > MAX_BODY_SIZE && request.method !== 'GET' && request.method !== 'HEAD') {
    return NextResponse.json(
      { error: 'Request body too large.', code: 'PAYLOAD_TOO_LARGE', requestId: 'middleware' },
      { status: 413 },
    )
  }

  // ── Apply security headers ───────────────────────────────────────────────
  const response = NextResponse.next()

  for (const [key, value] of Object.entries(SECURITY_HEADERS)) {
    response.headers.set(key, value)
  }
  if (HSTS) {
    response.headers.set('Strict-Transport-Security', HSTS)
  }

  // Cache-control: never cache authenticated API responses.
  if (request.nextUrl.pathname.startsWith('/api/')) {
    response.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate')
  }

  return response
}

export const config = {
  // Run on all routes except Next.js internal assets.
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|logo.svg|robots.txt).*)',
  ],
}
