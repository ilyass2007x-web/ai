'use client'

import { create } from 'zustand'
import type { User, Conversation, AppView, AuthView } from '@/types'
import { api } from '@/lib/api-client'

// Compute the initial auth view from the URL once (e.g. /?verify=token).
// Safe on the server (returns 'login') — AuthScreen is client-only anyway.
function initialAuthView(): AuthView {
  if (typeof window === 'undefined') return 'login'
  const p = new URLSearchParams(window.location.search)
  if (p.get('verify')) return 'verify'
  if (p.get('reset')) return 'reset'
  return 'login'
}

interface AppState {
  user: User | null
  loading: boolean
  view: AppView
  authView: AuthView
  conversations: Conversation[]
  currentConversationId: string | null
  sidebarOpen: boolean
  searchQuery: string

  // actions
  init: () => Promise<void>
  setUser: (u: User | null) => void
  setView: (v: AppView) => void
  setAuthView: (v: AuthView) => void
  setConversations: (c: Conversation[]) => void
  upsertConversation: (c: Conversation) => void
  removeConversation: (id: string) => void
  setCurrentConversation: (id: string | null) => void
  setSidebarOpen: (open: boolean) => void
  setSearchQuery: (q: string) => void
  logout: () => Promise<void>
}

export const useApp = create<AppState>((set, get) => ({
  user: null,
  loading: true,
  view: 'chat',
  authView: initialAuthView(),
  conversations: [],
  currentConversationId: null,
  sidebarOpen: false,
  searchQuery: '',

  init: async () => {
    try {
      const { user } = await api<{ user: User | null }>('/api/auth/me')
      set({ user, loading: false })
      if (user) {
        const { conversations } = await api<{ conversations: Conversation[] }>('/api/conversations')
        set({ conversations })
      }
    } catch {
      set({ user: null, loading: false })
    }
  },

  setUser: (u) => set({ user: u }),
  setView: (v) => set({ view: v, sidebarOpen: false }),
  setAuthView: (v) => set({ authView: v }),

  setConversations: (c) => set({ conversations: c }),

  upsertConversation: (c) => {
    const existing = get().conversations.filter((x) => x.id !== c.id)
    set({ conversations: [c, ...existing] })
  },

  removeConversation: (id) =>
    set((s) => ({
      conversations: s.conversations.filter((c) => c.id !== id),
      currentConversationId: s.currentConversationId === id ? null : s.currentConversationId,
    })),

  setCurrentConversation: (id) => set({ currentConversationId: id, view: 'chat', sidebarOpen: false }),

  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setSearchQuery: (q) => set({ searchQuery: q }),

  logout: async () => {
    try {
      await api('/api/auth/logout', { method: 'POST' })
    } catch {}
    set({ user: null, conversations: [], currentConversationId: null, view: 'chat', authView: 'login' })
  },
}))
