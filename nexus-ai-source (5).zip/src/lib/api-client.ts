// Lightweight fetch wrappers used by client components.

export class ApiError extends Error {
  status: number
  code: string
  requestId?: string
  constructor(message: string, status: number, code: string, requestId?: string) {
    super(message)
    this.status = status
    this.code = code
    this.requestId = requestId
  }
}

export async function api<T = unknown>(
  path: string,
  opts: { method?: string; body?: unknown; signal?: AbortSignal } = {},
): Promise<T> {
  const res = await fetch(path, {
    method: opts.method ?? 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: 'same-origin',
    signal: opts.signal,
  })

  const text = await res.text()
  let data: any = null
  try {
    data = text ? JSON.parse(text) : null
  } catch {
    data = { error: text }
  }

  if (!res.ok) {
    throw new ApiError(
      data?.error ?? `Request failed (${res.status})`,
      res.status,
      data?.code ?? 'ERROR',
      data?.requestId,
    )
  }
  return data as T
}

/**
 * SSE-based streaming chat. Calls onMeta when the first `meta` event arrives
 * (sources, conversationId), onDelta for each content chunk, and onDone at end.
 * Returns an AbortController-like handle to stop generation.
 */
export async function streamChat(
  path: string,
  body: unknown,
  handlers: {
    onMeta: (meta: any) => void
    onDelta: (content: string) => void
    onDone?: () => void
    onError?: (message: string) => void
  },
  signal?: AbortSignal,
) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    credentials: 'same-origin',
    signal,
  })

  if (!res.ok) {
    const t = await res.text().catch(() => '')
    let msg = `Request failed (${res.status})`
    try {
      msg = JSON.parse(t)?.error ?? msg
    } catch {}
    handlers.onError?.(msg)
    return
  }

  const reader = res.body?.getReader()
  if (!reader) return
  const decoder = new TextDecoder()
  let buffer = ''

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true })
      // SSE events are separated by a blank line.
      let sep
      while ((sep = buffer.indexOf('\n\n')) !== -1) {
        const raw = buffer.slice(0, sep)
        buffer = buffer.slice(sep + 2)
        let event = 'message'
        let data = ''
        for (const line of raw.split('\n')) {
          if (line.startsWith('event:')) event = line.slice(6).trim()
          else if (line.startsWith('data:')) data += line.slice(5).trim()
        }
        if (!data) continue
        try {
          const parsed = JSON.parse(data)
          if (event === 'meta') handlers.onMeta(parsed)
          else if (event === 'delta') handlers.onDelta(parsed.content ?? '')
          else if (event === 'done') handlers.onDone?.()
          else if (event === 'error') handlers.onError?.(parsed.message ?? 'Stream error')
        } catch {}
      }
    }
    // Final flush in case server closed without trailing blank line.
    if (buffer.trim()) {
      for (const block of buffer.split('\n\n')) {
        if (!block.trim()) continue
        let event = 'message'
        let data = ''
        for (const line of block.split('\n')) {
          if (line.startsWith('event:')) event = line.slice(6).trim()
          else if (line.startsWith('data:')) data += line.slice(5).trim()
        }
        if (data) {
          try {
            const parsed = JSON.parse(data)
            if (event === 'delta') handlers.onDelta(parsed.content ?? '')
            else if (event === 'done') handlers.onDone?.()
          } catch {}
        }
      }
    }
  } finally {
    reader.releaseLock()
  }
}
