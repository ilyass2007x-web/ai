// Shared streaming parser for OpenAI-compatible / SSE responses.
// Used by the openai-compatible, ollama, custom, and zai providers so they
// don't reimplement the same SSE parsing logic.

import type { ChatStream } from './provider'

/**
 * Parse an SSE / text/plain stream from a fetch Response into content deltas.
 * Handles `data: {...}` lines, `data: [DONE]`, and plain-text fallbacks.
 */
export async function* parseChatStream(body: ReadableStream<Uint8Array>): ChatStream {
  const reader = body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true })

      // SSE events are separated by a blank line, but some servers emit
      // single-line `data:` records. Split on any newline and process.
      let idx
      while ((idx = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, idx).trim()
        buffer = buffer.slice(idx + 1)
        if (!line) continue
        if (line.startsWith('data:')) {
          const payload = line.slice(5).trim()
          if (payload === '[DONE]') return
          try {
            const json = JSON.parse(payload)
            const delta =
              json?.choices?.[0]?.delta?.content ??
              json?.choices?.[0]?.message?.content ??
              json?.message?.content ?? // ollama
              ''
            if (delta) yield delta as string
          } catch {
            // Non-JSON data line: yield as plain text if it looks like content.
            if (payload && payload !== '[DONE]') yield payload
          }
        } else if (line.startsWith(':')) {
          // SSE comment / keep-alive — ignore.
        } else if (!line.startsWith('{') && !line.startsWith('}')) {
          // Plain text streaming (text/plain) — treat line as content.
          yield line + '\n'
        }
      }
    }
    // Flush any trailing plain text.
    const tail = buffer.trim()
    if (tail && !tail.startsWith('{') && tail !== '[DONE]') {
      yield tail
    }
  } finally {
    reader.releaseLock?.()
  }
}

/** Extract text content from a non-streaming OpenAI-compatible response body. */
export function extractContent(body: any): string {
  return (
    body?.choices?.[0]?.message?.content ??
    body?.choices?.[0]?.text ??
    body?.message?.content ??
    ''
  )
}

/** Extract a model name from an OpenAI-compatible response body. */
export function extractModel(body: any, fallback: string): string {
  return body?.model ?? body?.choices?.[0]?.model ?? fallback
}

/** Extract usage info if present. */
export function extractUsage(body: any): { promptTokens?: number; completionTokens?: number; totalTokens?: number } | undefined {
  const u = body?.usage
  if (!u) return undefined
  return {
    promptTokens: u.prompt_tokens ?? u.promptTokens,
    completionTokens: u.completion_tokens ?? u.completionTokens,
    totalTokens: u.total_tokens ?? u.totalTokens,
  }
}
