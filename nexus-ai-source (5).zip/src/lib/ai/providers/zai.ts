// "zai" provider — the bundled z-ai-web-dev-sdk runtime, exposed behind the
// standard AIProvider interface.
//
// This provider exists so the app runs out-of-the-box in the sandbox with
// zero configuration. It is NOT special: the orchestrator treats it exactly
// like any other provider. To switch to a different backend, simply set
// AI_PROVIDER / AI_MODEL / AI_BASE_URL / AI_API_KEY — no code changes needed.
//
// Configuration (all optional; falls back to the bundled runtime):
//   AI_PROVIDER=zai
//   AI_MODEL=<model id supported by the bundled runtime>
//   AI_API_KEY=...

import type {
  AIProvider, ChatRequest, ChatResponse, ChatStream, ProviderConfig, ProviderInfo,
} from '../provider'
import { ProviderError } from '../provider'
import { parseChatStream, extractContent, extractModel, extractUsage } from '../streaming'
import { registerProvider } from '../provider'

// We import the SDK dynamically so the rest of the app never imports it
// directly and so `import('./providers/zai')` (called by the router) is the
// only place that touches the vendor dependency.
type ZAISDK = {
  chat: {
    completions: {
      create: (body: Record<string, unknown>) => Promise<any>
    }
  }
  functions: {
    invoke: <T extends string>(name: T, args: any) => Promise<any>
  }
}

let zaiPromise: Promise<ZAISDK> | null = null
async function getZAI(): Promise<ZAISDK> {
  if (!zaiPromise) {
    zaiPromise = (async () => {
      const mod = await import('z-ai-web-dev-sdk')
      const ZAI = mod.default
      return (await ZAI.create()) as ZAISDK
    })()
  }
  return zaiPromise
}

function createZAIProvider(config: ProviderConfig): AIProvider {
  const model = config.model || 'nexus-default'
  const info: ProviderInfo = {
    id: 'zai',
    label: 'Nexus AI (bundled runtime)',
    model,
    supportsStreaming: true,
    supportsEmbeddings: false,
    healthy: true,
  }

  return {
    info,
    async chat(req: ChatRequest): Promise<ChatResponse> {
      const sdk = await getZAI().catch(() => {
        info.healthy = false
        throw new ProviderError(
          'The AI service is temporarily unavailable. Please try again.',
          'zai',
          503,
        )
      })
      try {
        const body = await sdk.chat.completions.create({
          model: req.model || model,
          messages: req.messages,
          temperature: req.temperature,
          thinking: { type: req.thinking ? 'enabled' : 'disabled' },
          stream: false,
        })
        // SDK may return either a parsed JSON object or a stream when stream=true.
        if (body && typeof body === 'object' && 'choices' in body) {
          return {
            content: extractContent(body),
            model: extractModel(body, model),
            usage: extractUsage(body),
            raw: body,
          }
        }
        return { content: '', model, raw: body }
      } catch {
        info.healthy = false
        throw new ProviderError(
          'The AI service returned an error. Please try again.',
          'zai',
          502,
        )
      }
    },
    async streamChat(req: ChatRequest): Promise<ChatStream> {
      const sdk = await getZAI().catch(() => {
        info.healthy = false
        throw new ProviderError(
          'The AI service is temporarily unavailable. Please try again.',
          'zai',
          503,
        )
      })
      let body: any
      try {
        body = await sdk.chat.completions.create({
          model: req.model || model,
          messages: req.messages,
          temperature: req.temperature,
          thinking: { type: req.thinking ? 'enabled' : 'disabled' },
          stream: true,
        })
      } catch {
        info.healthy = false
        throw new ProviderError(
          'The AI service returned an error. Please try again.',
          'zai',
          502,
        )
      }
      if (!body) return (async function* () {})()

      // If the SDK returned a parsed JSON object (stream not honoured), yield once.
      if (typeof body === 'object' && !('getReader' in body) && !('pipeTo' in body)) {
        const text = extractContent(body)
        return (async function* () {
          if (text) yield text
        })()
      }

      // Otherwise it's a ReadableStream — use the shared SSE parser.
      return parseChatStream(body as ReadableStream<Uint8Array>)
    },
    async healthCheck(): Promise<boolean> {
      try {
        await getZAI()
        info.healthy = true
        return true
      } catch {
        info.healthy = false
        return false
      }
    },
  }
}

registerProvider('zai', createZAIProvider)
// Also register under the original vendor-ish alias for clarity, though the
// app never references this name directly — only env config does.
registerProvider('bundled', createZAIProvider)
