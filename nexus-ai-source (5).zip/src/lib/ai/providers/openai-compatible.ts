// OpenAI-compatible provider.
//
// Works with any endpoint that implements the OpenAI Chat Completions API
// (https://platform.openai.com/docs/api-reference/chat), including:
//   - OpenAI itself (https://api.openai.com/v1)
//   - OpenRouter (https://openrouter.ai/api/v1)
//   - Together / Groq / Anyscale / LM Studio / vLLM / TGI / LiteLLM
//   - A self-hosted inference server exposing an OpenAI-compatible API
//
// Configuration:
//   AI_PROVIDER=openai-compatible   (or: openai | openrouter | together | groq | vllm | lm-studio)
//   AI_MODEL=<model id>
//   AI_BASE_URL=<e.g. https://api.openai.com/v1>
//   AI_API_KEY=<key>
//
// The same factory is registered under several aliases for convenience.

import { registerProvider, type AIProvider, type ChatRequest, type ChatResponse, type ChatStream, type EmbeddingRequest, type EmbeddingResponse, type ProviderConfig, type ProviderInfo, ProviderError, ProviderNotConfiguredError } from '../provider'
import { parseChatStream, extractContent, extractModel, extractUsage } from '../streaming'

interface OpenAICompatOptions {
  defaultHeaders?: Record<string, string>
  /** Whether an API key is required (Ollama doesn't need one). */
  requiresApiKey?: boolean
}

export function createOpenAICompatibleProvider(config: ProviderConfig, label: string, opts: OpenAICompatOptions = {}): AIProvider {
  const baseUrl = (config.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '')
  const apiKey = config.apiKey
  const model = config.model
  const requiresApiKey = opts.requiresApiKey ?? true

  const info: ProviderInfo = {
    id: config.provider,
    label,
    model,
    supportsStreaming: true,
    supportsEmbeddings: true,
    healthy: true,
  }

  async function doFetch(path: string, body: Record<string, unknown>, stream = false) {
    if (requiresApiKey && !apiKey) {
      throw new ProviderNotConfiguredError(config.provider, 'AI_API_KEY is required.')
    }
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
      ...opts.defaultHeaders,
    }
    let res: Response
    try {
      res = await fetch(`${baseUrl}${path}`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ ...body, stream }),
      })
    } catch {
      info.healthy = false
      throw new ProviderError(
        'The AI service is temporarily unavailable. Please try again.',
        config.provider,
        503,
      )
    }
    if (!res.ok) {
      info.healthy = false
      const status = res.status
      // Never leak the response body (it may contain provider URLs / errors).
      throw new ProviderError(
        status === 429
          ? 'The AI service is busy. Please try again in a moment.'
          : 'The AI service returned an error. Please try again.',
        config.provider,
        status,
      )
    }
    info.healthy = true
    return res
  }

  return {
    info,
    async chat(req: ChatRequest): Promise<ChatResponse> {
      const res = await doFetch('/chat/completions', {
        model: req.model || model,
        messages: req.messages,
        temperature: req.temperature,
        max_tokens: req.maxTokens,
      })
      const body = await res.json()
      return {
        content: extractContent(body),
        model: extractModel(body, model),
        usage: extractUsage(body),
        raw: body,
      }
    },
    async streamChat(req: ChatRequest): Promise<ChatStream> {
      const res = await doFetch(
        '/chat/completions',
        {
          model: req.model || model,
          messages: req.messages,
          temperature: req.temperature,
          max_tokens: req.maxTokens,
        },
        true,
      )
      if (!res.body) throw new ProviderError('No stream body from provider.', config.provider, 502)
      return parseChatStream(res.body)
    },
    async embed(req: EmbeddingRequest): Promise<EmbeddingResponse> {
      const inputs = Array.isArray(req.input) ? req.input : [req.input]
      const res = await doFetch('/embeddings', {
        model: req.model || model,
        input: inputs,
      })
      const body = await res.json()
      const embeddings: number[][] = (body?.data ?? [])
        .sort((a: any, b: any) => (a.index ?? 0) - (b.index ?? 0))
        .map((d: any) => d.embedding)
      return { embeddings, model: body?.model ?? model, usage: extractUsage(body) }
    },
    async healthCheck(): Promise<boolean> {
      try {
        const res = await fetch(`${baseUrl}/models`, {
          headers: apiKey ? { Authorization: `Bearer ${apiKey}` } : {},
        })
        info.healthy = res.ok
        return res.ok
      } catch {
        info.healthy = false
        return false
      }
    },
  }
}

// Register under several aliases so admins can set AI_PROVIDER=openai, etc.
registerProvider('openai', (cfg) => createOpenAICompatibleProvider(cfg, 'OpenAI'))
registerProvider('openai-compatible', (cfg) => createOpenAICompatibleProvider(cfg, 'OpenAI-compatible'))
registerProvider('openrouter', (cfg) => createOpenAICompatibleProvider(cfg, 'OpenRouter', {
  defaultHeaders: { 'HTTP-Referer': 'https://nexus.ai', 'X-Title': 'Nexus AI' },
}))
registerProvider('together', (cfg) => createOpenAICompatibleProvider(cfg, 'Together AI'))
registerProvider('groq', (cfg) => createOpenAICompatibleProvider(cfg, 'Groq'))
registerProvider('vllm', (cfg) => createOpenAICompatibleProvider(cfg, 'vLLM'))
registerProvider('lm-studio', (cfg) => createOpenAICompatibleProvider(cfg, 'LM Studio'))
