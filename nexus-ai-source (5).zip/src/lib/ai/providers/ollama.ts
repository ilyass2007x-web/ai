// Ollama provider — local, self-hosted models via http://localhost:11434.
//
// Configuration:
//   AI_PROVIDER=ollama
//   AI_BASE_URL=http://localhost:11434    (default)
//   AI_MODEL=llama3.1                    (or any pulled model)
//   AI_API_KEY=                          (not required)
//
// Ollama exposes an OpenAI-compatible layer at /v1, so we reuse the
// OpenAI-compatible implementation with `requiresApiKey: false`.

import { registerProvider, type ProviderConfig, type AIProvider } from '../provider'
import { createOpenAICompatibleProvider } from './openai-compatible'

function createOllamaProvider(config: ProviderConfig): AIProvider {
  const cfg: ProviderConfig = {
    ...config,
    // Ollama's OpenAI-compatible endpoint lives at /v1.
    baseUrl: (config.baseUrl || 'http://localhost:11434').replace(/\/v1\/?$/, '').replace(/\/$/, '') + '/v1',
    apiKey: config.apiKey || 'ollama', // Ollama ignores the key; a dummy keeps fetch happy.
  }
  return createOpenAICompatibleProvider(cfg, 'Ollama (local)', { requiresApiKey: false })
}

registerProvider('ollama', createOllamaProvider)
