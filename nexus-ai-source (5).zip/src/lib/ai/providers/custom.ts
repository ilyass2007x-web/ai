// Custom provider — any OpenAI-compatible self-hosted inference server.
//
// Configuration:
//   AI_PROVIDER=custom
//   AI_BASE_URL=https://my-ai-server.com/v1
//   AI_API_KEY=...
//   AI_MODEL=my-model
//
// This is functionally the OpenAI-compatible provider, exposed under a
// dedicated "custom" alias so admins can clearly identify a self-hosted
// backend in the dashboard.

import { registerProvider, type ProviderConfig, type AIProvider } from '../provider'
import { createOpenAICompatibleProvider } from './openai-compatible'

function createCustomProvider(config: ProviderConfig): AIProvider {
  if (!config.baseUrl) {
    throw new Error('AI_BASE_URL is required when AI_PROVIDER=custom.')
  }
  return createOpenAICompatibleProvider(config, 'Custom server')
}

registerProvider('custom', createCustomProvider)
