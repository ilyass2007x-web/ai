// ────────────────────────────────────────────────────────────────────────────
// Nexus AI — Provider-agnostic AI abstraction layer
//
// The entire application talks ONLY to `AIProvider` through the `AIRouter`.
// No part of Nexus AI imports or references a specific vendor (GLM, OpenAI,
// Anthropic, …) directly. Providers are selected via configuration
// (AI_PROVIDER env var / runtime config) and can be swapped without touching
// application code.
// ────────────────────────────────────────────────────────────────────────────

/** A single chat message, normalized across all providers. */
export interface ChatMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

export interface ChatRequest {
  messages: ChatMessage[]
  model?: string
  temperature?: number
  maxTokens?: number
  /** Enable chain-of-thought / reasoning if the provider supports it. */
  thinking?: boolean
  /** Optional opaque metadata for the provider (e.g. user id). */
  userId?: string
}

export interface ChatResponse {
  content: string
  model: string
  /** Estimated token usage if the provider reports one. */
  usage?: { promptTokens?: number; completionTokens?: number; totalTokens?: number }
  /** Provider-specific raw metadata (never exposed to the client). */
  raw?: unknown
}

/** Async generator yielding incremental content deltas (streaming). */
export type ChatStream = AsyncGenerator<string, void, unknown>

export interface EmbeddingRequest {
  input: string | string[]
  model?: string
}

export interface EmbeddingResponse {
  embeddings: number[][]
  model: string
  usage?: { totalTokens?: number }
}

export interface ProviderInfo {
  /** Stable provider id, e.g. "openai", "ollama", "zai", "custom". */
  id: string
  /** Human-readable label shown to admins (never the raw model name). */
  label: string
  /** The model this instance is configured to use. */
  model: string
  /** Whether streaming is supported. */
  supportsStreaming: boolean
  /** Whether embeddings are supported. */
  supportsEmbeddings: boolean
  /** Whether the provider is currently reachable (best-effort health flag). */
  healthy: boolean
}

/**
 * The universal AI provider interface. Every concrete provider implements this.
 * The rest of Nexus AI only ever imports `AIProvider` — never a vendor SDK.
 */
export interface AIProvider {
  readonly info: ProviderInfo
  /** Non-streaming completion. */
  chat(req: ChatRequest): Promise<ChatResponse>
  /** Streaming completion; yields incremental content deltas. */
  streamChat(req: ChatRequest): Promise<ChatStream>
  /** Generate an embedding (optional — may throw if unsupported). */
  embed?(req: EmbeddingRequest): Promise<EmbeddingResponse>
  /** Lightweight health check (e.g. a models list ping). */
  healthCheck?(): Promise<boolean>
}

// ─────────────────────────── Provider registry ──────────────────────────────

export type ProviderFactory = (config: ProviderConfig) => AIProvider

export interface ProviderConfig {
  provider: string
  model: string
  baseUrl?: string
  apiKey?: string
  /** Extra provider-specific options. */
  options?: Record<string, unknown>
}

const registry = new Map<string, ProviderFactory>()

/** Register a provider factory under one or more aliases. */
export function registerProvider(id: string, factory: ProviderFactory): void {
  registry.set(id.toLowerCase(), factory)
}

/** Look up the factory for a provider id (case-insensitive). */
export function getProviderFactory(id: string): ProviderFactory | undefined {
  return registry.get(id.toLowerCase())
}

/** List of registered provider ids (for admin UI). */
export function listProviderIds(): string[] {
  return Array.from(registry.keys())
}

export class ProviderError extends Error {
  status: number
  providerId: string
  constructor(message: string, providerId: string, status = 502) {
    super(message)
    this.name = 'ProviderError'
    this.providerId = providerId
    this.status = status
  }
}

export class ProviderNotConfiguredError extends ProviderError {
  constructor(providerId: string, detail?: string) {
    super(
      `AI provider "${providerId}" is not configured.${detail ? ` ${detail}` : ''}`,
      providerId,
      503,
    )
    this.name = 'ProviderNotConfiguredError'
  }
}
