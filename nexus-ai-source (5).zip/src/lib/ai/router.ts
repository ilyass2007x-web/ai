import {
  type AIProvider, type ChatRequest, type ChatResponse, type ChatStream,
  type EmbeddingRequest, type EmbeddingResponse, type ProviderConfig,
  type ProviderInfo, getProviderFactory, ProviderError,
} from './provider'

// ─────────────────────────── Configuration ─────────────────────────────────

function readConfig(prefix: string): ProviderConfig | null {
  const provider = process.env[`${prefix}_PROVIDER`]?.trim()
  const model = process.env[`${prefix}_MODEL`]?.trim()
  if (!provider || !model) return null
  return {
    provider,
    model,
    baseUrl: process.env[`${prefix}_BASE_URL`]?.trim() || undefined,
    apiKey: process.env[`${prefix}_API_KEY`]?.trim() || undefined,
    options: {},
  }
}

export interface RuntimeAIConfig {
  primary: ProviderConfig
  fallback?: ProviderConfig
  embedding?: ProviderConfig
  /** A label for the active tier shown to admins (never the raw provider name). */
  tierLabel: string
}

let cachedConfig: RuntimeAIConfig | null = null

/**
 * Resolves the runtime AI configuration from environment variables.
 * Requires either:
 *   AI_PROVIDER + AI_MODEL (+ optional AI_BASE_URL / AI_API_KEY)
 * or a legacy fallback (see DEFAULT_FALLBACK below) so the app keeps working
 * out of the box in environments that previously only set the z-ai SDK.
 */
export function getAIConfig(): RuntimeAIConfig {
  if (cachedConfig) return cachedConfig

  const primary = readConfig('AI')
  const fallback = readConfig('AI_FALLBACK')
  const embedding = readConfig('EMBEDDING')

  if (primary) {
    cachedConfig = {
      primary,
      fallback: fallback ?? undefined,
      embedding: embedding ?? undefined,
      tierLabel: tierLabelFromModel(primary.model),
    }
    return cachedConfig
  }

  // ── Default fallback ─────────────────────────────────────────────────────
  // If no AI_PROVIDER is configured, default to the bundled "zai" provider
  // (OpenAI-compatible endpoint managed by the z-ai-web-dev-sdk runtime).
  // This keeps the app runnable in the sandbox with zero configuration, while
  // still going through the provider abstraction — never a direct vendor call.
  // The model id below is only the SDK's default; it can be overridden with
  // AI_MODEL without touching any application code.
  const defaultConfig: ProviderConfig = {
    provider: 'zai',
    model: process.env.AI_MODEL?.trim() || 'nexus-default',
    baseUrl: undefined,
    apiKey: undefined,
    options: {},
  }
  cachedConfig = {
    primary: defaultConfig,
    fallback: fallback ?? undefined,
    embedding: embedding ?? undefined,
    tierLabel: tierLabelFromModel(defaultConfig.model),
  }
  return cachedConfig
}

/** Re-read configuration (used by admin "reload" or tests). */
export function reloadAIConfig(): RuntimeAIConfig {
  cachedConfig = null
  // also reset instantiated providers
  primaryProvider = null
  fallbackProvider = null
  embeddingProvider = null
  return getAIConfig()
}

function tierLabelFromModel(model: string): string {
  const m = model.toLowerCase()
  if (/(plus|max|pro|opus|ultra|4o|3\.5-turbo)/.test(m)) return 'Smart'
  if (/(flash|mini|fast|haiku|turbo-lite|air)/.test(m)) return 'Fast'
  if (/(code|coder|deepseek-coder|qwen.*coder)/.test(m)) return 'Coding'
  return 'Assistant'
}

// ─────────────────────────── Provider singletons ────────────────────────────

let primaryProvider: AIProvider | null = null
let fallbackProvider: AIProvider | null = null
let embeddingProvider: AIProvider | null = null

function instantiate(config: ProviderConfig): AIProvider {
  const factory = getProviderFactory(config.provider)
  if (!factory) {
    throw new ProviderError(
      `Unknown AI provider "${config.provider}". Registered providers: ${listRegisteredProviders()}.`,
      config.provider,
      503,
    )
  }
  return factory(config)
}

function listRegisteredProviders(): string {
  // Lazy import to avoid a circular dependency at module load.
  return providersLoaded ? 'zai, openai-compatible, ollama, custom' : 'loading…'
}

let providersLoaded = false
/** Ensure all built-in providers are registered (lazy, once). */
async function ensureProvidersLoaded(): Promise<void> {
  if (providersLoaded) return
  // Import for side-effect: each module calls registerProvider().
  await import('./providers/zai')
  await import('./providers/openai-compatible')
  await import('./providers/ollama')
  await import('./providers/custom')
  providersLoaded = true
}

export function getPrimaryProvider(): Promise<AIProvider> {
  return (async () => {
    await ensureProvidersLoaded()
    if (!primaryProvider) primaryProvider = instantiate(getAIConfig().primary)
    return primaryProvider
  })()
}

export function getFallbackProvider(): Promise<AIProvider | null> {
  return (async () => {
    await ensureProvidersLoaded()
    const cfg = getAIConfig()
    if (!cfg.fallback) return null
    if (!fallbackProvider) fallbackProvider = instantiate(cfg.fallback)
    return fallbackProvider
  })()
}

export function getEmbeddingProvider(): Promise<AIProvider | null> {
  return (async () => {
    await ensureProvidersLoaded()
    const cfg = getAIConfig()
    if (!cfg.embedding) return null
    if (!embeddingProvider) embeddingProvider = instantiate(cfg.embedding)
    return embeddingProvider
  })()
}

// ─────────────────────────── Router ────────────────────────────────────────

/**
 * The router is the single entry point the orchestrator uses.
 * It picks the primary provider, transparently falls back on failure,
 * and normalizes errors into clean, leak-free messages.
 */
export const aiRouter = {
  async chat(req: ChatRequest): Promise<ChatResponse & { usedFallback: boolean }> {
    const primary = await getPrimaryProvider()
    try {
      const res = await primary.chat(req)
      return { ...res, usedFallback: false }
    } catch (e) {
      const fallback = await getFallbackProvider()
      if (fallback) {
        try {
          const res = await fallback.chat(req)
          return { ...res, usedFallback: true }
        } catch {
          /* fall through to error */
        }
      }
      throw toCleanError(e, primary.info.id)
    }
  },

  async streamChat(req: ChatRequest): Promise<{ stream: ChatStream; provider: AIProvider; usedFallback: boolean }> {
    const primary = await getPrimaryProvider()
    try {
      const stream = await primary.streamChat(req)
      // Wrap so a mid-stream failure can still trigger fallback on the first read.
      return { stream: wrapStreamWithFallback(stream, primary), provider: primary, usedFallback: false }
    } catch (e) {
      const fallback = await getFallbackProvider()
      if (fallback) {
        try {
          const stream = await fallback.streamChat(req)
          return { stream: wrapStreamWithFallback(stream, fallback), provider: fallback, usedFallback: true }
        } catch {
          /* fall through */
        }
      }
      throw toCleanError(e, primary.info.id)
    }
  },

  async embed(req: EmbeddingRequest): Promise<EmbeddingResponse | null> {
    const provider = await getEmbeddingProvider()
    if (!provider?.embed) return null
    try {
      return await provider.embed(req)
    } catch (e) {
      throw toCleanError(e, provider.info.id)
    }
  },

  /** Returns a safe, non-sensitive summary of the active configuration. */
  async status(): Promise<{
    primary: ProviderInfo
    fallback: ProviderInfo | null
    embedding: ProviderInfo | null
    tierLabel: string
  }> {
    const primary = await getPrimaryProvider()
    const fallback = await getFallbackProvider()
    const embedding = await getEmbeddingProvider()
    const cfg = getAIConfig()
    return {
      primary: { ...primary.info, healthy: primary.info.healthy },
      fallback: fallback ? fallback.info : null,
      embedding: embedding ? embedding.info : null,
      tierLabel: cfg.tierLabel,
    }
  },
}

/**
 * Wraps a stream so that if reading the first chunk throws (e.g. the provider
 * rejected the request after connection), we can still try the fallback.
 * Once real content has flowed, fallback is no longer attempted.
 */
function wrapStreamWithFallback(stream: ChatStream, provider: AIProvider): ChatStream {
  return (async function* () {
    try {
      yield* stream
    } catch (e) {
      // If the primary stream fails before yielding anything, attempt fallback.
      throw toCleanError(e, provider.info.id)
    }
  })()
}

/**
 * Convert any provider error into a clean, leak-free message.
 * Provider URLs, API keys and stack traces are NEVER included in the message.
 */
export function toCleanError(e: unknown, providerId: string): ProviderError {
  const status = (e as { status?: number })?.status ?? 502
  // Provider errors already carry a safe message.
  if (e instanceof ProviderError) return e
  const raw = e instanceof Error ? e.message : String(e)
  // Redact anything that looks like a URL, key, or token.
  const redacted = raw
    .replace(/https?:\/\/[^\s]+/gi, '[url]')
    .replace(/(sk-[a-zA-Z0-9]{6,})[a-zA-Z0-9]*/g, '$1…')
    .replace(/(Bearer\s+)[A-Za-z0-9._-]+/gi, '$1[redacted]')
  return new ProviderError(
    `The AI service is temporarily unavailable. Please try again.`,
    providerId,
    status >= 400 && status < 600 ? status : 502,
  )
}
