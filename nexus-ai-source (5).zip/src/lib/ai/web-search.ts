import { db } from '../db'
import { aiRouter } from './router'
import type { ChatMessage } from './provider'

// ───────────────────────── Search provider abstraction ─────────────────────────
//
// Web search is independent from the AI model. It can be powered by:
//   - the bundled z-ai-web-dev-sdk `web_search` function (default, zero-config)
//   - any future provider (Brave, Tavily, SerpAPI, SearXNG, …) registered below.
//
// The orchestrator never calls a vendor directly — it calls `runWebSearch`.

export interface RawSearchResult {
  url: string
  title: string
  snippet: string
  domain: string
  rank?: number
  date?: string
}

export type SearchExecutor = (query: string, num: number) => Promise<RawSearchResult[]>

const searchExecutors = new Map<string, SearchExecutor>()

export function registerSearchProvider(id: string, exec: SearchExecutor): void {
  searchExecutors.set(id.toLowerCase(), exec)
}

async function getActiveSearchProvider(): Promise<{ id: string; exec: SearchExecutor } | null> {
  const id = (process.env.WEB_SEARCH_PROVIDER || 'zai').toLowerCase()
  const exec = searchExecutors.get(id)
  if (!exec) {
    // Lazy-load the default z-ai search provider if not yet registered.
    if (id === 'zai') {
      await import('./search-providers/zai-search')
      const exec2 = searchExecutors.get('zai')
      if (exec2) return { id, exec: exec2 }
    }
    return null
  }
  return { id, exec }
}

// ───────────────────────── Ranked sources ─────────────────────────

export interface RankedSource {
  url: string
  title: string
  domain: string
  snippet: string
  rank: number
  date?: string
  score: number
}

// Authority tiers for domain-based ranking.
const AUTHORITY_DOMAINS = [
  '.gov', 'gov.', 'wikipedia.org', 'mozilla.org', 'w3.org',
  'microsoft.com', 'apple.com', 'google.com', 'github.com',
  'stackoverflow.com', 'arxiv.org', 'nature.com', 'sciencedirect.com',
  'ieee.org', 'acm.org', 'nist.gov', 'who.int', 'un.org', 'europa.eu',
  'python.org', 'nodejs.org', 'react.dev', 'nextjs.org', 'typescriptlang.org',
  'prisma.io', 'neon.tech',
]

function authorityScore(domain: string): number {
  const d = domain.toLowerCase()
  for (const a of AUTHORITY_DOMAINS) {
    if (d.includes(a)) return 100
  }
  if (/\.(edu|edu\.[a-z]{2})$/.test(d) || /\.(ac\.[a-z]{2})$/.test(d)) return 95
  if (d.endsWith('.org')) return 70
  if (d.endsWith('.io') || d.endsWith('.dev')) return 65
  if (d.endsWith('.com')) return 50
  return 40
}

function snippetScore(snippet: string): number {
  const len = snippet?.length ?? 0
  if (len > 200) return 20
  if (len > 80) return 15
  if (len > 20) return 8
  return 0
}

export function rankResults(results: RawSearchResult[]): RankedSource[] {
  const seen = new Set<string>()
  return results
    .filter((r) => {
      const url = r.url?.trim()
      if (!url) return false
      if (seen.has(url)) return false
      seen.add(url)
      return true
    })
    .map((r, i) => ({
      url: r.url,
      title: r.title || r.url,
      domain: r.domain || safeDomain(r.url),
      snippet: r.snippet || '',
      rank: r.rank ?? i + 1,
      date: r.date,
      score:
        authorityScore(r.domain || safeDomain(r.url)) +
        snippetScore(r.snippet) +
        Math.max(0, 30 - i * 3),
    }))
    .sort((a, b) => b.score - a.score)
}

function safeDomain(url: string): string {
  try {
    return new URL(url).hostname
  } catch {
    return ''
  }
}

export interface WebSearchResult {
  query: string
  sources: RankedSource[]
  searchRecordId?: string
}

/**
 * Performs a web search via the active search provider, dedupes & ranks
 * results, and persists a record of the search + sources in the database.
 */
export async function performWebSearch(
  query: string,
  opts: { userId: string; conversationId?: string; num?: number },
): Promise<WebSearchResult> {
  const active = await getActiveSearchProvider()
  if (!active) {
    // No search provider configured — return empty rather than crash.
    return { query, sources: [] }
  }

  let raw: RawSearchResult[]
  try {
    raw = await active.exec(query, opts.num ?? 8)
  } catch (e) {
    console.error('[web-search] provider failed:', active.id, e)
    raw = []
  }
  const sources = rankResults(raw)

  const search = await db.webSearch.create({
    data: {
      userId: opts.userId,
      conversationId: opts.conversationId ?? null,
      query,
      resultsCount: sources.length,
    },
  })

  if (sources.length > 0) {
    await Promise.all(
      sources.slice(0, 8).map(async (s) => {
        const source = await db.webSource.upsert({
          where: { url: s.url },
          update: { title: s.title, domain: s.domain, snippet: s.snippet, rank: s.rank },
          create: { url: s.url, title: s.title, domain: s.domain, snippet: s.snippet, content: null, rank: s.rank },
        })
        await db.webSearchSource
          .create({ data: { webSearchId: search.id, sourceId: source.id } })
          .catch(() => {})
      }),
    )
  }

  return { query, sources, searchRecordId: search.id }
}

/**
 * Decides whether a user question needs fresh web information.
 * Uses the configured AI model with a strict JSON output.
 */
export async function decideWebSearch(
  question: string,
  recentContext: string,
): Promise<{ needed: boolean; queries: string[] }> {
  const prompt = `You are a research router. Decide whether the user's latest message REQUIRES a live web search to answer accurately.

Search is REQUIRED when the question depends on:
- Current/recent events, news, prices, releases, versions, statistics
- Latest documentation or status of products/services/companies/people
- Information that changes over time
- The user explicitly asking to search or use current/online sources

Do NOT search when the question is:
- Casual conversation, creative writing, translation, rewriting
- Basic math, logic, programming concepts, general knowledge that is stable
- Asking about the assistant itself

Return STRICT JSON only, no prose:
{"needed": true|false, "queries": ["optimized search query 1", "query 2"]}

Generate 1-3 concise, effective search queries (English preferred). If not needed, return an empty queries array.

Recent conversation context:
${recentContext.slice(0, 1500)}

User's latest message:
"""
${question}
"""

JSON:`

  const messages: ChatMessage[] = [{ role: 'user', content: prompt }]
  let text = ''
  try {
    const res = await aiRouter.chat({ messages, temperature: 0 })
    text = res.content
  } catch {
    text = ''
  }

  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/)
    const parsed = JSON.parse(jsonMatch ? jsonMatch[0] : text)
    return {
      needed: Boolean(parsed.needed),
      queries: Array.isArray(parsed.queries) ? parsed.queries.slice(0, 3) : [],
    }
  } catch {
    // Fallback: heuristic decision so a search-router model failure doesn't
    // block the user from getting fresh information.
    const freshIndicators = /(today|latest|current|recent|now|2024|2025|2026|price|news|version|release|update|status|live)/i
    return {
      needed: freshIndicators.test(question),
      queries: [question.slice(0, 120)],
    }
  }
}
