// Default web search provider — uses the bundled z-ai-web-dev-sdk `web_search`
// function. This keeps web research working out-of-the-box with zero config.
//
// To use a different search backend (Brave, Tavily, SearXNG, …), create a new
// provider module in this folder, register it via `registerSearchProvider`,
// and set WEB_SEARCH_PROVIDER=<id> in the environment. No other code changes.

import { registerSearchProvider, type RawSearchResult } from '../web-search'

type ZAISearchResult = {
  url: string
  name: string
  snippet: string
  host_name: string
  rank: number
  date: string
  favicon: string
}

let zaiSearchPromise: Promise<(query: string, num: number) => Promise<ZAISearchResult[]>> | null = null

async function getSearchFn() {
  if (!zaiSearchPromise) {
    zaiSearchPromise = (async () => {
      const mod = await import('z-ai-web-dev-sdk')
      const ZAI = mod.default
      const zai = await ZAI.create()
      return async (query: string, num: number) => {
        const results = await zai.functions.invoke('web_search', { query, num })
        return (results ?? []) as ZAISearchResult[]
      }
    })()
  }
  return zaiSearchPromise
}

registerSearchProvider('zai', async (query: string, num: number): Promise<RawSearchResult[]> => {
  try {
    const fn = await getSearchFn()
    const raw = await fn(query, num)
    return raw.map((r) => ({
      url: r.url,
      title: r.name,
      snippet: r.snippet,
      domain: r.host_name,
      rank: r.rank,
      date: r.date,
    }))
  } catch (e) {
    console.error('[zai-search] failed:', e)
    return []
  }
})
