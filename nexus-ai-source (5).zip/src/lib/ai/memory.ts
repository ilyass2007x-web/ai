import { db } from '../db'
import { aiRouter } from './router'
import type { ChatMessage } from './provider'

export interface RetrievedMemory {
  id: string
  content: string
  memoryType: string
  importance: number
  score: number
}

/**
 * Retrieves memories relevant to the current message using a hybrid of
 * PostgreSQL full-text search (tsvector over content) and keyword
 * overlap. Falls back to the most important recent memories.
 */
export async function retrieveMemories(
  userId: string,
  query: string,
  limit = 6,
): Promise<RetrievedMemory[]> {
  const terms = extractKeywords(query)
  if (terms.length === 0) return []

  // Hybrid: full-text via to_tsvector + keyword array overlap + importance.
  // Use a parameterized plainto_tsquery for safety (no injection).
  const ftsQuery = terms.slice(0, 6).join(' ')
  const rows = await db.$queryRaw<RetrievedMemory[]>`
    SELECT id, content, "memoryType", importance,
      (ts_rank(to_tsvector('english', content), plainto_tsquery('english', ${ftsQuery})) * 2
       + importance) AS score
    FROM "Memory"
    WHERE "userId" = ${userId}
      AND (
        to_tsvector('english', content) @@ plainto_tsquery('english', ${ftsQuery})
        OR "keywords" && ARRAY[${terms}]::text[]
      )
    ORDER BY score DESC
    LIMIT ${limit}
  `.catch(() => [] as RetrievedMemory[])

  if (rows.length > 0) return rows

  // Fallback: keyword ILIKE scan (works if FTS config differs).
  const likeRows = await db.memory.findMany({
    where: {
      userId,
      OR: terms.map((t) => ({ content: { contains: t, mode: 'insensitive' } })),
    },
    orderBy: [{ importance: 'desc' }, { updatedAt: 'desc' }],
    take: limit,
  })
  return likeRows.map((m) => ({
    id: m.id,
    content: m.content,
    memoryType: m.memoryType,
    importance: m.importance,
    score: m.importance,
  }))
}

function extractKeywords(text: string): string[] {
  const stop = new Set([
    'the', 'a', 'an', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'be',
    'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
    'could', 'should', 'may', 'might', 'must', 'can', 'to', 'of', 'in', 'on',
    'at', 'for', 'with', 'about', 'as', 'by', 'i', 'you', 'he', 'she', 'it',
    'we', 'they', 'my', 'your', 'his', 'her', 'its', 'our', 'their', 'this',
    'that', 'these', 'those', 'what', 'which', 'who', 'whom', 'how', 'when',
    'where', 'why', 'if', 'then', 'so', 'than', 'too', 'very', 'just', 'me',
    'please', 'help', 'want', 'need', 'like', 'tell', 'give', 'show', 'know',
  ])
  return Array.from(
    new Set(
      text
        .toLowerCase()
        .replace(/[^a-z0-9\s\u0600-\u06FF]/g, ' ')
        .split(/\s+/)
        .filter((w) => w.length > 2 && !stop.has(w)),
    ),
  ).slice(0, 10)
}

const MEMORY_EXTRACT_PROMPT = `You extract durable, long-term-useful facts about the user from a conversation.
Only extract information that would plausibly help FUTURE conversations. Examples worth remembering:
- The user's name, profession, projects, tech stack, goals
- Stable preferences (language, response style, tools used)
- Long-term context (building a SaaS, uses Neon PostgreSQL, prefers Darija)

NEVER extract:
- Passwords, API keys, tokens, payment info, sensitive personal data
- One-off task details unlikely to recur
- Emotional venting or private conversation content

If nothing worth remembering, return: {"memories":[]}

Otherwise return STRICT JSON:
{"memories":[{"content":"concise memory sentence","memoryType":"fact|preference|context|instruction","importance":0.0-1.0,"keywords":["kw1","kw2"]}]}

Return JSON only, no prose.`

export async function extractAndStoreMemories(
  userId: string,
  conversation: { userMsg: string; assistantMsg: string },
): Promise<number> {
  const settings = await db.userSettings.findUnique({ where: { userId } })
  if (settings && !settings.memoryEnabled) return 0

  const prompt = `${MEMORY_EXTRACT_PROMPT}

User message:
"""
${conversation.userMsg.slice(0, 2000)}
"""

Assistant response:
"""
${conversation.assistantMsg.slice(0, 2000)}
"""

JSON:`

  const messages: ChatMessage[] = [{ role: 'user', content: prompt }]
  let text = ''
  try {
    const res = await aiRouter.chat({ messages, temperature: 0 })
    text = res.content
  } catch {
    return 0
  }

  let parsed: { memories?: Array<{ content: string; memoryType: string; importance: number; keywords: string[] }> }
  try {
    const match = text.match(/\{[\s\S]*\}/)
    parsed = JSON.parse(match ? match[0] : text)
  } catch {
    return 0
  }

  const memories = (parsed.memories || []).filter(
    (m) => m.content && m.content.length < 500 && !looksSensitive(m.content),
  )
  if (memories.length === 0) return 0

  // Deduplicate against existing memories (simple content similarity).
  const existing = await db.memory.findMany({
    where: { userId },
    select: { id: true, content: true },
  })

  let stored = 0
  for (const m of memories) {
    const dup = existing.find((e) => similarEnough(e.content, m.content))
    if (dup) continue
    await db.memory.create({
      data: {
        userId,
        content: m.content,
        memoryType: ['fact', 'preference', 'context', 'instruction'].includes(m.memoryType)
          ? m.memoryType
          : 'fact',
        importance: typeof m.importance === 'number' ? Math.max(0, Math.min(1, m.importance)) : 0.5,
        keywords: Array.isArray(m.keywords) ? m.keywords.slice(0, 10) : [],
      },
    })
    stored++
  }
  return stored
}

function looksSensitive(text: string): boolean {
  const t = text.toLowerCase()
  return /(password|passwd|api[-_ ]?key|secret|token|bearer|credit|card|ssn|passport|pin\b)/.test(t)
}

function similarEnough(a: string, b: string): boolean {
  const sa = new Set(a.toLowerCase().split(/\W+/).filter((w) => w.length > 3))
  const sb = new Set(b.toLowerCase().split(/\W+/).filter((w) => w.length > 3))
  if (sa.size === 0 || sb.size === 0) return a === b
  let common = 0
  for (const w of sa) if (sb.has(w)) common++
  return common / Math.min(sa.size, sb.size) > 0.6
}

/**
 * Generate a summary when a conversation gets long, to keep the prompt compact.
 */
export async function summarizeConversation(
  history: { role: string; content: string }[],
  previousSummary?: string | null,
): Promise<string> {
  const transcript = history
    .map((m) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content.slice(0, 600)}`)
    .join('\n\n')
  const prompt = `Summarize the key facts, decisions, and context of this conversation so the assistant can continue helping later without re-reading every message. Keep it under 250 words. Focus on durable context, not small talk.${previousSummary ? `\n\nPrevious summary:\n${previousSummary}` : ''}\n\nConversation:\n${transcript}\n\nSummary:`
  const chatMessages: ChatMessage[] = [{ role: 'user', content: prompt }]
  try {
    const res = await aiRouter.chat({ messages: chatMessages, temperature: 0 })
    return res.content.slice(0, 2000)
  } catch {
    return previousSummary ?? ''
  }
}
