import { PrismaClient } from '@prisma/client'

// The sandbox shell may export a stale `DATABASE_URL` (pointing at an old
// SQLite file) which overrides `.env`. Next.js does not override existing
// env vars, so we normalise here: if DATABASE_URL is missing or points at
// a SQLite file, fall back to the Neon connection from DIRECT_DATABASE_URL
// (which is loaded from `.env` and not shadowed).
const raw = process.env.DATABASE_URL
if (!raw || raw.startsWith('file:') || raw.startsWith('sqlite')) {
  const direct = process.env.DIRECT_DATABASE_URL
  if (direct && direct.startsWith('postgres')) {
    process.env.DATABASE_URL = direct
  }
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'production' ? ['error'] : ['error', 'warn'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
