import { NextResponse } from 'next/server'
import { randomUUID } from 'crypto'

export interface ApiError {
  error: string
  code: string
  requestId: string
  details?: unknown
}

export function errorResponse(
  err: unknown,
  status?: number,
): NextResponse<ApiError> {
  const requestId = randomUUID()
  let message = 'Internal server error'
  let code = 'INTERNAL_ERROR'
  let statusCode = status ?? 500

  if (err instanceof Error) {
    if ('status' in err && typeof (err as { status: number }).status === 'number') {
      statusCode = (err as { status: number }).status
    }
    // Never leak internal details to the client for 5xx errors.
    if (statusCode >= 500) {
      message = 'Something went wrong. Please try again.'
    } else {
      message = err.message
    }
    code = err.name.replace(/Error$/,).toUpperCase() || code
  }

  // Server-side detailed log (never sent to client).
  console.error(`[${requestId}] ${code} (${statusCode}):`, err)

  return NextResponse.json(
    { error: message, code, requestId },
    { status: statusCode },
  )
}

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data, { status })
}
