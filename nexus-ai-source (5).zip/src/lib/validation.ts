import { z } from 'zod'

export const emailSchema = z.string().email().max(254).toLowerCase().trim()
export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .max(128, 'Password is too long')
  .regex(/[a-zA-Z]/, 'Password must contain at least one letter')
  .regex(/[0-9]/, 'Password must contain at least one number')

export const registerSchema = z.object({
  name: z.string().trim().min(1, 'Name is required').max(100),
  email: emailSchema,
  password: passwordSchema,
  confirmPassword: z.string(),
}).refine((d) => d.password === d.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
})

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1).max(128),
  remember: z.boolean().optional().default(true),
})

export const forgotPasswordSchema = z.object({
  email: emailSchema,
})

export const resetPasswordSchema = z.object({
  token: z.string().min(1),
  password: passwordSchema,
})

export const verifyEmailSchema = z.object({
  token: z.string().min(1),
})

export const createConversationSchema = z.object({
  title: z.string().trim().min(1).max(200).optional(),
  model: z.string().max(60).optional(),
})

export const updateConversationSchema = z.object({
  title: z.string().trim().min(1).max(200).optional(),
  archived: z.boolean().optional(),
  pinned: z.boolean().optional(),
})

export const sendMessageSchema = z.object({
  conversationId: z.string().min(1),
  content: z.string().trim().min(1).max(32_000),
})

export const updateMemorySchema = z.object({
  content: z.string().trim().min(1).max(2000).optional(),
  importance: z.number().min(0).max(1).optional(),
  memoryType: z.enum(['fact', 'preference', 'context', 'instruction']).optional(),
})

export const updateSettingsSchema = z.object({
  model: z.string().max(60).optional().nullable(),
  temperature: z.number().min(0).max(2).optional(),
  responseStyle: z.enum(['concise', 'balanced', 'detailed']).optional(),
  memoryEnabled: z.boolean().optional(),
  webSearchEnabled: z.boolean().optional(),
  language: z.enum(['en', 'ar', 'fr']).optional(),
  theme: z.enum(['light', 'dark', 'system']).optional(),
})

export const searchSchema = z.object({
  q: z.string().trim().min(1).max(200),
})

export const feedbackSchema = z.object({
  rating: z.enum(['positive', 'negative']),
  comment: z.string().max(2000).optional(),
})

export const updateProfileSchema = z.object({
  name: z.string().trim().min(1).max(100).optional(),
  email: emailSchema.optional(),
})

export const deleteAccountSchema = z.object({
  confirm: z.literal('DELETE'),
})

export const regenerateSchema = z.object({
  conversationId: z.string().min(1),
  messageId: z.string().min(1),
})
