// Simple in-memory rate limiter (PostgreSQL fallback not needed for single-instance).
// Uses a sliding window per key. Persists across requests within the process.

interface Bucket {
  timestamps: number[]
}

const buckets = new Map<string, Bucket>()

// Periodic cleanup of expired buckets to avoid memory growth.
const CLEANUP_INTERVAL = 5 * 60 * 1000 // 5 min
let lastCleanup = Date.now()

function cleanup(windowMs: number) {
  const now = Date.now()
  if (now - lastCleanup < CLEANUP_INTERVAL) return
  lastCleanup = now
  const cutoff = now - windowMs
  for (const [key, bucket] of buckets) {
    bucket.timestamps = bucket.timestamps.filter((t) => t > cutoff)
    if (bucket.timestamps.length === 0) buckets.delete(key)
  }
}

export interface RateLimitResult {
  ok: boolean
  remaining: number
  resetAt: number
  limit: number
}

export function rateLimit(
  key: string,
  limit: number,
  windowMs: number,
): RateLimitResult {
  cleanup(windowMs)
  const now = Date.now()
  const windowStart = now - windowMs

  let bucket = buckets.get(key)
  if (!bucket) {
    bucket = { timestamps: [] }
    buckets.set(key, bucket)
  }

  bucket.timestamps = bucket.timestamps.filter((t) => t > windowStart)
  if (bucket.timestamps.length >= limit) {
    const oldest = bucket.timestamps[0]
    return {
      ok: false,
      remaining: 0,
      resetAt: oldest + windowMs,
      limit,
    }
  }

  bucket.timestamps.push(now)
  return {
    ok: true,
    remaining: limit - bucket.timestamps.length,
    resetAt: now + windowMs,
    limit,
  }
}

export function getClientIp(request: Request): string {
  const xff = request.headers.get('x-forwarded-for')
  if (xff) return xff.split(',')[0]!.trim()
  return request.headers.get('x-real-ip') ?? 'unknown'
}

// Standard rate-limit presets.
export const LIMITS = {
  login: { limit: 10, windowMs: 10 * 60 * 1000 }, // 10 / 10 min per ip
  register: { limit: 5, windowMs: 60 * 60 * 1000 }, // 5 / hour per ip
  resetPassword: { limit: 5, windowMs: 60 * 60 * 1000 }, // 5 / hour per ip
  chat: { limit: 30, windowMs: 60 * 1000 }, // 30 / min per user
  chatDaily: { limit: 500, windowMs: 24 * 60 * 60 * 1000 }, // 500 / day per user
  webSearch: { limit: 20, windowMs: 60 * 1000 }, // 20 / min per user
} as const
