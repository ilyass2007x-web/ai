// ────────────────────────────────────────────────────────────────────────────
// Role-Based Access Control (RBAC)
//
// Roles follow a strict hierarchy: user < moderator < admin < super_admin.
// Every authorization check goes through `hasPermission()` or the
// `requireRole()` helpers — never trust a role string from the client.
// ────────────────────────────────────────────────────────────────────────────

export const ROLES = {
  USER: 'user',
  MODERATOR: 'moderator',
  ADMIN: 'admin',
  SUPER_ADMIN: 'super_admin',
} as const

export type Role = (typeof ROLES)[keyof typeof ROLES]

/** Numeric hierarchy for comparison. Higher = more privileged. */
const ROLE_LEVEL: Record<string, number> = {
  user: 1,
  moderator: 2,
  admin: 3,
  super_admin: 4,
}

export function roleLevel(role: string): number {
  return ROLE_LEVEL[role] ?? 0
}

/** Returns true if `role` meets or exceeds the required minimum role. */
export function hasRole(userRole: string, required: Role): boolean {
  return roleLevel(userRole) >= roleLevel(required)
}

/** Granular permission checks. */
export type Permission =
  | 'profile:read' | 'profile:write'
  | 'conversation:read' | 'conversation:write' | 'conversation:delete'
  | 'memory:read' | 'memory:write' | 'memory:delete'
  | 'chat:send'
  | 'search:use'
  | 'export:own'
  | 'settings:read' | 'settings:write'
  | 'admin:dashboard' | 'admin:users' | 'admin:conversations'
  | 'admin:usage' | 'admin:logs' | 'admin:ai'
  | 'admin:userRoles' // change roles
  | 'admin:banUser'
  | 'admin:deleteContent'

const PERMISSION_MATRIX: Record<string, Permission[]> = {
  user: [
    'profile:read', 'profile:write',
    'conversation:read', 'conversation:write', 'conversation:delete',
    'memory:read', 'memory:write', 'memory:delete',
    'chat:send', 'search:use', 'export:own',
    'settings:read', 'settings:write',
  ],
  moderator: [
    // inherits all user permissions
    'admin:conversations', 'admin:deleteContent', 'admin:banUser', 'admin:logs',
  ],
  admin: [
    // inherits moderator permissions
    'admin:dashboard', 'admin:users', 'admin:usage', 'admin:ai',
  ],
  super_admin: [
    // inherits admin permissions
    'admin:userRoles',
  ],
}

export function hasPermission(userRole: string, permission: Permission): boolean {
  // Check each role at or below the user's level for the permission.
  const level = roleLevel(userRole)
  for (const [role, perms] of Object.entries(PERMISSION_MATRIX)) {
    if (roleLevel(role) <= level && perms.includes(permission)) {
      return true
    }
  }
  return false
}

/**
 * Returns the effective permissions for a role (inherited from lower roles).
 */
export function getPermissions(userRole: string): Permission[] {
  const level = roleLevel(userRole)
  const result: Permission[] = []
  for (const [role, perms] of Object.entries(PERMISSION_MATRIX)) {
    if (roleLevel(role) <= level) {
      result.push(...perms)
    }
  }
  return Array.from(new Set(result))
}
