import { cookies } from 'next/headers'
import { db } from './db'
import { generateSessionToken, constantTimeEqual, hashToken } from './crypto'
import { hasRole, ROLES, type Role } from './rbac'

export const SESSION_COOKIE = 'sid'
const SESSION_TTL_DAYS = 30
const REMEMBER_TTL_DAYS = 90
// Window during which a "recent authentication" is considered valid for
// sensitive operations (password change, 2FA toggle, account deletion).
const RECENT_AUTH_WINDOW_MS = 15 * 60 * 1000 // 15 minutes

export interface AuthUser {
  id: string
  email: string
  name: string | null
  role: string
  emailVerified: Date | null
  avatarUrl: string | null
  twoFactorEnabled: boolean
  lastAuthAt: Date | null
}

export function getSessionMaxAge(remember: boolean): number {
  return remember ? REMEMBER_TTL_DAYS * 24 * 60 * 60 : SESSION_TTL_DAYS * 24 * 60 * 60
}

export async function createSession(userId: string, opts?: { remember?: boolean; ip?: string; userAgent?: string }) {
  const remember = opts?.remember ?? true
  const token = generateSessionToken()
  const expiresAt = new Date(Date.now() + getSessionMaxAge(remember) * 1000)

  await db.session.create({
    data: {
      userId,
      token: hashToken(token), // Store HASHED session token — prevents session hijacking if DB is leaked
      expiresAt,
      ip: opts?.ip ?? null,
      userAgent: opts?.userAgent ?? null,
    },
  })

  // Update lastAuthAt — used for "recent authentication" checks on sensitive ops.
  await db.user.update({ where: { id: userId }, data: { lastAuthAt: new Date() } }).catch(() => {})

  const cookieStore = await cookies()
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax', // CSRF protection: cookies aren't sent on cross-site POSTs
    path: '/',
    maxAge: getSessionMaxAge(remember),
  })

  return token
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(SESSION_COOKIE)?.value
    if (!token) return null

    // Look up by hashed token (constant-time lookup not needed — DB index is fast).
    const session = await db.session.findUnique({
      where: { token: hashToken(token) },
      include: { user: true },
    })

    if (!session) return null
    if (session.expiresAt < new Date()) {
      await db.session.delete({ where: { id: session.id } }).catch(() => {})
      return null
    }

    const u = session.user
    return {
      id: u.id,
      email: u.email,
      name: u.name,
      role: u.role,
      emailVerified: u.emailVerified,
      avatarUrl: u.avatarUrl,
      twoFactorEnabled: u.twoFactorEnabled ?? false,
      lastAuthAt: u.lastAuthAt ?? null,
    }
  } catch {
    return null
  }
}

export async function requireUser(): Promise<AuthUser> {
  const user = await getCurrentUser()
  if (!user) {
    throw new UnauthorizedError('Authentication required')
  }
  return user
}

export async function requireRole(minimum: Role) {
  const user = await requireUser()
  if (!hasRole(user.role, minimum)) {
    throw new ForbiddenError(`${minimum} access required`)
  }
  return user
}

export async function requireAdmin() {
  return requireRole(ROLES.ADMIN)
}

export async function requireSuperAdmin() {
  return requireRole(ROLES.SUPER_ADMIN)
}

/**
 * Requires that the user has authenticated recently (within RECENT_AUTH_WINDOW_MS).
 * Used for sensitive operations: password change, email change, 2FA toggle,
 * account deletion, role changes.
 *
 * If the session is too old, throws 401 with a code the frontend can use to
 * trigger a re-authentication flow.
 */
export async function requireRecentAuth(): Promise<AuthUser> {
  const user = await requireUser()
  if (!user.lastAuthAt || Date.now() - user.lastAuthAt.getTime() > RECENT_AUTH_WINDOW_MS) {
    const err = new UnauthorizedError('Recent authentication required for this action.')
    ;(err as any).code = 'RECENT_AUTH_REQUIRED'
    throw err
  }
  return user
}

export async function destroySession(): Promise<void> {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  if (token) {
    await db.session.deleteMany({ where: { token: hashToken(token) } }).catch(() => {})
  }
  cookieStore.delete(SESSION_COOKIE)
}

export async function destroyAllUserSessions(userId: string): Promise<void> {
  await db.session.deleteMany({ where: { userId } }).catch(() => {})
  const cookieStore = await cookies()
  cookieStore.delete(SESSION_COOKIE)
}

/**
 * Destroy all sessions for a user EXCEPT the current one. Used when a user
 * clicks "Log out all other devices" from the session management page.
 */
export async function destroyOtherSessions(userId: string): Promise<void> {
  const cookieStore = await cookies()
  const currentToken = cookieStore.get(SESSION_COOKIE)?.value
  if (currentToken) {
    await db.session.deleteMany({
      where: { userId, NOT: { token: hashToken(currentToken) } },
    }).catch(() => {})
  }
}

// ───────────────────────── Error classes ─────────────────────────

export class UnauthorizedError extends Error {
  status = 401
}
export class ForbiddenError extends Error {
  status = 403
}
export class BadRequestError extends Error {
  status = 400
}
export class NotFoundError extends Error {
  status = 404
}
export class ConflictError extends Error {
  status = 409
}
export class TooManyRequestsError extends Error {
  status = 429
}

export { constantTimeEqual }
