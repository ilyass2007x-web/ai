import bcrypt from 'bcryptjs'
import { randomBytes, randomUUID, createHash, timingSafeEqual } from 'crypto'

const BCRYPT_ROUNDS = 12

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    return await bcrypt.compare(password, hash)
  } catch {
    return false
  }
}

export function generateToken(bytes = 32): string {
  return randomBytes(bytes).toString('hex')
}

export function generateSessionToken(): string {
  // URL-safe, opaque session token
  return `${randomUUID()}.${generateToken(24)}`
}

/**
 * Hash a token (reset/verification/2FA) with SHA-256 before storing it in
 * the database. This ensures that even if the database is compromised,
 * attackers cannot use stored tokens directly — they'd need to brute-force
 * the SHA-256 hash, which is computationally infeasible.
 *
 * The raw token is only ever sent to the user (via email link or API response
 * in dev mode); the database only stores the hash.
 */
export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

/**
 * Constant-time string comparison to prevent timing attacks when comparing
 * tokens or hashes.
 */
export function constantTimeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a)
  const bufB = Buffer.from(b)
  if (bufA.length !== bufB.length) return false
  return timingSafeEqual(bufA, bufB)
}
