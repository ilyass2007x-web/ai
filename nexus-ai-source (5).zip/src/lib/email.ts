// Pluggable email module. In production, set EMAIL_PROVIDER + EMAIL_API_KEY
// to a real provider (e.g. "resend", "sendgrid") and implement send().
//
// In development (EMAIL_PROVIDER="console" or no API key configured), the
// verification/reset links are returned by the auth API endpoints so the
// developer can complete the flow without an SMTP server.

export interface EmailPayload {
  to: string
  subject: string
  html: string
  text: string
}

export interface EmailResult {
  delivered: boolean
  previewUrl?: string // dev-only: shown to the user to complete the flow locally
  providerMessage?: string
}

export async function sendEmail(payload: EmailPayload): Promise<EmailResult> {
  const provider = (process.env.EMAIL_PROVIDER ?? 'console').toLowerCase()

  if (provider === 'console' || !process.env.EMAIL_API_KEY) {
    // Dev mode: log and return the link so the flow is completable.
    console.log(`[EMAIL:console] to=${payload.to} subject=${payload.subject}\n${payload.text}`)
    return { delivered: true, providerMessage: 'Dev mode: email logged server-side.' }
  }

  // ── Production provider hooks ──────────────────────────────────────
  // Example (Resend) — uncomment & install `resend` if needed:
  //
  // if (provider === 'resend') {
  //   const { Resend } = await import('resend')
  //   const client = new Resend(process.env.EMAIL_API_KEY)
  //   await client.emails.send({
  //     from: process.env.EMAIL_FROM || 'no-reply@example.com',
  //     to: payload.to,
  //     subject: payload.subject,
  //     html: payload.html,
  //   })
  //   return { delivered: true }
  // }

  // Unknown provider fallback to console.
  console.warn(`[EMAIL] Unknown provider "${provider}", falling back to console.`)
  return { delivered: true, providerMessage: 'Email provider not configured; logged server-side.' }
}

export function emailTemplates() {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000'
  return {
    verification: (name: string | null, token: string) => ({
      subject: 'Verify your email address',
      text: `Hi ${name ?? 'there'},\n\nPlease verify your email by visiting:\n${appUrl}/?verify=${token}\n\nThis link expires in 24 hours.`,
      html: `<p>Hi ${name ?? 'there'},</p><p>Please verify your email by clicking below:</p><p><a href="${appUrl}/?verify=${token}">Verify email</a></p><p style="color:#888;font-size:12px">Or paste this link: ${appUrl}/?verify=${token}</p><p>This link expires in 24 hours.</p>`,
      link: `${appUrl}/?verify=${token}`,
    }),
    passwordReset: (name: string | null, token: string) => ({
      subject: 'Reset your password',
      text: `Hi ${name ?? 'there'},\n\nReset your password by visiting:\n${appUrl}/?reset=${token}\n\nIf you didn't request this, ignore this email. This link expires in 1 hour.`,
      html: `<p>Hi ${name ?? 'there'},</p><p>Reset your password by clicking below:</p><p><a href="${appUrl}/?reset=${token}">Reset password</a></p><p style="color:#888;font-size:12px">Or paste this link: ${appUrl}/?reset=${token}</p><p>If you didn't request this, ignore this email. This link expires in 1 hour.</p>`,
      link: `${appUrl}/?reset=${token}`,
    }),
  }
}
