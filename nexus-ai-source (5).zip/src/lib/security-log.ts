import { db } from './db'

// ────────────────────────────────────────────────────────────────────────────
// Security audit logging.
//
// Records important security events (login, logout, password changes, 2FA,
// admin actions, suspicious activity) to the SecurityLog table.
//
// NEVER logs: passwords, API secrets, session tokens, reset tokens, 2FA secrets.
// ────────────────────────────────────────────────────────────────────────────

export type SecurityEvent =
  | 'login_success'
  | 'login_failure'
  | 'logout'
  | 'register'
  | 'password_change'
  | 'password_reset'
  | 'email_verification'
  | 'email_change'
  | '2fa_enable'
  | '2fa_disable'
  | '2fa_challenge'
  | 'session_revoked'
  | 'session_revoked_all'
  | 'account_delete'
  | 'role_change'
  | 'admin_action'
  | 'rate_limit_hit'
  | 'suspicious_activity'

export interface SecurityLogEntry {
  userId?: string | null
  event: SecurityEvent
  ip?: string | null
  userAgent?: string | null
  metadata?: Record<string, unknown>
}

/**
 * Log a security event. Best-effort — failures are silently swallowed
 * so they never break the main request flow.
 */
export async function logSecurityEvent(entry: SecurityLogEntry): Promise<void> {
  try {
    await db.securityLog.create({
      data: {
        userId: entry.userId ?? null,
        event: entry.event,
        ip: entry.ip ?? null,
        userAgent: entry.userAgent ?? null,
        metadata: (entry.metadata as any) ?? undefined,
      },
    })
  } catch {
    // Never let logging failures break the request.
  }
}
