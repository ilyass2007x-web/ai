import { NextRequest } from 'next/server'

export async function parseJson<T = unknown>(req: NextRequest): Promise<T> {
  try {
    const text = await req.text()
    return JSON.parse(text || '{}') as T
  } catch {
    throw new SyntaxError('Invalid JSON body')
  }
}
