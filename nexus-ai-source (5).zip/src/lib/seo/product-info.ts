// ────────────────────────────────────────────────────────────────────────────
// Nexus AI — Central Product Definition (Single Source of Truth)
//
// This file is the canonical source of all product information used across
// the website, structured data, llms.txt, FAQ, documentation, and metadata.
// When a feature changes, update it here and every page stays consistent.
// ────────────────────────────────────────────────────────────────────────────

export const PRODUCT = {
  name: 'Nexus AI',
  tagline: 'Your intelligent assistant with real memory and live web research.',
  description:
    'Nexus AI is an independent AI conversational platform that combines streaming AI chat, live web research with source citations, and persistent long-term memory. It searches the internet when fresh information is needed, remembers useful context across conversations, and provides accurate, cited answers.',
  longDescription:
    'Nexus AI is a provider-agnostic AI assistant platform built on Neon PostgreSQL. It features secure email/password authentication with optional two-factor authentication, multi-conversation management with search and export, streaming AI responses, intelligent web research with authority-ranked sources, persistent memory that extracts and recalls durable user context, conversation summarization for long chats, and a provider abstraction layer that supports OpenAI, Anthropic, OpenRouter, Ollama, and any OpenAI-compatible endpoint.',
  officialUrl: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
  contactEmail: 'contact@nexus.ai',
  supportEmail: 'support@nexus.ai',
  version: '1.0',
  category: 'AI Assistant Platform',
  applicationCategory: 'ChatApplication',
  operatingSystem: 'Web',
  offers: 'Free-tier available with generous usage limits.',
  supportedLanguages: ['English', 'Français', 'العربية (Arabic/Darija)'],
  aiLanguages: ['en', 'ar', 'fr'],
} as const

export const FEATURES = [
  {
    slug: 'ai-chat',
    name: 'AI Chat',
    title: 'Streaming AI Chat with Real-Time Responses',
    description:
      'Engage in natural conversations with an AI assistant that streams responses token-by-token. Supports markdown rendering, syntax-highlighted code blocks, tables, lists, and copy/regenerate actions.',
    longDescription:
      'Nexus AI provides a premium chat experience inspired by modern AI assistants. Messages render with full markdown support including syntax-highlighted code blocks, tables, and blockquotes. Users can copy responses, regenerate answers, and provide thumbs-up/down feedback. The streaming architecture delivers responses incrementally via Server-Sent Events, so you see the answer as it is generated — no waiting for the full response.',
    capabilities: [
      'Token-by-token streaming via Server-Sent Events',
      'Full markdown rendering with syntax highlighting',
      'Copy, regenerate, and feedback actions on every response',
      'Stop generation mid-stream',
      'Multi-conversation management with pin, archive, rename, and search',
      'Export conversations as Markdown, TXT, or JSON',
    ],
  },
  {
    slug: 'web-research',
    name: 'Web Research',
    title: 'Intelligent Web Research with Source Citations',
    description:
      'Nexus AI decides when web research is necessary, searches authoritative sources, ranks results by credibility, and cites every factual claim with clickable source links.',
    longDescription:
      'Unlike simple chatbots, Nexus AI has an independent web research layer. An LLM-based decision router evaluates whether a question requires fresh internet information. When it does, Nexus searches multiple sources, deduplicates results, ranks them by authority (government, educational, official documentation preferred), extracts relevant content, and injects it into the AI context as data — not instructions. This prevents prompt injection from web content. Every factual claim derived from web research is cited with numbered, clickable source links.',
    capabilities: [
      'LLM-based decision router determines when to search',
      'Authority-based source ranking (gov, edu, docs preferred)',
      'Deduplication and content extraction',
      'Prompt-injection-safe context injection',
      'Numbered clickable citations in responses',
      'Independent from any AI provider — switchable search backend',
    ],
  },
  {
    slug: 'memory',
    name: 'Long-Term Memory',
    title: 'Persistent Memory That Remembers What Matters',
    description:
      'Nexus AI extracts durable facts about you across conversations and retrieves them using hybrid full-text + keyword search. You have full control to view, edit, delete, or disable memory.',
    longDescription:
      'Nexus AI maintains a personal memory system stored in Neon PostgreSQL. After important conversations, a memory extraction layer identifies durable information worth remembering — your name, projects, tech stack, preferences — and stores it securely. Sensitive data like passwords, API keys, and tokens are never stored. When you ask a new question, Nexus retrieves relevant memories using a hybrid of PostgreSQL full-text search and keyword overlap, then includes them as context. You can view, edit, delete individual memories, clear all memories, or disable the feature entirely from Settings.',
    capabilities: [
      'Automatic extraction of durable user facts',
      'Sensitive data filtering (passwords, keys, tokens never stored)',
      'Hybrid retrieval: PostgreSQL full-text + keyword search',
      'Memory deduplication with similarity scoring',
      'Full user control: view, edit, delete, disable',
      'Per-user isolation — memories never cross accounts',
    ],
  },
  {
    slug: 'ai-search',
    name: 'Conversation Search',
    title: 'Search Across All Your Conversations',
    description:
      'Find any conversation, message, or memory instantly with global full-text search across titles, message contents, and stored memories.',
    longDescription:
      'Nexus AI indexes every conversation title, message content, and stored memory in PostgreSQL. The global search feature lets you find past discussions, code snippets, research results, and AI answers by keyword. Search results are grouped by conversations, messages, and memories, with one-click navigation to the relevant conversation.',
    capabilities: [
      'Global full-text search across conversations, messages, and memories',
      'Grouped results by category',
      'Instant filtering in the sidebar',
      'One-click navigation to results',
      'PostgreSQL-powered (no external search service needed)',
    ],
  },
  {
    slug: 'multilingual',
    name: 'Multilingual AI',
    title: 'Multilingual Support with Auto-Detection',
    description:
      'Nexus AI detects the language you write in and responds in the same language. Supports English, French, and Arabic (including Darija).',
    longDescription:
      'Nexus AI automatically detects the language of your message and responds in the same language. The interface supports English, French, and Arabic, with Arabic support including Moroccan Darija. Language preferences are stored per user and can be changed in Settings.',
    capabilities: [
      'Automatic language detection',
      'English, French, and Arabic (Darija) support',
      'Per-user language preference',
      'RTL (right-to-left) layout support for Arabic',
      'Configurable interface language in Settings',
    ],
  },
] as const

export const USE_CASES = [
  {
    slug: 'students',
    title: 'For Students',
    description: 'Research, learn, and study with an AI that remembers your courses and preferences.',
    points: [
      'Ask complex questions and get cited, research-backed answers',
      'Web research for current events, latest data, and academic sources',
      'Memory remembers your field of study and learning style',
      'Export conversations as study notes (Markdown)',
    ],
  },
  {
    slug: 'developers',
    title: 'For Developers',
    description: 'Code assistance, technical research, and a provider-agnostic architecture you control.',
    points: [
      'Syntax-highlighted code blocks with copy button',
      'Web research for latest API docs, library versions, and Stack Overflow answers',
      'Memory remembers your tech stack and project context',
      'Provider-agnostic: connect OpenAI, Ollama, or your own model server',
    ],
  },
  {
    slug: 'research',
    title: 'For Researchers',
    description: 'Authoritative source ranking and citation tracking for academic-quality research.',
    points: [
      'Authority-ranked sources (gov, edu, scientific publications preferred)',
      'Every web-sourced claim is cited with clickable links',
      'Distinguishes between fact, opinion, and uncertain information',
      'Conversation summaries for long research sessions',
    ],
  },
  {
    slug: 'content-creators',
    title: 'For Content Creators',
    description: 'Brainstorm, draft, and research with persistent context across sessions.',
    points: [
      'Memory remembers your brand voice, audience, and content themes',
      'Web research for trending topics and current information',
      'Export conversations for content planning',
      'Multilingual support for global audiences',
    ],
  },
  {
    slug: 'business',
    title: 'For Business',
    description: 'Secure, private AI assistant with enterprise-grade authentication and data isolation.',
    points: [
      'Enterprise security: bcrypt hashing, HTTP-only sessions, CSRF protection',
      'RBAC with user, moderator, admin, and super_admin roles',
      'Rate limiting and brute-force protection',
      'Data never crosses between user accounts',
      'Admin dashboard with usage analytics and security audit logs',
    ],
  },
] as const

export const FAQS = [
  {
    question: 'What is Nexus AI?',
    answer:
      'Nexus AI is an independent AI conversational platform that combines streaming chat, live web research with citations, and persistent long-term memory. It is built on Neon PostgreSQL and uses a provider-agnostic architecture so the underlying AI model can be changed via configuration.',
  },
  {
    question: 'What can Nexus AI do?',
    answer:
      'Nexus AI can hold multi-conversation chat sessions, search the web for current information and cite its sources, remember useful facts about you across conversations, summarize long conversations, search through your past conversations, and export your data. It supports markdown rendering with code syntax highlighting.',
  },
  {
    question: 'Can Nexus AI search the web?',
    answer:
      'Yes. Nexus AI has an independent web research layer. An LLM-based decision router determines when fresh internet information is needed, searches authoritative sources, ranks them by credibility, and includes clickable citations in the response. Web content is treated as data, never as instructions, to prevent prompt injection.',
  },
  {
    question: 'Does Nexus AI remember conversations?',
    answer:
      'Yes. Nexus AI has a persistent memory system that extracts durable facts about you (name, projects, preferences, tech stack) and stores them in Neon PostgreSQL. Memories are retrieved using hybrid full-text + keyword search. Sensitive data like passwords and API keys are never stored. You can view, edit, delete, or disable memory at any time.',
  },
  {
    question: 'Is Nexus AI free?',
    answer:
      'Nexus AI offers a free tier with generous usage limits. The platform is designed to work with low-cost providers and local models (via Ollama) to minimize operating costs. Usage limits include rate limiting per minute and per day.',
  },
  {
    question: 'What languages does Nexus AI support?',
    answer:
      'Nexus AI supports English, French, and Arabic (including Moroccan Darija). The AI automatically detects the language you write in and responds in the same language. The interface language can be configured in Settings.',
  },
  {
    question: 'How does Nexus AI protect user data?',
    answer:
      'Nexus AI uses enterprise-grade security: passwords are hashed with bcrypt (12 rounds), sessions use opaque HTTP-only cookies with SameSite protection, all tokens (session, reset, verification) are SHA-256 hashed at rest, rate limiting prevents brute-force attacks, and every database query is scoped to the authenticated user (preventing IDOR). The admin dashboard includes a security audit log.',
  },
  {
    question: 'How do I create an account?',
    answer:
      'Click "Sign up" on the homepage, enter your name, email, and a strong password (minimum 8 characters with at least one letter and one number). A verification email will be sent to confirm your address. After verification, you can start chatting immediately.',
  },
  {
    question: 'Is Nexus AI an independent AI platform?',
    answer:
      'Yes. Nexus AI is a provider-agnostic platform. It does not depend on any single AI provider (GLM, OpenAI, etc.). The application communicates only with a universal AIProvider interface. Switching the underlying model requires only environment variable changes — no code modifications.',
  },
  {
    question: 'Can I use my own AI model with Nexus AI?',
    answer:
      'Yes. Nexus AI supports any OpenAI-compatible endpoint, including OpenAI, OpenRouter, Together, Groq, Ollama (local), and custom self-hosted servers. Set AI_PROVIDER, AI_MODEL, AI_BASE_URL, and AI_API_KEY in your environment configuration.',
  },
  {
    question: 'Can I export my conversations?',
    answer:
      'Yes. Every conversation can be exported as Markdown, plain text, or JSON. The export belongs only to you and includes all messages and web sources.',
  },
  {
    question: 'Does Nexus AI work on mobile?',
    answer:
      'Yes. Nexus AI is fully responsive and optimized for iPhone SE, iPhone Pro Max, Android phones, tablets, iPads, laptops, and desktop monitors. The interface uses a mobile-first design with fluid typography, touch-friendly targets, and iOS safe-area support.',
  },
] as const

export const NAV_LINKS = [
  { href: '/about', label: 'About' },
  { href: '/features', label: 'Features' },
  { href: '/use-cases', label: 'Use Cases' },
  { href: '/docs', label: 'Documentation' },
  { href: '/faq', label: 'FAQ' },
  { href: '/blog', label: 'Blog' },
] as const
