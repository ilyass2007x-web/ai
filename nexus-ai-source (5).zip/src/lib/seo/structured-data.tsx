// ────────────────────────────────────────────────────────────────────────────
// JSON-LD Structured Data generators.
//
// These produce valid schema.org JSON-LD for search engines and AI systems.
// Only factual, verified information is included — no invented data.
// ────────────────────────────────────────────────────────────────────────────

import { PRODUCT, FAQS } from './product-info'

export function organizationStructuredData() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: PRODUCT.name,
    description: PRODUCT.description,
    url: PRODUCT.officialUrl,
    email: PRODUCT.contactEmail,
    logo: `${PRODUCT.officialUrl}/logo.svg`,
  }
}

export function webSiteStructuredData() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: PRODUCT.name,
    url: PRODUCT.officialUrl,
    description: PRODUCT.description,
    potentialAction: {
      '@type': 'SearchAction',
      target: `${PRODUCT.officialUrl}/?q={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
  }
}

export function webApplicationStructuredData() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: PRODUCT.name,
    description: PRODUCT.description,
    url: PRODUCT.officialUrl,
    applicationCategory: PRODUCT.applicationCategory,
    operatingSystem: PRODUCT.operatingSystem,
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
      description: PRODUCT.offers,
    },
    featureList: [
      'Streaming AI chat with markdown and code highlighting',
      'Web research with authority-ranked sources and citations',
      'Persistent long-term memory with hybrid search',
      'Conversation search and export',
      'Multilingual support (English, French, Arabic)',
      'Provider-agnostic AI architecture',
      'Enterprise-grade security with RBAC',
    ],
    audience: {
      '@type': 'Audience',
      audienceType: 'General users, developers, students, researchers, businesses',
    },
  }
}

export function faqStructuredData(faqs: { question: string; answer: string }[] = [...FAQS]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((f) => ({
      '@type': 'Question',
      name: f.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: f.answer,
      },
    })),
  }
}

export function breadcrumbStructuredData(items: { name: string; url: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  }
}

export function articleStructuredData(article: {
  title: string
  description: string
  slug: string
  author: string
  publishedAt: string
  updatedAt?: string
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: article.title,
    description: article.description,
    url: `${PRODUCT.officialUrl}/blog/${article.slug}`,
    author: {
      '@type': 'Organization',
      name: article.author || PRODUCT.name,
    },
    publisher: {
      '@type': 'Organization',
      name: PRODUCT.name,
      logo: { '@type': 'ImageObject', url: `${PRODUCT.officialUrl}/logo.svg` },
    },
    datePublished: article.publishedAt,
    dateModified: article.updatedAt || article.publishedAt,
  }
}

/** Renders a JSON-LD script tag. */
export function JsonLd({ data }: { data: Record<string, unknown> }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  )
}
