export interface User {
  id: string
  email: string
  name: string | null
  role: string
  emailVerified: Date | null
  avatarUrl: string | null
}

export interface Conversation {
  id: string
  title: string
  archived: boolean
  pinned: boolean
  createdAt: string
  updatedAt: string
  _count?: { messages: number }
}

export interface Source {
  id?: string
  url: string
  title: string
  domain: string
  snippet?: string
  rank?: number
  score?: number
}

export interface Message {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  model?: string | null
  tokenUsage?: number | null
  createdAt: string
  sources?: { source: Source }[]
}

export interface UserSettings {
  userId: string
  model: string | null
  temperature: number
  responseStyle: 'concise' | 'balanced' | 'detailed'
  memoryEnabled: boolean
  webSearchEnabled: boolean
  language: 'en' | 'ar' | 'fr'
  theme: 'light' | 'dark' | 'system'
}

/** Sanitized AI status returned by /api/admin/ai (no secrets). */
export interface AIStatus {
  primary: { provider: string; model: string; baseUrl: string | null; apiKeyConfigured: boolean } | null
  fallback: { provider: string; model: string; baseUrl: string | null; apiKeyConfigured: boolean } | null
  embedding: { provider: string; model: string; baseUrl: string | null; apiKeyConfigured: boolean } | null
  tierLabel: string
  availableProviders: string[]
}

export interface Memory {
  id: string
  content: string
  memoryType: string
  importance: number
  keywords: string[]
  createdAt: string
  updatedAt: string
}

export type AppView = 'chat' | 'settings' | 'admin' | 'search'
export type AuthView = 'login' | 'register' | 'forgot' | 'reset' | 'verify'
