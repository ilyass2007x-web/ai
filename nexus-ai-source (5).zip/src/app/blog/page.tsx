import type { Metadata } from 'next'
import Link from 'next/link'
import { db } from '@/lib/db'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `Blog — ${PRODUCT.name}`,
  description: 'Articles, tutorials, guides, and product updates from Nexus AI.',
  alternates: { canonical: `${PRODUCT.officialUrl}/blog` },
  robots: { index: true, follow: true },
}

export const dynamic = 'force-dynamic'

export default async function BlogPage() {
  const articles = await db.article.findMany({
    where: { published: true },
    orderBy: { publishedAt: 'desc' },
    select: { id: true, slug: true, title: true, description: true, category: true, tags: true, publishedAt: true, author: { select: { name: true } } },
    take: 50,
  }).catch(() => [])

  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Blog', url: `${PRODUCT.officialUrl}/blog` },
      ])} />

      <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Blog</h1>
        <p className="mt-3 text-muted-foreground">Articles, tutorials, guides, and product updates.</p>

        {articles.length === 0 ? (
          <div className="mt-10 rounded-lg border border-dashed border-border p-10 text-center text-muted-foreground">
            No articles published yet. Check back soon!
          </div>
        ) : (
          <div className="mt-10 space-y-6">
            {articles.map((article) => (
              <Link
                key={article.id}
                href={`/blog/${article.slug}`}
                className="block rounded-xl border border-border bg-card p-5 transition-colors hover:border-brand/40"
              >
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="rounded-full bg-brand/10 px-2 py-0.5 text-brand">{article.category}</span>
                  {article.publishedAt && (
                    <time dateTime={article.publishedAt.toISOString()}>
                      {article.publishedAt.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                    </time>
                  )}
                </div>
                <h2 className="mt-2 font-semibold">{article.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{article.description}</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </MarketingPage>
  )
}
