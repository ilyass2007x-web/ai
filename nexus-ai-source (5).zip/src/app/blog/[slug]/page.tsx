import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { db } from '@/lib/db'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, articleStructuredData, JsonLd } from '@/lib/seo/structured-data'
import { Markdown } from '@/components/chat/markdown'

interface Props { params: Promise<{ slug: string }> }

export const dynamic = 'force-dynamic'

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const article = await db.article.findUnique({ where: { slug, published: true } }).catch(() => null)
  if (!article) return { title: 'Article not found' }
  return {
    title: `${article.title} — ${PRODUCT.name} Blog`,
    description: article.description,
    alternates: { canonical: `${PRODUCT.officialUrl}/blog/${article.slug}` },
    openGraph: {
      title: article.title,
      description: article.description,
      url: `${PRODUCT.officialUrl}/blog/${article.slug}`,
      type: 'article',
      publishedTime: article.publishedAt?.toISOString(),
    },
    robots: { index: true, follow: true },
  }
}

export default async function BlogArticlePage({ params }: Props) {
  const { slug } = await params
  const article = await db.article.findUnique({
    where: { slug, published: true },
    include: { author: { select: { name: true } } },
  }).catch(() => null)

  if (!article) notFound()

  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Blog', url: `${PRODUCT.officialUrl}/blog` },
        { name: article.title, url: `${PRODUCT.officialUrl}/blog/${article.slug}` },
      ])} />
      <JsonLd data={articleStructuredData({
        title: article.title,
        description: article.description,
        slug: article.slug,
        author: article.author?.name || PRODUCT.name,
        publishedAt: article.publishedAt?.toISOString() || article.createdAt.toISOString(),
        updatedAt: article.updatedAt.toISOString(),
      })} />

      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <Link href="/blog" className="text-sm text-muted-foreground hover:text-foreground">← Back to blog</Link>

        <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
          <span className="rounded-full bg-brand/10 px-2 py-0.5 text-brand">{article.category}</span>
          {article.publishedAt && (
            <time dateTime={article.publishedAt.toISOString()}>
              {article.publishedAt.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
            </time>
          )}
        </div>

        <h1 className="mt-3 text-fluid-xl font-bold tracking-tight">{article.title}</h1>
        <p className="mt-3 text-lg text-muted-foreground">{article.description}</p>

        {article.author?.name && (
          <p className="mt-4 text-sm text-muted-foreground">By {article.author.name}</p>
        )}

        <div className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <Markdown content={article.content} />
        </div>

        {article.tags.length > 0 && (
          <div className="mt-8 flex flex-wrap gap-2">
            {article.tags.map((tag) => (
              <span key={tag} className="rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">#{tag}</span>
            ))}
          </div>
        )}
      </article>
    </MarketingPage>
  )
}
