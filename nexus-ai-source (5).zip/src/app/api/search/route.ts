import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, requireUser } from '@/lib/session'
import { searchSchema } from '@/lib/validation'

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser()
    const body = await parseJson(req)
    const parsed = searchSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError('Query is required')

    const q = parsed.data.q
    // Full-text search across conversation titles + message contents + memories.
    const [conversations, messages, memories] = await Promise.all([
      db.conversation.findMany({
        where: {
          userId: user.id,
          OR: [
            { title: { contains: q, mode: 'insensitive' } },
            { summary: { contains: q, mode: 'insensitive' } },
          ],
        },
        orderBy: { updatedAt: 'desc' },
        take: 20,
        select: { id: true, title: true, archived: true, updatedAt: true },
      }),
      db.message.findMany({
        where: {
          userId: user.id,
          content: { contains: q, mode: 'insensitive' },
        },
        orderBy: { createdAt: 'desc' },
        take: 30,
        select: {
          id: true, content: true, role: true, createdAt: true,
          conversation: { select: { id: true, title: true } },
        },
      }),
      db.memory.findMany({
        where: { userId: user.id, content: { contains: q, mode: 'insensitive' } },
        orderBy: { updatedAt: 'desc' },
        take: 20,
        select: { id: true, content: true, memoryType: true, updatedAt: true },
      }),
    ])

    return ok({ conversations, messages, memories })
  } catch (e) {
    return errorResponse(e)
  }
}
