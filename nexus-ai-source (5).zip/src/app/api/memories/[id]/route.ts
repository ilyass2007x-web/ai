import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, NotFoundError, requireUser } from '@/lib/session'
import { updateMemorySchema } from '@/lib/validation'

interface Params { params: Promise<{ id: string }> }

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const user = await requireUser()
    const { id } = await params
    const body = await parseJson(req)
    const parsed = updateMemorySchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    const existing = await db.memory.findFirst({ where: { id, userId: user.id } })
    if (!existing) throw new NotFoundError('Memory not found')

    const memory = await db.memory.update({
      where: { id },
      data: parsed.data,
    })
    return ok({ memory })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const user = await requireUser()
    const { id } = await params
    const existing = await db.memory.findFirst({ where: { id, userId: user.id } })
    if (!existing) throw new NotFoundError('Memory not found')
    await db.memory.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
