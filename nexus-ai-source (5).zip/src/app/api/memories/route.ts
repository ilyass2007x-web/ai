import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireUser } from '@/lib/session'

export async function GET() {
  try {
    const user = await requireUser()
    const memories = await db.memory.findMany({
      where: { userId: user.id },
      orderBy: [{ importance: 'desc' }, { updatedAt: 'desc' }],
      select: { id: true, content: true, memoryType: true, importance: true, keywords: true, createdAt: true, updatedAt: true },
    })
    const settings = await db.userSettings.findUnique({ where: { userId: user.id } })
    return ok({ memories, memoryEnabled: settings?.memoryEnabled ?? true })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await requireUser()
    const url = new URL(req.url)
    const all = url.searchParams.get('all')
    if (all === 'true') {
      await db.memory.deleteMany({ where: { userId: user.id } })
      return ok({ ok: true, deleted: 'all' })
    }
    return ok({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
