import { NextRequest } from 'next/server'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, NotFoundError, requireUser } from '@/lib/session'
import { prepareRegenerate } from '@/lib/ai/orchestrator'
import { regenerateSchema } from '@/lib/validation'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser()
    const body = await parseJson(req)
    const parsed = regenerateSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    const prepared = await prepareRegenerate({
      user,
      conversationId: parsed.data.conversationId,
      messageId: parsed.data.messageId,
    })

    const encoder = new TextEncoder()
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const send = (event: string, data: unknown) => {
          controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`))
        }
        send('meta', {
          assistantMessageId: prepared.assistantMessageId,
          sources: prepared.sources,
        })
        try {
          for await (const delta of prepared.stream) {
            send('delta', { content: delta })
          }
          send('done', { ok: true })
        } catch (e) {
          send('error', { message: e instanceof Error ? e.message : 'Stream failed' })
        } finally {
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no',
      },
    })
  } catch (e) {
    // Keep NotFoundError import used.
    if (e instanceof NotFoundError) return errorResponse(e)
    return errorResponse(e)
  }
}
