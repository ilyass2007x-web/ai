import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, requireUser, TooManyRequestsError } from '@/lib/session'
import { rateLimit, LIMITS } from '@/lib/rate-limit'
import { prepareResponse } from '@/lib/ai/orchestrator'
import { z } from 'zod'

const chatSchema = z.object({
  conversationId: z.string().min(1).optional(),
  content: z.string().trim().min(1).max(32_000),
})

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser()

    const rlMin = rateLimit(`chat:${user.id}`, LIMITS.chat.limit, LIMITS.chat.windowMs)
    if (!rlMin.ok) throw new TooManyRequestsError('You are sending messages too fast. Please slow down.')
    const rlDay = rateLimit(`chat-daily:${user.id}`, LIMITS.chatDaily.limit, LIMITS.chatDaily.windowMs)
    if (!rlDay.ok) throw new TooManyRequestsError('Daily message limit reached. Please try again tomorrow.')

    const body = await parseJson(req)
    const parsed = chatSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')
    const { content } = parsed.data

    let conversationId = parsed.data.conversationId
    if (!conversationId) {
      const conv = await db.conversation.create({
        data: { userId: user.id, title: content.trim().slice(0, 60) },
      })
      conversationId = conv.id
    }

    const prepared = await prepareResponse({ user, conversationId, content })

    const encoder = new TextEncoder()
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const send = (event: string, data: unknown) => {
          controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`))
        }

        // 1. Announce the conversation + sources + assistant message id.
        send('meta', {
          conversationId,
          assistantMessageId: prepared.assistantMessageId,
          searchPerformed: prepared.searchPerformed,
          sources: prepared.sources,
        })

        // 2. Stream content deltas.
        try {
          for await (const delta of prepared.stream) {
            send('delta', { content: delta })
          }
          send('done', { ok: true })
        } catch (e) {
          send('error', {
            message: e instanceof Error ? e.message : 'Stream failed',
          })
        } finally {
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no',
      },
    })
  } catch (e) {
    return errorResponse(e)
  }
}
