import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, requireUser } from '@/lib/session'
import { updateSettingsSchema } from '@/lib/validation'

export async function GET() {
  try {
    const user = await requireUser()
    const settings = await db.userSettings.upsert({
      where: { userId: user.id },
      update: {},
      create: { userId: user.id },
    })
    return ok({ settings })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const user = await requireUser()
    const body = await parseJson(req)
    const parsed = updateSettingsSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    const settings = await db.userSettings.upsert({
      where: { userId: user.id },
      update: parsed.data,
      create: { userId: user.id, ...parsed.data },
    })
    return ok({ settings })
  } catch (e) {
    return errorResponse(e)
  }
}
