import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, destroyAllUserSessions, requireRecentAuth } from '@/lib/session'
import { deleteAccountSchema } from '@/lib/validation'
import { logSecurityEvent } from '@/lib/security-log'

export async function POST(req: NextRequest) {
  try {
    // Account deletion requires recent authentication (within 15 min).
    const user = await requireRecentAuth()
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'
    const ua = req.headers.get('user-agent') ?? undefined

    const body = await parseJson(req)
    const parsed = deleteAccountSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError('You must type DELETE to confirm.')

    // Log before deletion (the user record will be gone after).
    await logSecurityEvent({ userId: user.id, event: 'account_delete', ip, userAgent: ua })

    // Cascade deletes handle conversations, messages, memories, sessions, etc.
    await db.$transaction([
      db.passwordResetToken.deleteMany({ where: { userId: user.id } }),
      db.emailVerificationToken.deleteMany({ where: { userId: user.id } }),
      db.apiKey.deleteMany({ where: { userId: user.id } }),
      db.usageLog.deleteMany({ where: { userId: user.id } }),
      db.userSettings.deleteMany({ where: { userId: user.id } }),
      db.session.deleteMany({ where: { userId: user.id } }),
      db.conversation.deleteMany({ where: { userId: user.id } }),
      db.memory.deleteMany({ where: { userId: user.id } }),
      db.securityLog.deleteMany({ where: { userId: user.id } }),
      db.user.delete({ where: { id: user.id } }),
    ])

    await destroyAllUserSessions(user.id).catch(() => {})
    return ok({ ok: true, message: 'Account deleted permanently.' })
  } catch (e) {
    return errorResponse(e)
  }
}
