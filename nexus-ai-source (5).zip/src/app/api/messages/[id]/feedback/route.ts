import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, NotFoundError, requireUser } from '@/lib/session'
import { feedbackSchema } from '@/lib/validation'

interface Params { params: Promise<{ id: string }> }

export async function POST(req: NextRequest, { params }: Params) {
  try {
    const user = await requireUser()
    const { id: messageId } = await params
    const body = await parseJson(req)
    const parsed = feedbackSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    const message = await db.message.findFirst({
      where: { id: messageId, userId: user.id },
    })
    if (!message) throw new NotFoundError('Message not found')

    const feedback = await db.feedback.upsert({
      where: { userId_messageId: { userId: user.id, messageId } },
      update: { rating: parsed.data.rating, comment: parsed.data.comment ?? null },
      create: {
        userId: user.id,
        messageId,
        rating: parsed.data.rating,
        comment: parsed.data.comment ?? null,
      },
    })
    return ok({ feedback })
  } catch (e) {
    return errorResponse(e)
  }
}
