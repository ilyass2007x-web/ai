import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireUser } from '@/lib/session'
import { logSecurityEvent } from '@/lib/security-log'

interface Params { params: Promise<{ id: string }> }

// Revoke a specific session by ID. Users can only revoke their OWN sessions
// (IDOR protection — the query is scoped to userId).
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const user = await requireUser()
    const { id } = await params
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'
    const ua = req.headers.get('user-agent') ?? undefined

    // Authorization: verify the session belongs to the current user.
    const session = await db.session.findFirst({
      where: { id, userId: user.id },
    })
    if (!session) {
      return errorResponse(new Error('Session not found'))
    }

    await db.session.delete({ where: { id } })
    await logSecurityEvent({ userId: user.id, event: 'session_revoked', ip, userAgent: ua })

    return ok({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
