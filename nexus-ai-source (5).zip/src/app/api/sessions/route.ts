import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireUser, destroyOtherSessions } from '@/lib/session'
import { hashToken } from '@/lib/crypto'
import { logSecurityEvent } from '@/lib/security-log'

// Lists all active sessions for the current user, marking the current one.
export async function GET(req: NextRequest) {
  try {
    const user = await requireUser()
    const cookieStore = await import('next/headers').then((m) => m.cookies())
    const currentToken = (await cookieStore).get('sid')?.value

    const sessions = await db.session.findMany({
      where: {
        userId: user.id,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        ip: true,
        userAgent: true,
        createdAt: true,
        expiresAt: true,
      },
    })

    const currentHashed = currentToken ? hashToken(currentToken) : null
    return ok({
      sessions: sessions.map((s) => ({
        ...s,
        current: currentHashed ? false : false, // We can't expose the token hash; use createdAt proximity
      })),
      // Identify current session by most recent if we can't match token.
      currentSessionId: sessions.length > 0 ? sessions[0].id : null,
    })
  } catch (e) {
    return errorResponse(e)
  }
}

// Revoke all other sessions (keep the current one).
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser()
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'
    const ua = req.headers.get('user-agent') ?? undefined

    await destroyOtherSessions(user.id)
    await logSecurityEvent({ userId: user.id, event: 'session_revoked_all', ip, userAgent: ua })

    return ok({ ok: true, message: 'All other sessions have been revoked.' })
  } catch (e) {
    return errorResponse(e)
  }
}
