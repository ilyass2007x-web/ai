import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import {
  BadRequestError, ConflictError, createSession,
  TooManyRequestsError,
} from '@/lib/session'
import { hashPassword, generateToken, hashToken } from '@/lib/crypto'
import { registerSchema } from '@/lib/validation'
import { rateLimit, LIMITS, getClientIp } from '@/lib/rate-limit'
import { sendEmail, emailTemplates } from '@/lib/email'
import { logSecurityEvent } from '@/lib/security-log'

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIp(req)
    const ua = req.headers.get('user-agent') ?? undefined
    const rl = rateLimit(`register:${ip}`, LIMITS.register.limit, LIMITS.register.windowMs)
    if (!rl.ok) throw new TooManyRequestsError('Too many registration attempts. Try again later.')

    const body = await parseJson(req)
    const parsed = registerSchema.safeParse(body)
    if (!parsed.success) {
      throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')
    }
    const { name, email, password } = parsed.data

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) throw new ConflictError('An account with this email already exists.')

    const user = await db.user.create({
      data: { email, name, passwordHash: await hashPassword(password) },
    })
    await db.userSettings.upsert({
      where: { userId: user.id },
      update: {},
      create: { userId: user.id },
    })

    // Generate verification token — store HASHED in DB, send raw to user.
    const rawToken = generateToken(32)
    await db.emailVerificationToken.create({
      data: {
        userId: user.id,
        token: hashToken(rawToken), // Hashed at rest
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      },
    })

    const template = emailTemplates().verification(name, rawToken)
    await sendEmail({
      to: email,
      subject: template.subject,
      html: template.html,
      text: template.text,
    })

    await createSession(user.id, { remember: true, ip, userAgent: ua })
    await logSecurityEvent({ userId: user.id, event: 'register', ip, userAgent: ua })

    return ok({
      user: { id: user.id, email: user.email, name: user.name, emailVerified: false, role: user.role, avatarUrl: null },
      verificationLink: template.link,
    })
  } catch (e) {
    return errorResponse(e)
  }
}
