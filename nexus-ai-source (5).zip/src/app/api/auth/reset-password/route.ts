import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, destroyAllUserSessions } from '@/lib/session'
import { hashPassword, hashToken, constantTimeEqual } from '@/lib/crypto'
import { resetPasswordSchema } from '@/lib/validation'
import { logSecurityEvent } from '@/lib/security-log'

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'
    const ua = req.headers.get('user-agent') ?? undefined

    const body = await parseJson(req)
    const parsed = resetPasswordSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input.')

    const { token, password } = parsed.data
    const hashedToken = hashToken(token)

    const record = await db.passwordResetToken.findUnique({ where: { token: hashedToken } })
    if (!record || record.usedAt || record.expiresAt < new Date()) {
      throw new BadRequestError('This reset link is invalid or has expired.')
    }

    const newHash = await hashPassword(password)
    await db.$transaction([
      db.user.update({ where: { id: record.userId }, data: { passwordHash: newHash } }),
      db.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
    ])

    // Invalidate all existing sessions for this user after a password reset
    // (prevents session hijacking if the password was changed due to compromise).
    await destroyAllUserSessions(record.userId).catch(() => {})
    await logSecurityEvent({ userId: record.userId, event: 'password_change', ip, userAgent: ua })

    return ok({ ok: true, message: 'Password reset successfully. Please log in.' })
  } catch (e) {
    return errorResponse(e)
  }
}
