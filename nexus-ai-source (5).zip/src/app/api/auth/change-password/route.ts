import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, requireRecentAuth, destroyAllUserSessions } from '@/lib/session'
import { verifyPassword, hashPassword } from '@/lib/crypto'
import { z } from 'zod'
import { logSecurityEvent } from '@/lib/security-log'

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1).max(128),
  newPassword: z.string().min(8, 'Password must be at least 8 characters').max(128)
    .regex(/[a-zA-Z]/, 'Password must contain at least one letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
})

// Change password. Requires:
// 1. Authentication (logged in)
// 2. Recent authentication (within 15 min)
// 3. Correct current password
// After successful change, all sessions are revoked (force re-login).
export async function POST(req: NextRequest) {
  try {
    const user = await requireRecentAuth()
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'
    const ua = req.headers.get('user-agent') ?? undefined

    const body = await parseJson(req)
    const parsed = changePasswordSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input.')

    // Verify current password.
    const userRow = await db.user.findUnique({ where: { id: user.id }, select: { passwordHash: true } })
    if (!userRow) throw new BadRequestError('User not found.')

    const valid = await verifyPassword(parsed.data.currentPassword, userRow.passwordHash)
    if (!valid) throw new BadRequestError('Current password is incorrect.')

    // Hash and update.
    const newHash = await hashPassword(parsed.data.newPassword)
    await db.user.update({ where: { id: user.id }, data: { passwordHash: newHash } })

    // Invalidate ALL sessions (including current) — force re-login everywhere.
    await destroyAllUserSessions(user.id).catch(() => {})
    await logSecurityEvent({ userId: user.id, event: 'password_change', ip, userAgent: ua })

    return ok({ ok: true, message: 'Password changed. Please log in again.' })
  } catch (e) {
    return errorResponse(e)
  }
}
