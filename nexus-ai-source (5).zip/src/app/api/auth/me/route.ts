import { errorResponse, ok } from '@/lib/errors'
import { getCurrentUser } from '@/lib/session'

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) return ok({ user: null })
    return ok({ user })
  } catch (e) {
    return errorResponse(e)
  }
}
