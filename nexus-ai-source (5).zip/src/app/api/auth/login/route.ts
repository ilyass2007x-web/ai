import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, createSession, TooManyRequestsError } from '@/lib/session'
import { verifyPassword, hashToken } from '@/lib/crypto'
import { loginSchema } from '@/lib/validation'
import { rateLimit, LIMITS, getClientIp } from '@/lib/rate-limit'
import { logSecurityEvent } from '@/lib/security-log'

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIp(req)
    const ua = req.headers.get('user-agent') ?? undefined
    const rl = rateLimit(`login:${ip}`, LIMITS.login.limit, LIMITS.login.windowMs)
    if (!rl.ok) throw new TooManyRequestsError('Too many login attempts. Try again later.')

    const body = await parseJson(req)
    const parsed = loginSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError('Invalid email or password.')

    const { email, password, remember } = parsed.data

    // Progressive delay: after 3 failed attempts for this email+IP, add
    // exponential backoff (1s, 2s, 4s, 8s…) to slow down brute-force.
    const failKey = `loginfail:${email.toLowerCase()}:${ip}`
    const failRl = rateLimit(failKey, 10, 15 * 60 * 1000) // track failures for 15 min
    if (failRl.remaining <= 7) {
      const failures = 10 - failRl.remaining
      const delayMs = Math.min(Math.pow(2, failures - 3) * 1000, 30000) // cap at 30s
      if (delayMs > 0) await new Promise((r) => setTimeout(r, delayMs))
    }

    const user = await db.user.findUnique({ where: { email } })
    // Generic error to prevent account enumeration.
    if (!user) {
      await logSecurityEvent({ event: 'login_failure', ip, userAgent: ua, metadata: { reason: 'unknown_email' } })
      throw new BadRequestError('Invalid email or password.')
    }
    const valid = await verifyPassword(password, user.passwordHash)
    if (!valid) {
      await logSecurityEvent({ userId: user.id, event: 'login_failure', ip, userAgent: ua, metadata: { reason: 'wrong_password' } })
      throw new BadRequestError('Invalid email or password.')
    }

    await createSession(user.id, { remember, ip, userAgent: ua })
    await logSecurityEvent({ userId: user.id, event: 'login_success', ip, userAgent: ua })

    return ok({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        emailVerified: user.emailVerified,
        avatarUrl: user.avatarUrl,
        twoFactorEnabled: user.twoFactorEnabled,
      },
    })
  } catch (e) {
    return errorResponse(e)
  }
}
