import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, TooManyRequestsError } from '@/lib/session'
import { generateToken, hashToken } from '@/lib/crypto'
import { forgotPasswordSchema } from '@/lib/validation'
import { rateLimit, LIMITS, getClientIp } from '@/lib/rate-limit'
import { sendEmail, emailTemplates } from '@/lib/email'
import { logSecurityEvent } from '@/lib/security-log'

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIp(req)
    const ua = req.headers.get('user-agent') ?? undefined
    const rl = rateLimit(`reset:${ip}`, LIMITS.resetPassword.limit, LIMITS.resetPassword.windowMs)
    if (!rl.ok) throw new TooManyRequestsError('Too many requests. Try again later.')

    const body = await parseJson(req)
    const parsed = forgotPasswordSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError('Invalid email.')

    const { email } = parsed.data
    const user = await db.user.findUnique({ where: { email } })

    // Always respond generically to avoid account enumeration, but only
    // create a token + email when the user actually exists.
    let resetLink: string | undefined
    if (user) {
      // Invalidate any previous unused tokens for this user.
      await db.passwordResetToken.updateMany({
        where: { userId: user.id, usedAt: null },
        data: { usedAt: new Date() },
      })
      const rawToken = generateToken(32)
      await db.passwordResetToken.create({
        data: {
          userId: user.id,
          token: hashToken(rawToken), // Hashed at rest
          expiresAt: new Date(Date.now() + 60 * 60 * 1000), // 1 hour
        },
      })
      const template = emailTemplates().passwordReset(user.name, rawToken)
      await sendEmail({
        to: email,
        subject: template.subject,
        html: template.html,
        text: template.text,
      })
      resetLink = template.link
      await logSecurityEvent({ userId: user.id, event: 'password_reset', ip, userAgent: ua })
    }

    return ok({
      ok: true,
      message: 'If an account exists for that email, a reset link has been sent.',
      // dev-mode convenience
      resetLink,
    })
  } catch (e) {
    return errorResponse(e)
  }
}
