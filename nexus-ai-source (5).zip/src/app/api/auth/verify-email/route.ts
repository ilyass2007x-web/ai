import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, createSession } from '@/lib/session'
import { hashToken } from '@/lib/crypto'
import { verifyEmailSchema } from '@/lib/validation'
import { getClientIp } from '@/lib/rate-limit'
import { logSecurityEvent } from '@/lib/security-log'

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIp(req)
    const ua = req.headers.get('user-agent') ?? undefined

    const body = await parseJson(req)
    const parsed = verifyEmailSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError('Invalid token.')

    const { token } = parsed.data
    const hashedToken = hashToken(token)

    const record = await db.emailVerificationToken.findUnique({ where: { token: hashedToken } })
    if (!record || record.usedAt || record.expiresAt < new Date()) {
      throw new BadRequestError('This verification link is invalid or has expired.')
    }

    await db.$transaction([
      db.user.update({
        where: { id: record.userId },
        data: { emailVerified: new Date() },
      }),
      db.emailVerificationToken.update({
        where: { id: record.id },
        data: { usedAt: new Date() },
      }),
    ])

    await createSession(record.userId, { remember: true, ip, userAgent: ua })
    await logSecurityEvent({ userId: record.userId, event: 'email_verification', ip, userAgent: ua })

    return ok({ ok: true, message: 'Email verified successfully.' })
  } catch (e) {
    return errorResponse(e)
  }
}
