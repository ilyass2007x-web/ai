import { NextRequest } from 'next/server'
import { errorResponse, ok } from '@/lib/errors'
import { destroySession } from '@/lib/session'
import { getCurrentUser } from '@/lib/session'
import { getClientIp } from '@/lib/rate-limit'
import { logSecurityEvent } from '@/lib/security-log'

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIp(req)
    const ua = req.headers.get('user-agent') ?? undefined
    const user = await getCurrentUser()
    await destroySession()
    if (user) {
      await logSecurityEvent({ userId: user.id, event: 'logout', ip, userAgent: ua })
    }
    return ok({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
