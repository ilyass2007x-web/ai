import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireAdmin } from '@/lib/session'

export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const url = new URL(req.url)
    const take = Math.min(parseInt(url.searchParams.get('take') ?? '100'), 500)
    const type = url.searchParams.get('type')

    const logs = await db.usageLog.findMany({
      where: type ? { type } : undefined,
      orderBy: { createdAt: 'desc' },
      take,
      select: {
        id: true, userId: true, type: true, tokens: true, model: true,
        createdAt: true, metadata: true,
        user: { select: { email: true, name: true } },
      },
    })
    return ok({ logs })
  } catch (e) {
    return errorResponse(e)
  }
}
