import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, requireAdmin } from '@/lib/session'
import { z } from 'zod'

const articleSchema = z.object({
  slug: z.string().trim().min(1).max(200).regex(/^[a-z0-9-]+$/, 'Slug must be lowercase, hyphens only'),
  title: z.string().trim().min(1).max(200),
  description: z.string().trim().min(1).max(300),
  content: z.string().trim().min(1),
  category: z.enum(['general', 'tutorial', 'guide', 'update', 'technical']).default('general'),
  tags: z.array(z.string().max(50)).max(10).default([]),
  published: z.boolean().default(false),
})

// Admin: list all articles (including drafts)
export async function GET() {
  try {
    await requireAdmin()
    const articles = await db.article.findMany({
      orderBy: { createdAt: 'desc' },
      select: { id: true, slug: true, title: true, description: true, category: true, tags: true, published: true, publishedAt: true, createdAt: true, updatedAt: true },
    })
    return ok({ articles })
  } catch (e) {
    return errorResponse(e)
  }
}

// Admin: create article
export async function POST(req: NextRequest) {
  try {
    const user = await requireAdmin()
    const body = await parseJson(req)
    const parsed = articleSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    const existing = await db.article.findUnique({ where: { slug: parsed.data.slug } })
    if (existing) throw new BadRequestError('An article with this slug already exists.')

    const article = await db.article.create({
      data: {
        ...parsed.data,
        authorId: user.id,
        publishedAt: parsed.data.published ? new Date() : null,
      },
    })
    return ok({ article }, 201)
  } catch (e) {
    return errorResponse(e)
  }
}
