import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, NotFoundError, requireAdmin } from '@/lib/session'
import { z } from 'zod'

const updateSchema = z.object({
  slug: z.string().trim().min(1).max(200).regex(/^[a-z0-9-]+$/).optional(),
  title: z.string().trim().min(1).max(200).optional(),
  description: z.string().trim().min(1).max(300).optional(),
  content: z.string().trim().min(1).optional(),
  category: z.enum(['general', 'tutorial', 'guide', 'update', 'technical']).optional(),
  tags: z.array(z.string().max(50)).max(10).optional(),
  published: z.boolean().optional(),
})

interface Params { params: Promise<{ id: string }> }

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    await requireAdmin()
    const { id } = await params
    const body = await parseJson(req)
    const parsed = updateSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    const existing = await db.article.findUnique({ where: { id } })
    if (!existing) throw new NotFoundError('Article not found')

    const wasUnpublished = !existing.published
    const isPublishing = parsed.data.published === true
    const data: any = { ...parsed.data }
    if (isPublishing && wasUnpublished && !existing.publishedAt) {
      data.publishedAt = new Date()
    }

    const article = await db.article.update({ where: { id }, data })
    return ok({ article })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    await requireAdmin()
    const { id } = await params
    const existing = await db.article.findUnique({ where: { id } })
    if (!existing) throw new NotFoundError('Article not found')
    await db.article.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
