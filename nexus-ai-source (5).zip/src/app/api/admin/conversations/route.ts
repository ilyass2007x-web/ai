import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireAdmin } from '@/lib/session'

export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const url = new URL(req.url)
    const take = Math.min(parseInt(url.searchParams.get('take') ?? '50'), 200)

    const conversations = await db.conversation.findMany({
      orderBy: { updatedAt: 'desc' },
      take,
      select: {
        id: true, title: true, archived: true, pinned: true,
        createdAt: true, updatedAt: true,
        user: { select: { id: true, email: true, name: true } },
        _count: { select: { messages: true, webSearches: true } },
      },
    })
    return ok({ conversations })
  } catch (e) {
    return errorResponse(e)
  }
}
