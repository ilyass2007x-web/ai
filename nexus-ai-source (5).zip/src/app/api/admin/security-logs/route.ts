import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireAdmin } from '@/lib/session'

// Admin-only: returns recent security audit log entries.
export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const url = new URL(req.url)
    const take = Math.min(parseInt(url.searchParams.get('take') ?? '100'), 500)
    const event = url.searchParams.get('event')

    const logs = await db.securityLog.findMany({
      where: event ? { event } : undefined,
      orderBy: { createdAt: 'desc' },
      take,
      select: {
        id: true,
        userId: true,
        event: true,
        ip: true,
        userAgent: true,
        metadata: true,
        createdAt: true,
        user: { select: { email: true, name: true } },
      },
    })

    return ok({ logs })
  } catch (e) {
    return errorResponse(e)
  }
}
