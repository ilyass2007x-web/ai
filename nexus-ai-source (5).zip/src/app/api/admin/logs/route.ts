import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireAdmin } from '@/lib/session'

export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const url = new URL(req.url)
    const take = Math.min(parseInt(url.searchParams.get('take') ?? '100'), 500)

    const [webSearches, feedback] = await Promise.all([
      db.webSearch.findMany({
        orderBy: { createdAt: 'desc' },
        take,
        select: {
          id: true, query: true, resultsCount: true, createdAt: true,
          user: { select: { email: true, name: true } },
          conversation: { select: { id: true, title: true } },
        },
      }),
      db.feedback.findMany({
        orderBy: { createdAt: 'desc' },
        take: 50,
        select: {
          id: true, rating: true, comment: true, createdAt: true,
          user: { select: { email: true, name: true } },
          message: { select: { id: true, content: true, conversationId: true } },
        },
      }),
    ])
    return ok({ webSearches, feedback })
  } catch (e) {
    return errorResponse(e)
  }
}
