import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireAdmin } from '@/lib/session'

export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const url = new URL(req.url)
    const search = url.searchParams.get('q') ?? ''
    const take = Math.min(parseInt(url.searchParams.get('take') ?? '50'), 200)

    const users = await db.user.findMany({
      where: search
        ? { OR: [{ email: { contains: search, mode: 'insensitive' } }, { name: { contains: search, mode: 'insensitive' } }] }
        : undefined,
      orderBy: { createdAt: 'desc' },
      take,
      select: {
        id: true, email: true, name: true, role: true, emailVerified: true,
        avatarUrl: true, createdAt: true, updatedAt: true,
        _count: {
          select: { conversations: true, messages: true, memories: true, usageLogs: true },
        },
      },
    })
    return ok({ users })
  } catch (e) {
    return errorResponse(e)
  }
}
