import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, NotFoundError, requireSuperAdmin } from '@/lib/session'
import { z } from 'zod'
import { ROLES } from '@/lib/rbac'
import { logSecurityEvent } from '@/lib/security-log'

const validRoles = Object.values(ROLES)
const roleSchema = z.object({ role: z.enum(validRoles as [string, ...string[]]) })

interface Params { params: Promise<{ id: string }> }

// Change a user's role. Only super_admins can do this.
export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const admin = await requireSuperAdmin()
    const { id: targetUserId } = await params
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'
    const ua = req.headers.get('user-agent') ?? undefined

    const body = await parseJson(req)
    const parsed = roleSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError('Invalid role.')

    const target = await db.user.findUnique({ where: { id: targetUserId } })
    if (!target) throw new NotFoundError('User not found.')

    const oldRole = target.role
    await db.user.update({
      where: { id: targetUserId },
      data: { role: parsed.data.role },
    })

    await logSecurityEvent({
      userId: admin.id,
      event: 'role_change',
      ip, userAgent: ua,
      metadata: { targetUserId, oldRole, newRole: parsed.data.role },
    })

    // If a user's role was elevated, revoke all their sessions so they
    // re-authenticate with the new privileges (prevents privilege escalation
    // via stale sessions).
    if (roleLevel(parsed.data.role) > roleLevel(oldRole)) {
      await db.session.deleteMany({ where: { userId: targetUserId } }).catch(() => {})
    }

    return ok({ ok: true, userId: targetUserId, oldRole, newRole: parsed.data.role })
  } catch (e) {
    return errorResponse(e)
  }
}

function roleLevel(role: string): number {
  const levels: Record<string, number> = { user: 1, moderator: 2, admin: 3, super_admin: 4 }
  return levels[role] ?? 0
}
