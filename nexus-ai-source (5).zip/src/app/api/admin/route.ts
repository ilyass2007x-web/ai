import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireAdmin } from '@/lib/session'

export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const url = new URL(req.url)
    const days = Math.min(parseInt(url.searchParams.get('days') ?? '30'), 90)
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000)

    const [
      totalUsers, activeUsers, totalConversations, totalMessages,
      aiRequests, totalTokens, webSearches, totalMemories, totalFeedback,
      recentUsers, recentUsage,
    ] = await Promise.all([
      db.user.count(),
      db.user.count({ where: { sessions: { some: { createdAt: { gte: since } } } } }),
      db.conversation.count(),
      db.message.count(),
      db.usageLog.count({ where: { type: 'ai_request' } }),
      db.usageLog.aggregate({ _sum: { tokens: true } }),
      db.webSearch.count(),
      db.memory.count(),
      db.feedback.count(),
      db.user.findMany({
        orderBy: { createdAt: 'desc' },
        take: 8,
        select: { id: true, email: true, name: true, role: true, emailVerified: true, createdAt: true },
      }),
      db.usageLog.findMany({
        where: { createdAt: { gte: since } },
        orderBy: { createdAt: 'asc' },
        select: { id: true, userId: true, type: true, tokens: true, model: true, createdAt: true },
      }),
    ])

    // Aggregate usage by day + popular models.
    const byDay = new Map<string, { requests: number; tokens: number; searches: number }>()
    const modelCounts = new Map<string, number>()
    for (const log of recentUsage) {
      const day = log.createdAt.toISOString().slice(0, 10)
      const entry = byDay.get(day) ?? { requests: 0, tokens: 0, searches: 0 }
      if (log.type === 'ai_request') {
        entry.requests += 1
        entry.tokens += log.tokens ?? 0
        if (log.model) modelCounts.set(log.model, (modelCounts.get(log.model) ?? 0) + 1)
      }
      if (log.type === 'web_search') entry.searches += 1
      byDay.set(day, entry)
    }
    const usageByDay = Array.from(byDay.entries()).map(([day, v]) => ({ day, ...v }))
    const popularModels = Array.from(modelCounts.entries())
      .map(([model, count]) => ({ model, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8)

    // Database health: simple connectivity probe.
    let dbHealthy = true
    try {
      await db.$queryRaw`SELECT 1`
    } catch {
      dbHealthy = false
    }

    return ok({
      totals: {
        users: totalUsers,
        activeUsers7d: activeUsers,
        conversations: totalConversations,
        messages: totalMessages,
        aiRequests,
        totalTokens: totalTokens._sum.tokens ?? 0,
        webSearches,
        memories: totalMemories,
        feedback: totalFeedback,
      },
      usageByDay,
      popularModels,
      recentUsers,
      dbHealthy,
    })
  } catch (e) {
    return errorResponse(e)
  }
}
