import { NextRequest } from 'next/server'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, requireAdmin } from '@/lib/session'
import { aiRouter, getAIConfig, reloadAIConfig } from '@/lib/ai/router'
import { listProviderIds } from '@/lib/ai/provider'

// Returns a sanitized view of the active AI configuration.
// API keys are NEVER included — only a boolean "configured" flag.
export async function GET() {
  try {
    await requireAdmin()
    const cfg = getAIConfig()
    const status = await aiRouter.status().catch(() => null)

    const sanitize = (c: typeof cfg.primary | undefined) =>
      c
        ? {
            provider: c.provider,
            model: c.model,
            baseUrl: c.baseUrl ?? null,
            apiKeyConfigured: Boolean(c.apiKey),
          }
        : null

    return ok({
      primary: sanitize(cfg.primary),
      fallback: sanitize(cfg.fallback),
      embedding: sanitize(cfg.embedding),
      tierLabel: cfg.tierLabel,
      status,
      availableProviders: listProviderIds(),
      // Note: env-var based; changes require a server reload.
      configurableViaEnv: true,
    })
  } catch (e) {
    return errorResponse(e)
  }
}

// Reload the AI configuration from environment variables (after the admin
// updates .env / restarts, or in environments that support live env refresh).
export async function POST(req: NextRequest) {
  try {
    await requireAdmin()
    const body = await parseJson(req).catch(() => ({}))
    if (body?.action !== 'reload') {
      throw new BadRequestError('Unknown action. Use { "action": "reload" } to re-read env vars.')
    }
    const cfg = reloadAIConfig()
    const status = await aiRouter.status().catch(() => null)
    return ok({
      reloaded: true,
      primary: {
        provider: cfg.primary.provider,
        model: cfg.primary.model,
        baseUrl: cfg.primary.baseUrl ?? null,
      },
      status,
    })
  } catch (e) {
    return errorResponse(e)
  }
}
