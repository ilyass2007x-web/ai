import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { requireAdmin } from '@/lib/session'
import { FEATURES, USE_CASES, FAQS } from '@/lib/seo/product-info'
import { PRODUCT } from '@/lib/seo/product-info'

export async function GET() {
  try {
    await requireAdmin()

    // Define all public pages and check their metadata coverage.
    const publicPages = [
      { path: '/', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/about', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/features', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      ...FEATURES.map((f) => ({ path: `/features/${f.slug}`, hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true })),
      { path: '/use-cases', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      ...USE_CASES.map((uc) => ({ path: `/use-cases/${uc.slug}`, hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true })),
      { path: '/docs', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/docs/getting-started', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/docs/features', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/docs/security', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/docs/privacy', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/docs/api', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/faq', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/privacy', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/terms', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/contact', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
      { path: '/blog', hasTitle: true, hasDescription: true, hasCanonical: true, hasStructuredData: true },
    ]

    // Count articles
    const [publishedArticles, draftArticles] = await Promise.all([
      db.article.count({ where: { published: true } }),
      db.article.count({ where: { published: false } }),
    ])

    const totalPages = publicPages.length
    const pagesWithFullMeta = publicPages.filter((p) => p.hasTitle && p.hasDescription && p.hasCanonical).length

    return ok({
      indexedPages: publicPages,
      totalPages,
      pagesWithFullMeta,
      missingMeta: publicPages.filter((p) => !p.hasTitle || !p.hasDescription || !p.hasCanonical),
      missingStructuredData: publicPages.filter((p) => !p.hasStructuredData),
      sitemapStatus: 'active',
      robotsStatus: 'active',
      llmsTxtStatus: 'active',
      faqCount: FAQS.length,
      featurePages: FEATURES.length,
      useCasePages: USE_CASES.length,
      publishedArticles,
      draftArticles,
      canonicalBaseUrl: PRODUCT.officialUrl,
    })
  } catch (e) {
    return errorResponse(e)
  }
}
