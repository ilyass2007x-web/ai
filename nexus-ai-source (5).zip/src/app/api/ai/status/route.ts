import { errorResponse, ok } from '@/lib/errors'
import { getCurrentUser } from '@/lib/session'
import { getAIConfig } from '@/lib/ai/router'

// Public (authenticated) endpoint returning a non-sensitive summary of the
// active AI tier. Used by the settings UI to show "Nexus AI • Smart" etc.
// Never returns provider names, URLs, or keys — only a generic tier label.
export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) return ok({ tierLabel: null })
    const cfg = getAIConfig()
    return ok({ tierLabel: cfg.tierLabel })
  } catch (e) {
    return errorResponse(e)
  }
}
