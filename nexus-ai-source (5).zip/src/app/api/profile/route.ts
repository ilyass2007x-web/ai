import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, ConflictError, requireUser, requireRecentAuth } from '@/lib/session'
import { updateProfileSchema } from '@/lib/validation'
import { logSecurityEvent } from '@/lib/security-log'

export async function GET() {
  try {
    const user = await requireUser()
    const profile = await db.user.findUnique({
      where: { id: user.id },
      select: { id: true, email: true, name: true, avatarUrl: true, role: true, emailVerified: true, createdAt: true, twoFactorEnabled: true, lastAuthAt: true },
    })
    return ok({ profile })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const user = await requireUser()
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'
    const ua = req.headers.get('user-agent') ?? undefined

    const body = await parseJson(req)
    const parsed = updateProfileSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    // Email changes require recent authentication.
    if (parsed.data.email && parsed.data.email !== user.email) {
      await requireRecentAuth()
      const taken = await db.user.findUnique({ where: { email: parsed.data.email } })
      if (taken) throw new ConflictError('Email already in use.')
      await logSecurityEvent({ userId: user.id, event: 'email_change', ip, userAgent: ua, metadata: { oldEmail: user.email, newEmail: parsed.data.email } })
    }

    const updated = await db.user.update({
      where: { id: user.id },
      data: parsed.data,
      select: { id: true, email: true, name: true, avatarUrl: true, role: true, emailVerified: true },
    })
    return ok({ profile: updated })
  } catch (e) {
    return errorResponse(e)
  }
}
