import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { BadRequestError, NotFoundError, requireUser } from '@/lib/session'

interface Params { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, { params }: Params) {
  try {
    const user = await requireUser()
    const { id } = await params
    const url = new URL(req.url)
    const format = (url.searchParams.get('format') ?? 'markdown').toLowerCase()

    const conversation = await db.conversation.findFirst({
      where: { id, userId: user.id },
      include: {
        messages: {
          orderBy: { createdAt: 'asc' },
          include: {
            sources: { select: { source: { select: { url: true, title: true, domain: true } } } },
          },
        },
      },
    })
    if (!conversation) throw new NotFoundError('Conversation not found')

    if (format === 'json') {
      return NextResponse.json(conversation, {
        headers: {
          'Content-Disposition': `attachment; filename="${slug(conversation.title)}.json"`,
        },
      })
    }

    if (format === 'txt') {
      let out = `${conversation.title}\n${'='.repeat(conversation.title.length)}\nCreated: ${conversation.createdAt.toISOString()}\n\n`
      for (const m of conversation.messages) {
        out += `[${m.role.toUpperCase()}] ${m.createdAt.toISOString()}\n${m.content}\n\n`
      }
      return new Response(out, {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          'Content-Disposition': `attachment; filename="${slug(conversation.title)}.txt"`,
        },
      })
    }

    // markdown (default)
    let md = `# ${conversation.title}\n\n*Created: ${conversation.createdAt.toISOString()}*\n\n`
    for (const m of conversation.messages) {
      const who = m.role === 'user' ? '🧑 You' : '🤖 Assistant'
      md += `### ${who}\n\n${m.content}\n\n`
      if (m.sources.length > 0) {
        md += `**Sources:**\n`
        for (const s of m.sources) {
          md += `- [${s.source.title}](${s.source.url})\n`
        }
        md += '\n'
      }
    }
    return new Response(md, {
      headers: {
        'Content-Type': 'text/markdown; charset=utf-8',
        'Content-Disposition': `attachment; filename="${slug(conversation.title)}.md"`,
      },
    })
  } catch (e) {
    if (e instanceof BadRequestError) return errorResponse(e)
    return errorResponse(e)
  }
}

function slug(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'conversation'
}
