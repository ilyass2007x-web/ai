import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, NotFoundError, requireUser } from '@/lib/session'
import { updateConversationSchema } from '@/lib/validation'

interface Params { params: Promise<{ id: string }> }

export async function GET(_req: NextRequest, { params }: Params) {
  try {
    const user = await requireUser()
    const { id } = await params
    const conversation = await db.conversation.findFirst({
      where: { id, userId: user.id },
      include: {
        messages: {
          orderBy: { createdAt: 'asc' },
          select: {
            id: true, role: true, content: true, model: true,
            tokenUsage: true, createdAt: true,
            sources: { select: { source: { select: { id: true, url: true, title: true, domain: true, snippet: true } } } },
          },
        },
      },
    })
    if (!conversation) throw new NotFoundError('Conversation not found')
    return ok({ conversation })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const user = await requireUser()
    const { id } = await params
    const body = await parseJson(req)
    const parsed = updateConversationSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    const existing = await db.conversation.findFirst({ where: { id, userId: user.id } })
    if (!existing) throw new NotFoundError('Conversation not found')

    const conversation = await db.conversation.update({
      where: { id },
      data: parsed.data,
      select: { id: true, title: true, archived: true, pinned: true, updatedAt: true },
    })
    return ok({ conversation })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const user = await requireUser()
    const { id } = await params
    const existing = await db.conversation.findFirst({ where: { id, userId: user.id } })
    if (!existing) throw new NotFoundError('Conversation not found')
    await db.conversation.delete({ where: { id } })
    return ok({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
