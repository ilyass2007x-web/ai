import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse, ok } from '@/lib/errors'
import { parseJson } from '@/lib/http'
import { BadRequestError, requireUser } from '@/lib/session'
import { createConversationSchema } from '@/lib/validation'

export async function GET() {
  try {
    const user = await requireUser()
    const conversations = await db.conversation.findMany({
      where: { userId: user.id },
      orderBy: [{ pinned: 'desc' }, { updatedAt: 'desc' }],
      select: {
        id: true,
        title: true,
        archived: true,
        pinned: true,
        createdAt: true,
        updatedAt: true,
        _count: { select: { messages: true } },
      },
      take: 200,
    })
    return ok({ conversations })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser()
    const body = await parseJson(req)
    const parsed = createConversationSchema.safeParse(body)
    if (!parsed.success) throw new BadRequestError(parsed.error.issues[0]?.message ?? 'Invalid input')

    const conversation = await db.conversation.create({
      data: {
        userId: user.id,
        title: parsed.data.title ?? 'New conversation',
        model: parsed.data.model,
      },
    })
    return ok({ conversation }, 201)
  } catch (e) {
    return errorResponse(e)
  }
}
