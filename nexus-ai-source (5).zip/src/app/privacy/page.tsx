import type { Metadata } from 'next'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'

export const metadata: Metadata = {
  title: `Privacy Policy — ${PRODUCT.name}`,
  description: 'Privacy policy for Nexus AI: data collection, usage, retention, and your rights.',
  alternates: { canonical: `${PRODUCT.officialUrl}/privacy` },
  robots: { index: true, follow: true },
}

export default function PrivacyPage() {
  return (
    <MarketingPage>
      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Privacy Policy</h1>
        <p className="mt-2 text-sm text-muted-foreground">Last updated: {new Date().getFullYear()}</p>

        <section className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <h2>1. Overview</h2>
          <p>
            {PRODUCT.name} (&quot;we&quot;, &quot;us&quot;) is an independent AI assistant platform. This
            privacy policy explains how we collect, use, and protect your data when you use our service.
          </p>

          <h2>2. Data We Collect</h2>
          <h3>Account Information</h3>
          <ul>
            <li>Name and email address (for authentication)</li>
            <li>Hashed password (bcrypt, 12 rounds — never stored in plain text)</li>
            <li>Role and email verification status</li>
          </ul>
          <h3>Usage Data</h3>
          <ul>
            <li>Conversations and messages (titles, content, timestamps)</li>
            <li>Memories (durable facts extracted from conversations)</li>
            <li>Web search queries and results</li>
            <li>Session data (IP address, user agent)</li>
            <li>Usage logs (AI requests, token counts)</li>
            <li>Security audit logs</li>
          </ul>

          <h2>3. How We Use Your Data</h2>
          <ul>
            <li>To provide the AI chat, web research, and memory features</li>
            <li>To authenticate your sessions and secure your account</li>
            <li>To improve response quality through conversation context</li>
            <li>To monitor for abuse and security threats</li>
            <li>To provide admin analytics (for administrators)</li>
          </ul>

          <h2>4. Data Sharing</h2>
          <p>
            We do not sell or share your data with third parties. Your conversations and memories
            are isolated to your account. AI inference requests may be sent to the configured AI
            provider (message content only — no stored data is shared).
          </p>

          <h2>5. Data Security</h2>
          <p>We use industry-standard security measures:</p>
          <ul>
            <li>Bcrypt password hashing</li>
            <li>SHA-256 hashed session and token storage</li>
            <li>HTTP-only, SameSite cookies</li>
            <li>Content Security Policy and security headers</li>
            <li>Rate limiting and brute-force protection</li>
            <li>Role-based access control</li>
            <li>Security audit logging</li>
          </ul>

          <h2>6. Your Rights</h2>
          <ul>
            <li><strong>Access:</strong> view your conversations, memories, and settings</li>
            <li><strong>Export:</strong> download your conversations as Markdown/TXT/JSON</li>
            <li><strong>Delete:</strong> delete conversations, memories, or your entire account</li>
            <li><strong>Control:</strong> enable/disable memory and web search</li>
            <li><strong>Revoke sessions:</strong> log out all other devices</li>
          </ul>

          <h2>7. Data Retention</h2>
          <p>
            Your data is retained until you delete it. Sessions expire automatically (30-90 days).
            Security logs are retained for auditing purposes. Account deletion permanently removes
            all associated data.
          </p>

          <h2>8. Contact</h2>
          <p>
            For privacy questions, contact <a href={`mailto:${PRODUCT.contactEmail}`}>{PRODUCT.contactEmail}</a>.
          </p>
        </section>
      </article>
    </MarketingPage>
  )
}
