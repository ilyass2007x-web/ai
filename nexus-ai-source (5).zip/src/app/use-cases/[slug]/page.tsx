import type { Metadata } from 'next'
import Link from 'next/link'
import { MarketingPage } from '@/components/marketing/page'
import { USE_CASES, PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

interface Props { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const uc = USE_CASES.find((u) => u.slug === slug)
  if (!uc) return { title: 'Use case not found' }
  return {
    title: `${uc.title} — ${PRODUCT.name}`,
    description: uc.description,
    alternates: { canonical: `${PRODUCT.officialUrl}/use-cases/${slug}` },
    openGraph: { title: uc.title, description: uc.description, url: `${PRODUCT.officialUrl}/use-cases/${slug}` },
    robots: { index: true, follow: true },
  }
}

export default async function UseCasePage({ params }: Props) {
  const { slug } = await params
  const uc = USE_CASES.find((u) => u.slug === slug)

  if (!uc) {
    return (
      <MarketingPage>
        <div className="mx-auto max-w-2xl px-4 py-20 text-center">
          <h1 className="text-2xl font-bold">Use case not found</h1>
          <Link href="/use-cases" className="mt-4 inline-block text-brand hover:underline">← Back to use cases</Link>
        </div>
      </MarketingPage>
    )
  }

  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Use Cases', url: `${PRODUCT.officialUrl}/use-cases` },
        { name: uc.title, url: `${PRODUCT.officialUrl}/use-cases/${uc.slug}` },
      ])} />

      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <Link href="/use-cases" className="text-sm text-muted-foreground hover:text-foreground">← All use cases</Link>
        <h1 className="mt-4 text-fluid-xl font-bold tracking-tight">{uc.title}</h1>
        <p className="mt-3 text-lg text-muted-foreground">{uc.description}</p>

        <section className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <h2>How {PRODUCT.name} helps</h2>
          <ul>
            {uc.points.map((point) => (
              <li key={point}>{point}</li>
            ))}
          </ul>
        </section>

        <div className="mt-10">
          <Link href="/" className="rounded-xl bg-brand px-5 py-2.5 text-sm font-medium text-brand-foreground hover:bg-brand/90">
            Get started with {PRODUCT.name}
          </Link>
        </div>

        <div className="mt-12 border-t border-border pt-6">
          <h3 className="text-sm font-semibold">Other use cases</h3>
          <div className="mt-3 flex flex-wrap gap-2">
            {USE_CASES.filter((u) => u.slug !== uc.slug).map((u) => (
              <Link key={u.slug} href={`/use-cases/${u.slug}`} className="rounded-full border border-border bg-card px-3 py-1 text-xs hover:border-brand/40">
                {u.title}
              </Link>
            ))}
          </div>
        </div>
      </article>
    </MarketingPage>
  )
}
