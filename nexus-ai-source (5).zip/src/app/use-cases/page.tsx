import type { Metadata } from 'next'
import Link from 'next/link'
import { MarketingPage } from '@/components/marketing/page'
import { USE_CASES, PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `Use Cases — ${PRODUCT.name}`,
  description: 'How students, developers, researchers, content creators, and businesses use Nexus AI.',
  alternates: { canonical: `${PRODUCT.officialUrl}/use-cases` },
  robots: { index: true, follow: true },
}

export default function UseCasesPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Use Cases', url: `${PRODUCT.officialUrl}/use-cases` },
      ])} />

      <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Use Cases</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          {PRODUCT.name} adapts to your workflow, whether you&apos;re studying, coding, researching, creating, or running a business.
        </p>

        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {USE_CASES.map((uc) => (
            <Link
              key={uc.slug}
              href={`/use-cases/${uc.slug}`}
              className="rounded-xl border border-border bg-card p-5 transition-colors hover:border-brand/40"
            >
              <h2 className="font-semibold">{uc.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{uc.description}</p>
            </Link>
          ))}
        </div>
      </div>
    </MarketingPage>
  )
}
