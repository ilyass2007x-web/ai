import type { Metadata } from 'next'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'
import { Mail, MessageSquare, FileText } from 'lucide-react'

export const metadata: Metadata = {
  title: `Contact — ${PRODUCT.name}`,
  description: `Contact Nexus AI for support, questions, or feedback. Email: ${PRODUCT.contactEmail}`,
  alternates: { canonical: `${PRODUCT.officialUrl}/contact` },
  robots: { index: true, follow: true },
}

export default function ContactPage() {
  return (
    <MarketingPage>
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Contact & Support</h1>
        <p className="mt-3 text-muted-foreground">
          We&apos;re here to help. Reach out through any of these channels.
        </p>

        <div className="mt-10 space-y-4">
          <a
            href={`mailto:${PRODUCT.contactEmail}`}
            className="flex items-center gap-4 rounded-xl border border-border bg-card p-5 transition-colors hover:border-brand/40"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand/10 text-brand">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-semibold">General Contact</h2>
              <p className="text-sm text-muted-foreground">{PRODUCT.contactEmail}</p>
            </div>
          </a>

          <a
            href={`mailto:${PRODUCT.supportEmail}`}
            className="flex items-center gap-4 rounded-xl border border-border bg-card p-5 transition-colors hover:border-brand/40"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand/10 text-brand">
              <MessageSquare className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-semibold">Support</h2>
              <p className="text-sm text-muted-foreground">{PRODUCT.supportEmail}</p>
            </div>
          </a>

          <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-5">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand/10 text-brand">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-semibold">Documentation</h2>
              <p className="text-sm text-muted-foreground">
                <a href="/docs" className="text-brand hover:underline">Browse the docs →</a>
              </p>
            </div>
          </div>
        </div>

        <div className="mt-10 rounded-lg border border-border bg-muted/30 p-5 text-sm text-muted-foreground">
          <p>
            Before contacting support, please check our{' '}
            <a href="/faq" className="text-brand hover:underline">FAQ</a> and{' '}
            <a href="/docs" className="text-brand hover:underline">Documentation</a> — many common
            questions are already answered there.
          </p>
        </div>
      </div>
    </MarketingPage>
  )
}
