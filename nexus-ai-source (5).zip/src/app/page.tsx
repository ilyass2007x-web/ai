import type { Metadata } from 'next'
import { AppShell } from '@/components/app-shell'
import { SeoContent } from '@/components/marketing/seo-content'
import {
  organizationStructuredData,
  webSiteStructuredData,
  webApplicationStructuredData,
  faqStructuredData,
  JsonLd,
} from '@/lib/seo/structured-data'
import { PRODUCT } from '@/lib/seo/product-info'

export const metadata: Metadata = {
  title: `${PRODUCT.name} — ${PRODUCT.tagline}`,
  description: PRODUCT.description,
  alternates: { canonical: PRODUCT.officialUrl },
  openGraph: {
    title: `${PRODUCT.name} — ${PRODUCT.tagline}`,
    description: PRODUCT.description,
    url: PRODUCT.officialUrl,
    siteName: PRODUCT.name,
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: `${PRODUCT.name} — ${PRODUCT.tagline}`,
    description: PRODUCT.description,
  },
  robots: { index: true, follow: true },
}

export default function Page() {
  return (
    <>
      {/* Structured data — crawlable by Google, Bing, and AI search engines */}
      <JsonLd data={organizationStructuredData()} />
      <JsonLd data={webSiteStructuredData()} />
      <JsonLd data={webApplicationStructuredData()} />
      <JsonLd data={faqStructuredData()} />

      {/* Server-rendered SEO content — visible to crawlers and non-JS clients */}
      <SeoContent />

      {/* Client-side app shell — overlays SEO content for authenticated users */}
      <AppShell />
    </>
  )
}
