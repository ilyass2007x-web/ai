import type { MetadataRoute } from 'next'
import { PRODUCT, FEATURES, USE_CASES } from '@/lib/seo/product-info'

export default function sitemap(): MetadataRoute.Sitemap {
  const base = PRODUCT.officialUrl
  const now = new Date()

  const staticPages = [
    { url: `${base}`, priority: 1.0, changeFrequency: 'weekly' as const },
    { url: `${base}/about`, priority: 0.9, changeFrequency: 'monthly' as const },
    { url: `${base}/features`, priority: 0.9, changeFrequency: 'monthly' as const },
    { url: `${base}/use-cases`, priority: 0.8, changeFrequency: 'monthly' as const },
    { url: `${base}/docs`, priority: 0.8, changeFrequency: 'monthly' as const },
    { url: `${base}/faq`, priority: 0.8, changeFrequency: 'monthly' as const },
    { url: `${base}/blog`, priority: 0.7, changeFrequency: 'weekly' as const },
    { url: `${base}/privacy`, priority: 0.3, changeFrequency: 'yearly' as const },
    { url: `${base}/terms`, priority: 0.3, changeFrequency: 'yearly' as const },
    { url: `${base}/contact`, priority: 0.5, changeFrequency: 'yearly' as const },
    { url: `${base}/docs/getting-started`, priority: 0.7, changeFrequency: 'monthly' as const },
    { url: `${base}/docs/features`, priority: 0.7, changeFrequency: 'monthly' as const },
    { url: `${base}/docs/security`, priority: 0.7, changeFrequency: 'monthly' as const },
    { url: `${base}/docs/privacy`, priority: 0.7, changeFrequency: 'monthly' as const },
    { url: `${base}/docs/api`, priority: 0.6, changeFrequency: 'monthly' as const },
  ]

  const featurePages = FEATURES.map((f) => ({
    url: `${base}/features/${f.slug}`,
    priority: 0.7,
    changeFrequency: 'monthly' as const,
  }))

  const useCasePages = USE_CASES.map((uc) => ({
    url: `${base}/use-cases/${uc.slug}`,
    priority: 0.6,
    changeFrequency: 'monthly' as const,
  }))

  return [...staticPages, ...featurePages, ...useCasePages].map((page) => ({
    url: page.url,
    lastModified: now,
    changeFrequency: page.changeFrequency,
    priority: page.priority,
  }))
}
