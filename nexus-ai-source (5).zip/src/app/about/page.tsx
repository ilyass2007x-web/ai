import type { Metadata } from 'next'
import Link from 'next/link'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT, FEATURES } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `About ${PRODUCT.name} — Independent AI Assistant Platform`,
  description: PRODUCT.longDescription.slice(0, 160),
  alternates: { canonical: `${PRODUCT.officialUrl}/about` },
  openGraph: {
    title: `About ${PRODUCT.name}`,
    description: PRODUCT.description,
    url: `${PRODUCT.officialUrl}/about`,
  },
  robots: { index: true, follow: true },
}

export default function AboutPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'About', url: `${PRODUCT.officialUrl}/about` },
      ])} />

      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">About {PRODUCT.name}</h1>
        <p className="mt-4 text-lg text-muted-foreground">{PRODUCT.tagline}</p>

        <section className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <h2>What is {PRODUCT.name}?</h2>
          <p>{PRODUCT.longDescription}</p>

          <h2>What makes {PRODUCT.name} different?</h2>
          <ul>
            <li><strong>Provider-agnostic:</strong> Not locked into any single AI provider. Switch between OpenAI, Anthropic, OpenRouter, Ollama, or any OpenAI-compatible endpoint via configuration.</li>
            <li><strong>Independent web research:</strong> An LLM decision router determines when to search, ranks sources by authority, and cites every claim with clickable links.</li>
            <li><strong>Persistent memory:</strong> Durable facts about you are stored in Neon PostgreSQL and retrieved via hybrid full-text + keyword search. Sensitive data is never stored.</li>
            <li><strong>Enterprise security:</strong> Bcrypt hashing, HTTP-only sessions, CSRF protection, rate limiting, RBAC with four roles, hashed token storage, and security audit logging.</li>
            <li><strong>Zero trust architecture:</strong> Every request is validated and authorized server-side. Client-provided roles, IDs, and permissions are never trusted.</li>
          </ul>

          <h2>Who can use {PRODUCT.name}?</h2>
          <p>{PRODUCT.name} is designed for anyone who needs an intelligent AI assistant:</p>
          <ul>
            <li><strong>Students</strong> who need cited, research-backed answers</li>
            <li><strong>Developers</strong> who want code assistance and technical research</li>
            <li><strong>Researchers</strong> who need authority-ranked academic sources</li>
            <li><strong>Content creators</strong> who want persistent context across sessions</li>
            <li><strong>Businesses</strong> that need secure, private AI with data isolation</li>
          </ul>

          <h2>How does it work?</h2>
          <p>When you send a message, {PRODUCT.name} follows a structured orchestration pipeline:</p>
          <ol>
            <li>Authenticates your session securely</li>
            <li>Loads your conversation and recent messages</li>
            <li>Retrieves relevant memories using hybrid search</li>
            <li>An LLM decision router determines whether web research is needed</li>
            <li>If needed: searches authoritative sources, ranks and deduplicates results</li>
            <li>Builds context with system prompt, memories, conversation history, and web research</li>
            <li>Streams the AI response token-by-token via Server-Sent Events</li>
            <li>Persists the response and sources to Neon PostgreSQL</li>
            <li>Extracts durable memories in the background</li>
            <li>Summarizes long conversations to keep the prompt compact</li>
          </ol>

          <h2>Security & Privacy</h2>
          <p>{PRODUCT.name} follows a zero-trust security architecture:</p>
          <ul>
            <li>Passwords hashed with bcrypt (12 rounds)</li>
            <li>Session tokens are SHA-256 hashed at rest in the database</li>
            <li>HTTP-only, SameSite cookies prevent CSRF and session theft</li>
            <li>Rate limiting on all sensitive endpoints (login, register, password reset, chat)</li>
            <li>Progressive delays after failed login attempts</li>
            <li>Role-based access control (user, moderator, admin, super_admin)</li>
            <li>Every database query is scoped to the authenticated user (IDOR protection)</li>
            <li>Security audit log tracks all important events</li>
            <li>Content Security Policy and security headers on all responses</li>
          </ul>
          <p>
            <Link href="/docs/security">Read the full security documentation →</Link>
          </p>

          <h2>Supported Capabilities</h2>
          <ul>
            {FEATURES.map((f) => (
              <li key={f.slug}><Link href={`/features/${f.slug}`}><strong>{f.name}</strong></Link> — {f.description}</li>
            ))}
          </ul>

          <h2>Contact & Support</h2>
          <p>
            For questions or support, contact us at{' '}
            <a href={`mailto:${PRODUCT.contactEmail}`}>{PRODUCT.contactEmail}</a>
            {' '}or visit our <Link href="/contact">contact page</Link>.
          </p>
        </section>
      </article>
    </MarketingPage>
  )
}
