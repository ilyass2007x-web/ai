import type { Metadata } from 'next'
import Link from 'next/link'
import { MarketingPage } from '@/components/marketing/page'
import { FEATURES, PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

interface Props { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const feature = FEATURES.find((f) => f.slug === slug)
  if (!feature) return { title: 'Feature not found' }
  return {
    title: `${feature.title} — ${PRODUCT.name}`,
    description: feature.description,
    alternates: { canonical: `${PRODUCT.officialUrl}/features/${slug}` },
    openGraph: {
      title: feature.title,
      description: feature.description,
      url: `${PRODUCT.officialUrl}/features/${slug}`,
    },
    robots: { index: true, follow: true },
  }
}

export default async function FeatureDetailPage({ params }: Props) {
  const { slug } = await params
  const feature = FEATURES.find((f) => f.slug === slug)

  if (!feature) {
    return (
      <MarketingPage>
        <div className="mx-auto max-w-2xl px-4 py-20 text-center">
          <h1 className="text-2xl font-bold">Feature not found</h1>
          <Link href="/features" className="mt-4 inline-block text-brand hover:underline">← Back to features</Link>
        </div>
      </MarketingPage>
    )
  }

  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Features', url: `${PRODUCT.officialUrl}/features` },
        { name: feature.name, url: `${PRODUCT.officialUrl}/features/${feature.slug}` },
      ])} />

      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <Link href="/features" className="text-sm text-muted-foreground hover:text-foreground">← All features</Link>
        <h1 className="mt-4 text-fluid-xl font-bold tracking-tight">{feature.title}</h1>
        <p className="mt-3 text-lg text-muted-foreground">{feature.description}</p>

        <section className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <h2>Overview</h2>
          <p>{feature.longDescription}</p>

          <h2>Capabilities</h2>
          <ul>
            {feature.capabilities.map((cap) => (
              <li key={cap}>{cap}</li>
            ))}
          </ul>
        </section>

        <div className="mt-10 flex flex-wrap gap-3">
          <Link href="/" className="rounded-xl bg-brand px-5 py-2.5 text-sm font-medium text-brand-foreground hover:bg-brand/90">
            Try {PRODUCT.name}
          </Link>
          <Link href="/docs/features" className="rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:bg-muted">
            Documentation
          </Link>
        </div>

        <div className="mt-12 border-t border-border pt-6">
          <h3 className="text-sm font-semibold">Explore other features</h3>
          <div className="mt-3 flex flex-wrap gap-2">
            {FEATURES.filter((f) => f.slug !== feature.slug).map((f) => (
              <Link
                key={f.slug}
                href={`/features/${f.slug}`}
                className="rounded-full border border-border bg-card px-3 py-1 text-xs hover:border-brand/40"
              >
                {f.name}
              </Link>
            ))}
          </div>
        </div>
      </article>
    </MarketingPage>
  )
}
