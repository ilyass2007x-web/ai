import type { Metadata } from 'next'
import Link from 'next/link'
import { MarketingPage } from '@/components/marketing/page'
import { FEATURES, PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `Features — ${PRODUCT.name}`,
  description: 'Explore the key features of Nexus AI: streaming chat, web research with citations, persistent memory, conversation search, and multilingual support.',
  alternates: { canonical: `${PRODUCT.officialUrl}/features` },
  openGraph: {
    title: `Features — ${PRODUCT.name}`,
    description: 'Streaming chat, web research, persistent memory, conversation search, and multilingual AI.',
    url: `${PRODUCT.officialUrl}/features`,
  },
  robots: { index: true, follow: true },
}

export default function FeaturesPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Features', url: `${PRODUCT.officialUrl}/features` },
      ])} />

      <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Features</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          Everything you need from a modern AI assistant — streaming chat, live web research,
          persistent memory, and enterprise-grade security.
        </p>

        <div className="mt-10 space-y-8">
          {FEATURES.map((feature) => (
            <Link
              key={feature.slug}
              href={`/features/${feature.slug}`}
              className="block rounded-xl border border-border bg-card p-6 transition-colors hover:border-brand/40"
            >
              <h2 className="text-fluid-md font-semibold">{feature.title}</h2>
              <p className="mt-2 text-muted-foreground">{feature.description}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {feature.capabilities.slice(0, 3).map((cap) => (
                  <span key={cap} className="rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">
                    {cap}
                  </span>
                ))}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </MarketingPage>
  )
}
