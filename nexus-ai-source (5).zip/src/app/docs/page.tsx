import type { Metadata } from 'next'
import Link from 'next/link'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `Documentation — ${PRODUCT.name}`,
  description: 'Nexus AI documentation: getting started, features, security, privacy, FAQ, and API reference.',
  alternates: { canonical: `${PRODUCT.officialUrl}/docs` },
  robots: { index: true, follow: true },
}

const DOC_SECTIONS = [
  { slug: 'getting-started', title: 'Getting Started', description: 'Create an account, verify your email, and start your first conversation.' },
  { slug: 'features', title: 'Features Guide', description: 'Detailed documentation of all Nexus AI features and how to use them.' },
  { slug: 'security', title: 'Security', description: 'Authentication, authorization, RBAC, rate limiting, and the zero-trust architecture.' },
  { slug: 'privacy', title: 'Privacy', description: 'How Nexus AI handles your data, memory, and conversations.' },
  { slug: 'faq', title: 'FAQ', description: 'Frequently asked questions and answers.' },
  { slug: 'api', title: 'API Reference', description: 'REST API endpoints for programmatic access.' },
]

export default function DocsPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Documentation', url: `${PRODUCT.officialUrl}/docs` },
      ])} />

      <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Documentation</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          Everything you need to know about using and securing {PRODUCT.name}.
        </p>

        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {DOC_SECTIONS.map((section) => (
            <Link
              key={section.slug}
              href={`/docs/${section.slug}`}
              className="rounded-xl border border-border bg-card p-5 transition-colors hover:border-brand/40"
            >
              <h2 className="font-semibold">{section.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{section.description}</p>
            </Link>
          ))}
        </div>
      </div>
    </MarketingPage>
  )
}
