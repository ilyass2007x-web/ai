import type { Metadata } from 'next'
import Link from 'next/link'
import { MarketingPage } from '@/components/marketing/page'
import { FEATURES, PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `Features Guide — ${PRODUCT.name} Documentation`,
  description: 'Detailed documentation of all Nexus AI features: chat, web research, memory, search, and multilingual support.',
  alternates: { canonical: `${PRODUCT.officialUrl}/docs/features` },
  robots: { index: true, follow: true },
}

export default function DocsFeaturesPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Documentation', url: `${PRODUCT.officialUrl}/docs` },
        { name: 'Features', url: `${PRODUCT.officialUrl}/docs/features` },
      ])} />

      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Features Guide</h1>
        <p className="mt-3 text-muted-foreground">Detailed documentation for each {PRODUCT.name} feature.</p>

        <div className="mt-8 space-y-8">
          {FEATURES.map((feature) => (
            <section key={feature.slug} className="prose prose-sm dark:prose-invert max-w-none">
              <h2>{feature.title}</h2>
              <p>{feature.longDescription}</p>
              <h3>Capabilities</h3>
              <ul>
                {feature.capabilities.map((cap) => <li key={cap}>{cap}</li>)}
              </ul>
              <p><Link href={`/features/${feature.slug}`}>Read the {feature.name} feature page →</Link></p>
            </section>
          ))}
        </div>
      </article>
    </MarketingPage>
  )
}
