import type { Metadata } from 'next'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `Security — ${PRODUCT.name} Documentation`,
  description: 'Nexus AI security architecture: authentication, RBAC, rate limiting, session management, hashed token storage, and zero-trust design.',
  alternates: { canonical: `${PRODUCT.officialUrl}/docs/security` },
  robots: { index: true, follow: true },
}

export default function DocsSecurityPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Documentation', url: `${PRODUCT.officialUrl}/docs` },
        { name: 'Security', url: `${PRODUCT.officialUrl}/docs/security` },
      ])} />

      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Security</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          {PRODUCT.name} follows a zero-trust security architecture. Every request is validated and
          authorized server-side — client-provided roles, IDs, and permissions are never trusted.
        </p>

        <section className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <h2>Authentication</h2>
          <ul>
            <li>Passwords hashed with <strong>bcrypt (12 rounds)</strong> — never stored in plain text</li>
            <li>Opaque session tokens in <strong>HTTP-only, SameSite=lax cookies</strong></li>
            <li>Session tokens are <strong>SHA-256 hashed at rest</strong> in the database</li>
            <li>Session expiration (30 days default, 90 days with &quot;remember me&quot;)</li>
            <li>Session invalidation after logout and password change</li>
            <li>All sessions can be revoked (&quot;log out all devices&quot;)</li>
            <li>Session fixation prevention — tokens are rotated on every login</li>
          </ul>

          <h2>Role-Based Access Control (RBAC)</h2>
          <p>Four-level role hierarchy with granular permissions:</p>
          <ul>
            <li><strong>User</strong> — manage own profile, conversations, memories, settings</li>
            <li><strong>Moderator</strong> — moderate content, manage reports (inherits User)</li>
            <li><strong>Admin</strong> — manage users, content, platform settings (inherits Moderator)</li>
            <li><strong>Super Admin</strong> — full system administration including role changes (inherits Admin)</li>
          </ul>
          <p>Permissions are enforced server-side via the <code>requireRole()</code> and <code>hasPermission()</code> helpers.</p>

          <h2>Rate Limiting & Brute-Force Protection</h2>
          <ul>
            <li>IP-based rate limits on login, registration, and password reset</li>
            <li>Progressive delays after failed login attempts (exponential backoff)</li>
            <li>Per-user rate limits on chat (30/min, 500/day) and web search (20/min)</li>
            <li>Generic error messages to prevent account enumeration</li>
          </ul>

          <h2>IDOR Protection</h2>
          <p>
            Every database query involving user data is scoped to the authenticated user&apos;s ID.
            Users cannot access another user&apos;s conversations, messages, memories, or settings by
            changing a URL ID. The server validates ownership on every request.
          </p>

          <h2>Input Validation</h2>
          <p>
            Every user-controlled input is validated server-side using <strong>Zod</strong> schemas.
            Frontend validation is for UX only; the server never trusts client input.
          </p>

          <h2>Security Headers</h2>
          <ul>
            <li><strong>Content-Security-Policy</strong> — restricts resource loading</li>
            <li><strong>X-Frame-Options: DENY</strong> — clickjacking protection</li>
            <li><strong>X-Content-Type-Options: nosniff</strong> — MIME-type sniffing protection</li>
            <li><strong>Referrer-Policy</strong> — strict-origin-when-cross-origin</li>
            <li><strong>Permissions-Policy</strong> — disables camera, microphone, geolocation</li>
            <li><strong>HSTS</strong> — force HTTPS in production</li>
          </ul>

          <h2>Security Audit Log</h2>
          <p>
            All security events are logged: login success/failure, logout, password change/reset,
            email verification, role changes, admin actions, session revocation, and suspicious
            activity. Passwords, API keys, and tokens are never logged.
          </p>

          <h2>CSRF Protection</h2>
          <p>
            SameSite=lax cookies prevent CSRF on state-changing requests. The cookie is not sent
            on cross-site POST requests, protecting against login CSRF and form submission attacks.
          </p>

          <h2>SQL Injection Protection</h2>
          <p>
            {PRODUCT.name} uses <strong>Prisma ORM</strong> exclusively — no raw SQL queries with
            user input. Parameterized queries are used automatically. Raw queries (used only for
            full-text search) use Prisma&apos;s tagged template literals which are injection-safe.
          </p>

          <h2>XSS Protection</h2>
          <p>
            User-generated content is rendered as markdown (not raw HTML). React escapes all content
            by default. <code>dangerouslySetInnerHTML</code> is only used for JSON-LD structured data
            (which is generated server-side from trusted product data).
          </p>
        </section>
      </article>
    </MarketingPage>
  )
}
