import type { Metadata } from 'next'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `Getting Started — ${PRODUCT.name} Documentation`,
  description: 'Learn how to create an account, verify your email, and start your first conversation with Nexus AI.',
  alternates: { canonical: `${PRODUCT.officialUrl}/docs/getting-started` },
  robots: { index: true, follow: true },
}

export default function GettingStartedPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Documentation', url: `${PRODUCT.officialUrl}/docs` },
        { name: 'Getting Started', url: `${PRODUCT.officialUrl}/docs/getting-started` },
      ])} />

      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Getting Started</h1>

        <section className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <h2>Create your account</h2>
          <ol>
            <li>Click <strong>Sign up</strong> on the homepage.</li>
            <li>Enter your full name, email address, and a strong password (minimum 8 characters with at least one letter and one number).</li>
            <li>A verification email will be sent to your address.</li>
            <li>Click the verification link to confirm your email and activate your account.</li>
          </ol>

          <h2>Start your first conversation</h2>
          <ol>
            <li>After logging in, click <strong>New chat</strong> in the sidebar.</li>
            <li>Type your question or message in the input box at the bottom.</li>
            <li>Press <kbd>Enter</kbd> to send, or <kbd>Shift+Enter</kbd> for a new line.</li>
            <li>The AI will stream its response in real-time.</li>
          </ol>

          <h2>Using web research</h2>
          <p>
            {PRODUCT.name} automatically decides when to search the web. If your question requires
            current information (latest news, prices, documentation, versions), the AI will search
            authoritative sources and cite them with clickable links in the response.
          </p>
          <p>
            You can explicitly ask the AI to search by including phrases like &quot;search the web&quot;
            or &quot;what is the latest&quot; in your message.
          </p>

          <h2>Managing conversations</h2>
          <ul>
            <li><strong>New chat</strong> — start a new conversation</li>
            <li><strong>Pin</strong> — keep important conversations at the top</li>
            <li><strong>Archive</strong> — hide old conversations without deleting them</li>
            <li><strong>Rename</strong> — give conversations meaningful titles</li>
            <li><strong>Search</strong> — find any conversation, message, or memory instantly</li>
            <li><strong>Export</strong> — download as Markdown, TXT, or JSON</li>
          </ul>

          <h2>Configuring settings</h2>
          <p>Open Settings from the user menu to configure:</p>
          <ul>
            <li><strong>Model override</strong> — use a specific model id or the server default</li>
            <li><strong>Temperature</strong> — control response creativity</li>
            <li><strong>Response style</strong> — concise, balanced, or detailed</li>
            <li><strong>Memory</strong> — enable/disable long-term memory</li>
            <li><strong>Web research</strong> — enable/disable web search</li>
            <li><strong>Language</strong> — English, French, or Arabic</li>
            <li><strong>Theme</strong> — light, dark, or system</li>
          </ul>
        </section>
      </article>
    </MarketingPage>
  )
}
