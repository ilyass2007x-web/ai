import { redirect } from 'next/navigation'

export default function DocsFaqPage() {
  redirect('/faq')
}
