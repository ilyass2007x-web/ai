import type { Metadata } from 'next'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `API Reference — ${PRODUCT.name} Documentation`,
  description: 'REST API endpoints for Nexus AI: authentication, conversations, chat, memory, search, and admin.',
  alternates: { canonical: `${PRODUCT.officialUrl}/docs/api` },
  robots: { index: true, follow: true },
}

const ENDPOINTS = [
  { method: 'POST', path: '/api/auth/register', desc: 'Create a new account' },
  { method: 'POST', path: '/api/auth/login', desc: 'Authenticate and create a session' },
  { method: 'POST', path: '/api/auth/logout', desc: 'Destroy the current session' },
  { method: 'GET', path: '/api/auth/me', desc: 'Get the current user' },
  { method: 'POST', path: '/api/auth/forgot-password', desc: 'Request a password reset email' },
  { method: 'POST', path: '/api/auth/reset-password', desc: 'Reset password with a token' },
  { method: 'POST', path: '/api/auth/verify-email', desc: 'Verify email with a token' },
  { method: 'POST', path: '/api/auth/change-password', desc: 'Change password (requires recent auth)' },
  { method: 'GET', path: '/api/conversations', desc: 'List conversations' },
  { method: 'POST', path: '/api/conversations', desc: 'Create a conversation' },
  { method: 'GET', path: '/api/conversations/:id', desc: 'Get a conversation with messages' },
  { method: 'PATCH', path: '/api/conversations/:id', desc: 'Rename, pin, or archive' },
  { method: 'DELETE', path: '/api/conversations/:id', desc: 'Delete a conversation' },
  { method: 'GET', path: '/api/conversations/:id/export', desc: 'Export as Markdown/TXT/JSON' },
  { method: 'POST', path: '/api/chat', desc: 'Send a message and stream the AI response (SSE)' },
  { method: 'POST', path: '/api/chat/regenerate', desc: 'Regenerate a previous response' },
  { method: 'GET', path: '/api/memories', desc: 'List stored memories' },
  { method: 'PATCH', path: '/api/memories/:id', desc: 'Edit a memory' },
  { method: 'DELETE', path: '/api/memories/:id', desc: 'Delete a memory' },
  { method: 'POST', path: '/api/search', desc: 'Search conversations, messages, and memories' },
  { method: 'GET', path: '/api/settings', desc: 'Get user settings' },
  { method: 'PATCH', path: '/api/settings', desc: 'Update user settings' },
  { method: 'GET', path: '/api/sessions', desc: 'List active sessions' },
  { method: 'POST', path: '/api/sessions', desc: 'Revoke all other sessions' },
  { method: 'DELETE', path: '/api/sessions/:id', desc: 'Revoke a specific session' },
  { method: 'GET', path: '/api/profile', desc: 'Get profile' },
  { method: 'PATCH', path: '/api/profile', desc: 'Update profile (email change requires recent auth)' },
  { method: 'POST', path: '/api/account', desc: 'Delete account (requires recent auth + confirmation)' },
  { method: 'POST', path: '/api/messages/:id/feedback', desc: 'Rate a message' },
  { method: 'GET', path: '/api/ai/status', desc: 'Get active AI tier label' },
  { method: 'GET', path: '/api/admin', desc: 'Admin dashboard stats (admin only)' },
  { method: 'GET', path: '/api/admin/users', desc: 'List users (admin only)' },
  { method: 'GET', path: '/api/admin/conversations', desc: 'List all conversations (admin only)' },
  { method: 'GET', path: '/api/admin/usage', desc: 'Usage logs (admin only)' },
  { method: 'GET', path: '/api/admin/logs', desc: 'Web search & feedback logs (admin only)' },
  { method: 'GET', path: '/api/admin/security-logs', desc: 'Security audit logs (admin only)' },
  { method: 'GET', path: '/api/admin/ai', desc: 'AI provider config (admin only)' },
  { method: 'PATCH', path: '/api/admin/users/:id/role', desc: 'Change user role (super_admin only)' },
]

export default function DocsApiPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Documentation', url: `${PRODUCT.officialUrl}/docs` },
        { name: 'API', url: `${PRODUCT.officialUrl}/docs/api` },
      ])} />

      <article className="mx-auto max-w-4xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">API Reference</h1>
        <p className="mt-3 text-muted-foreground">
          REST API endpoints for {PRODUCT.name}. All endpoints use JSON and require authentication
          (except auth endpoints). Admin endpoints require the admin role.
        </p>

        <div className="mt-8 overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="px-4 py-2 text-left font-semibold">Method</th>
                <th className="px-4 py-2 text-left font-semibold">Endpoint</th>
                <th className="px-4 py-2 text-left font-semibold">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {ENDPOINTS.map((ep) => (
                <tr key={ep.method + ep.path}>
                  <td className="px-4 py-2">
                    <span className={`rounded px-1.5 py-0.5 text-xs font-mono font-medium ${
                      ep.method === 'GET' ? 'bg-emerald-500/10 text-emerald-600' :
                      ep.method === 'POST' ? 'bg-amber-500/10 text-amber-600' :
                      ep.method === 'PATCH' ? 'bg-sky-500/10 text-sky-600' :
                      'bg-red-500/10 text-red-600'
                    }`}>{ep.method}</span>
                  </td>
                  <td className="px-4 py-2 font-mono text-xs">{ep.path}</td>
                  <td className="px-4 py-2 text-muted-foreground">{ep.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <section className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <h2>Chat Streaming</h2>
          <p>
            The <code>/api/chat</code> endpoint returns a Server-Sent Events (SSE) stream. Events:
          </p>
          <ul>
            <li><code>meta</code> — conversation ID, assistant message ID, sources, search status</li>
            <li><code>delta</code> — incremental content chunks</li>
            <li><code>done</code> — stream complete</li>
            <li><code>error</code> — error message (if any)</li>
          </ul>
        </section>
      </article>
    </MarketingPage>
  )
}
