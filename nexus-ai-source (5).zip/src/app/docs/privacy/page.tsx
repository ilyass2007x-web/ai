import type { Metadata } from 'next'
import { MarketingPage } from '@/components/marketing/page'
import { PRODUCT } from '@/lib/seo/product-info'
import { breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `Privacy — ${PRODUCT.name} Documentation`,
  description: 'How Nexus AI handles your data: conversations, memories, web searches, and authentication.',
  alternates: { canonical: `${PRODUCT.officialUrl}/docs/privacy` },
  robots: { index: true, follow: true },
}

export default function DocsPrivacyPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'Documentation', url: `${PRODUCT.officialUrl}/docs` },
        { name: 'Privacy', url: `${PRODUCT.officialUrl}/docs/privacy` },
      ])} />

      <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Privacy</h1>
        <p className="mt-3 text-muted-foreground">How {PRODUCT.name} collects, uses, and protects your data.</p>

        <section className="mt-8 prose prose-sm dark:prose-invert max-w-none">
          <h2>Data We Store</h2>
          <ul>
            <li><strong>Account data:</strong> name, email, hashed password, role, email verification status</li>
            <li><strong>Conversations:</strong> titles, messages, AI model used, timestamps</li>
            <li><strong>Memories:</strong> durable facts extracted from conversations (name, projects, preferences)</li>
            <li><strong>Web search records:</strong> search queries and ranked sources</li>
            <li><strong>Sessions:</strong> IP address, user agent, expiration (for session management)</li>
            <li><strong>Usage logs:</strong> AI requests, token counts, model used (for analytics)</li>
            <li><strong>Security logs:</strong> login events, admin actions, suspicious activity</li>
          </ul>

          <h2>Memory System</h2>
          <p>
            {PRODUCT.name} automatically extracts durable facts from your conversations to improve
            future interactions. This includes your name, projects, tech stack, and preferences.
          </p>
          <p><strong>Sensitive data is NEVER stored:</strong></p>
          <ul>
            <li>Passwords, API keys, tokens, bearer credentials</li>
            <li>Payment information, credit card numbers</li>
            <li>Personal identification numbers (SSN, passport)</li>
          </ul>
          <p>
            You have full control over your memory: view, edit, delete individual memories, clear all
            memories, or disable the feature entirely from <strong>Settings → Memory</strong>.
          </p>

          <h2>Data Isolation</h2>
          <p>
            Your data is isolated to your account. No other user can access your conversations,
            messages, or memories. Every database query is scoped to your authenticated user ID.
          </p>

          <h2>Data Retention</h2>
          <ul>
            <li><strong>Conversations & messages:</strong> retained until you delete them</li>
            <li><strong>Memories:</strong> retained until you delete them or disable memory</li>
            <li><strong>Sessions:</strong> expire automatically (30-90 days) or on logout</li>
            <li><strong>Security logs:</strong> retained for security auditing</li>
          </ul>

          <h2>Account Deletion</h2>
          <p>
            You can permanently delete your account from <strong>Settings → Privacy → Danger Zone</strong>.
            This removes all your conversations, messages, memories, settings, and sessions. The action
            is irreversible and requires typing &quot;DELETE&quot; to confirm plus recent authentication.
          </p>

          <h2>Data Export</h2>
          <p>
            You can export any conversation as Markdown, plain text, or JSON at any time. The export
            includes all messages and web sources for that conversation.
          </p>

          <h2>Third-Party Services</h2>
          <ul>
            <li><strong>Neon PostgreSQL:</strong> database hosting (data at rest)</li>
            <li><strong>AI provider:</strong> configurable (OpenAI, Anthropic, Ollama, etc.) — only message content is sent for inference; no data is stored by the provider</li>
            <li><strong>Web search provider:</strong> configurable — search queries are sent to retrieve fresh information</li>
          </ul>
          <p>API keys for these services are stored server-side only and never exposed to the browser.</p>
        </section>
      </article>
    </MarketingPage>
  )
}
