import type { Metadata } from 'next'
import { MarketingPage } from '@/components/marketing/page'
import { FAQS, PRODUCT } from '@/lib/seo/product-info'
import { faqStructuredData, breadcrumbStructuredData, JsonLd } from '@/lib/seo/structured-data'

export const metadata: Metadata = {
  title: `FAQ — ${PRODUCT.name}`,
  description: 'Frequently asked questions about Nexus AI: what it is, what it can do, web research, memory, security, and more.',
  alternates: { canonical: `${PRODUCT.officialUrl}/faq` },
  robots: { index: true, follow: true },
}

export default function FaqPage() {
  return (
    <MarketingPage>
      <JsonLd data={breadcrumbStructuredData([
        { name: 'Home', url: PRODUCT.officialUrl },
        { name: 'FAQ', url: `${PRODUCT.officialUrl}/faq` },
      ])} />
      <JsonLd data={faqStructuredData()} />

      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h1 className="text-fluid-xl font-bold tracking-tight">Frequently Asked Questions</h1>
        <p className="mt-3 text-muted-foreground">Everything you need to know about {PRODUCT.name}.</p>

        <div className="mt-10 space-y-4">
          {FAQS.map((faq) => (
            <div key={faq.question} className="rounded-lg border border-border bg-card p-5">
              <h2 className="font-semibold">{faq.question}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </MarketingPage>
  )
}
