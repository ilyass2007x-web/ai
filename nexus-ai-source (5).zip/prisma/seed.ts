// Seed script: creates an admin user and ensures default settings.
// Run with: bun run db:seed
import { db } from '../src/lib/db'
import { hashPassword } from '../src/lib/crypto'

async function main() {
  const adminEmail = 'admin@aichat.local'
  const existing = await db.user.findUnique({ where: { email: adminEmail } })
  if (!existing) {
    const user = await db.user.create({
      data: {
        email: adminEmail,
        name: 'Admin',
        passwordHash: await hashPassword('admin12345'),
        emailVerified: new Date(),
        role: 'admin',
      },
    })
    await db.userSettings.upsert({
      where: { userId: user.id },
      update: {},
      create: { userId: user.id },
    })
    console.log('✓ Admin user created:')
    console.log('  Email: admin@aichat.local')
    console.log('  Password: admin12345')
  } else {
    // Ensure admin role + verified.
    await db.user.update({
      where: { id: existing.id },
      data: { role: 'admin', emailVerified: existing.emailVerified ?? new Date() },
    })
    await db.userSettings.upsert({
      where: { userId: existing.id },
      update: {},
      create: { userId: existing.id },
    })
    console.log('✓ Admin user already exists (role ensured).')
  }
}

main()
  .then(async () => {
    await db.$disconnect()
  })
  .catch(async (e) => {
    console.error('Seed failed:', e)
    await db.$disconnect()
    process.exit(1)
  })
